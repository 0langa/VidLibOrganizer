# Task 05: App-wide and cross-process coordination


**Files:** Create `crates/vidlib-fileops/src/coordinator.rs`, `crates/vidlib-fileops/tests/coordinator.rs`, `src-tauri/src/app_state.rs`; modify fileops src/lib.rs, `src-tauri/src/jobs.rs`, `src-tauri/src/main.rs`, manifests/Cargo.lock.

**Interfaces:** Produces Coordinator/Lease and recovery gate from 4.3. Extend desktop state with Arc-managed plan/job registries and app-data paths, while retaining libraries.json preferences. Use fs4's OS shared/exclusive lock adapter, owned by RAII guards; each lease owns a separately opened lock-file handle and is not Clone, so one reader's Drop cannot release another reader's lock.

- [ ] **Step 1 — Red:** Add `readers_exclude_writer`, `writer_excludes_second_process`, `panic_releases_lease`, `startup_pending_journal_blocks_writes`, `other_process_epoch_revokes_old_plan`, and desktop tests that duplicate scans/actions use the same coordinator. A spawned fixture process must actually contend on the same lock file.
  ```rust
  assert_eq!(writer_attempt.unwrap_err().code, ErrorCode::Busy);
  assert_eq!(new_write.unwrap_err().code, ErrorCode::RecoveryRequired);
  assert!(coordinator.try_acquire(LeaseKind::Recovery).is_ok());
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test coordinator`; run desktop job tests where Tauri dependencies exist.
- [ ] **Step 3 — Implement:** Short process-local locks plus shared read/exclusive write OS lock file; check pending journals while holding the relevant lock. Integrate existing duplicate scan/action entry points and close-window handling. Cache browsing is allowed; new physical scans wait/refuse while a write/recovery is active. Return typed busy status and release all guards on error/panic.
- [ ] **Step 4 — Verify green:** Coordinator subprocess tests and existing job tests. Verify two installed app processes cannot mutate concurrently, not just two threads of one Jobs struct.
- [ ] **Step 5 — Commit:** `feat: coordinate collection reads writes and recovery`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


### 4.3 Execution, journal, events, and coordination

Task 04 owns Journal, StepReceipt, event/state persistence and `Journal::open(path: &Path) -> Result<Journal, OpError>`, `begin(&mut self, plan: &ExecutionPlan) -> Result<OperationId, OpError>`, `intent(&mut self, op, step: &ExecutionStep) -> Result<(), OpError>`, `complete(&mut self, op, receipt: &StepReceipt) -> Result<(), OpError>`, `pending(&self) -> Result<Vec<PendingOperation>, OpError>`, `events_after(cursor, limit) -> Result<EventPage, OpError>`, and `ack_events(&mut self, ids: &[EventId]) -> Result<(), OpError>`. ExecutionPlan/ExecutionStep are imported from Rename's pure model, not redefined. A connection is opened/used on its owning blocking thread; read queries use separate connections. Set/verify WAL, FULL, foreign_keys=ON, busy_timeout=5000 ms; migrations/intent/receipt transactions use BEGIN IMMEDIATE and explicit commit. No SQLite transaction spans filesystem I/O.

Own schema: `schema_migrations`, `operations`, `steps`, `receipts`, `operation_events`, `outbox_ack`, `history_visibility`; Task 25 adds protected-root policy tables. Each step stores full native path codec, expected prestate, object/temporary ownership, group/sequence, and observed poststate; plan/recipe inputs are stored for inspection but recovery uses the compiled steps. State machine: Prepared -> Running -> Completed / Cancelled / Failed / RecoveryRequired; steps Planned -> IntentDurable -> Applied -> CompletionDurable, or Compensated/Unresolved. Applied is the observed in-memory action state until its receipt transaction commits; a restart without that receipt follows reconciliation, not a fabricated durable flag. SQLite commit failure stops the next filesystem step.

`ExecutionStep` variants cover RenameEntry, CreateDirectory, StageCopy, PublishCopy, RemoveSource, SetMetadata, RemoveOwnedCopy, and RemoveOwnedEmptyDirectory, with exact expected states. `StepReceipt` records actual paths/identity, digest when applicable, metadata, completed phase, and durability result. Store intent before action and receipt after action; reconcile the action/receipt gap by identity, not blind retries. One dependency group is the compensation unit; completed prior groups remain completed.

Rename-cycle temporary names are logical reservations recorded in the graph/journal; the first no-replace move materializes the path atomically. Do not create an empty placeholder and then overwrite it. Copy staging uses create-new ownership with a recorded native identity, and publication still uses no-replace semantics.

`OperationEventV1` contains stable EventId, OperationId, GroupId, StepId, kind, completed phase, native before/after paths, before/after FileStamp, digest if available, observed time, `origin: App`, and journal sequence/provenance. Emit facts for each completed phase, including a verified published copy whose later source removal fails. Events and receipts commit together. Imported reports never become executable journals.

Task 05 owns `Coordinator::open(app_data: &Path) -> Result<Coordinator, OpError>` and `try_acquire(kind: LeaseKind) -> Result<Lease, OpError>` with RAII Read/Write/Recovery leases. Use Tauri's `app.path().app_local_data_dir()` for the two databases and lock file, validate local storage, and retain the existing app_config_dir libraries.json location. Use a per-app-data OS advisory lock file (shared readers, exclusive writer), plus process-local job registry and startup pending-journal gate. A recovery lease is exclusive but may enter RecoveryRequired state. No destructive job bypasses it, including legacy duplicate actions. A second instance cannot write to this app data concurrently. Denied acquisition returns Busy/RecoveryRequired, not a blocking UI wait.

The operation store also owns a monotonic namespace/policy epoch. Read/capture it under a read lease, store it with the plan, and compare again inside the write lease before preflight. Increment it after any app path mutation or protected-root policy update, including partial success, before releasing the lease. Read queries/registries use it to revoke stale results across app instances. An intent/receipt failure leaves the recovery gate active rather than authorizing a stale plan. Blueprint root registration cannot retroactively permit an older plan to rename a newly protected root.

Task 07 owns `execute(plan: &RenamePlan, lease: &Lease, journal: &mut Journal, fs: &mut dyn Filesystem, control: &JobControl) -> Result<OperationReport, OpError>`. The real Windows and Linux adapters and fault-injection test adapter implement `Filesystem`: capture/verify state, no-replace rename/publish, owned directory/staging creation, verified content I/O, metadata changes, and flush results. `OpError` has stable code, phase, operation/step/item IDs when known, message, and retryability; UI receives a serializable DTO, not a panic/debug dump.

Task 08 owns `reconcile(op: &PendingOperation, fs: &mut dyn Filesystem) -> Result<RecoveryPreview, OpError>` and `apply_recovery(preview, choice: Resume | Restore, lease, journal, fs, control) -> Result<OperationReport, OpError>`. Task 09 owns `plan_undo(completed: &OperationRecord, namespace: &NamespaceSnapshot, version: PlanRef) -> Result<RenamePlan, OpError>`; inverse operations use the same executor/journal/confirmation flow.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.


## Desktop baseline build prerequisite

Workspace-local GTK/WebKit native SDK is ready: source /workspace/.tools/desktop-env.sh; use CARGO_TARGET_DIR=/workspace/.tools/desktop-target for shared warmed desktop compilation. Baseline desktop tests fail only at tauri::generate_context! because src-tauri/icons/icon.png is missing (only icon.ico is tracked). When you integrate desktop code, add a faithful PNG encoding of the existing icon as a narrow build prerequisite, run desktop tests and include it with your integration commit; do not redesign the icon. This does not establish Windows runtime evidence.

## Task04 integration handoff

Read task-04-report.md for committed Journal APIs and recovery-state details after the controller clears its review. Journal is intentionally !Send/!Sync: create/use it on its owning blocking thread; store paths/Arc-managed registries in desktop state rather than sharing one Journal across threads. Task04 did not add the persisted namespace/policy epoch store. Task05 is authorized to extend journal/ modules and migration tests narrowly to implement that section4.3 operation-store responsibility, with checked schema migration/preservation of existing pending operations and events. Keep epochs in operations.sqlite3, not a competing JSON state store or Blueprint DB; no SQLite transaction may span media filesystem effects. Existing schema checks/migrations must recognize the resulting supported schema coherently.

Task04 performance correction advances the operation schema to v2 through a checked v1->v2 migration, preserving v1 SQL/checksum. Current effects use a compact covering operation_effect_header index and an unfinished_steps partial index; keep new epoch/status queries targeted and do not restore per-step full operation/inspection reconstruction. Read the final report and current migration code rather than assuming v1 is still current.

## Typed-error compatibility clarification

Task05 is authorized to make a minimal ui/api.js adapter change needed for existing duplicate UI consumers when desktop commands return structured OpError DTOs. Preserve stable code/phase/IDs and expose a useful .message through safe existing render paths; check invoke rejection and existing job-status error handling. This is compatibility for the task-owned typed Busy/RecoveryRequired/StaleState protocol, with focused verification, not a new UI workflow.
