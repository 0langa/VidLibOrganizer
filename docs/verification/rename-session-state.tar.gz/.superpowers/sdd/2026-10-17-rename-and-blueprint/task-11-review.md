### Spec Compliance

- ❌ Issues found: Unicode sentence casing does not consume an initial titlecase letter, and title/sentence casing changes the spelling of an initial capital dotted I. These are the two casing findings below; the rest of the Task 11 behavior visible in this diff matches the brief and the controller's Delimited/Between ruling.
- ⚠️ Cannot verify from diff: Windows runtime/offline packaging and filesystem qualification remain pending. The reported Windows cross-check establishes compilation only; release gates must stay closed.
- ⚠️ Cannot verify from diff: Complete Rename UI, later rules/regex, R01–R18 release completion, and the separate Blueprint release are outside this backend slice. This diff adds no unsupported frontend controls.

### Strengths

- `crates/vidlib-rename/src/text.rs:201` and `:293`: operations resolve each selector against current input, change only the selected byte range, and validate the assembled filename without path parsing or sanitization. Grapheme positions use checked inclusive logical endpoints and safe UTF-8 byte boundaries.
- `crates/vidlib-rename/src/text.rs:100`, `:520`, and `:594`: typed operations cover the requested edit operations, ordered explicit replacement scope/sensitivity, explicit transliteration, exceptions and Roman handling. Delimited and flat paired Between semantics are documented and implemented separately.
- `crates/vidlib-rename/src/evaluate.rs:78`, `:112`, and `:121`: original/current values remain separate; a failed rule records its ID and explanation, blocks only its row, and retains the original target rather than exposing partial output. Earlier successful explanations remain available.
- `crates/vidlib-rename/src/recipe.rs:36` and `:304`, and `crates/vidlib-rename/src/text.rs:53`: the new operation data integrates with strict tagged serde configuration and operation validation. The existing Keep/FixedStem serialized shapes remain intact. The manifest and lock additions belong to the owning crate; no unrelated dependency resolution appears in the package.
- `crates/vidlib-rename/tests/text.rs:39`, `:324`, `:368`, `:411`, `:482`, `:654`, `:760`, and `:885`: literal behavioral cases exercise ordering, grapheme safety, Unicode expansion/context, opt-in Roman/transliteration, extension isolation, invalid positions, current-input evaluation, invalid output rejection and failed-row target preservation.

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- **Sentence capitalization ignores Unicode titlecase letters.** `crates/vidlib-rename/src/text.rs:629` consumes `sentence_start` only for `is_lowercase()` or `is_uppercase()`. Unicode titlecase letters (category Lt), including U+01C5 `ǅ`, satisfy neither predicate. Consequently Sentence case on `ǅ hello.mkv` produces `ǅ Hello.mkv`, although the first word already supplied the sentence's cased letter and the expected result is `ǅ hello.mkv`. This violates the Unicode sentence-case requirement. Detect Unicode Cased characters including Lt when consuming sentence capitalization, and add a regression covering an initial titlecase digraph followed by a lowercase word.

#### Minor (Nice to Have)

- **Title/sentence mode unnecessarily decomposes an initial capital dotted I.** `crates/vidlib-rename/src/text.rs:623` and `:624` lowercase the entire word before title-casing its first cased character. For `İSTANBUL`, lowercase expands U+0130 into `i` + U+0307, after which `title_first` produces `I` + U+0307 + `stanbul`. Unicode title mapping preserves the original initial U+0130, yielding `İstanbul`. The strings are canonically equivalent but have different filename bytes, so this falls short of the full title-mapping and spelling-preservation intent. Title-map the original first cased character and lowercase the remaining text with the appropriate context; add exact-codepoint regressions for Title and Sentence modes.

### Checks and Review Limits

- Read the supplied contract, brief, report, official reviewer prompt and packaged full diff. The initial tool response truncated the middle of the diff; recovered only that omitted text/tests region from the package. No independent git diff or whole changed-file reread was performed.
- Named cross-interface check: examined unchanged `RecipeV1` selector validation and `valid_component` at `crates/vidlib-rename/src/recipe.rs:284` and `:344` to establish whether the new evaluator preserves legacy validation and rejects filename components rather than sanitizing them. It does.
- Named dependency-interface check: inspected `unicode-segmentation`'s `unicode_words` documentation/filter to establish whether the new case engine's word classification covers Alphabetic/Number input; it does. This did not resolve the separate Lt capitalization-state error.
- Focused Unicode doubt check: compiled a Rust constant expression for `'ǅ'.is_lowercase() || 'ǅ'.is_uppercase()` to LLVM IR on stdout with the report's Rust environment. It returned the constant `false`, confirming the predicate defect; the erroneous full-name output follows directly from the reviewed `convert_case` loop. No package/suite reruns or checkout mutations were performed. Python Unicode data also identified U+01C5/U+01C8/U+01CB/U+01F2 as Lt with neither lower nor upper classification.
- The reported focused/workspace/Clippy/format/cross-compile results were not rerun merely to confirm them. No Windows runtime result is inferred from compilation.

### Assessment

**Task quality: Needs fixes.**

**Finding counts:** 0 Critical, 1 Important, 1 Minor.

**Reasoning:** The backend interfaces, operation coverage, error isolation, dependencies and literal regression tests are cohesive and fit Task 11's ownership. The sentence-state bug needs correction before this Unicode casing slice is trusted; the exact-codepoint title mapping issue should be addressed in the same area.
