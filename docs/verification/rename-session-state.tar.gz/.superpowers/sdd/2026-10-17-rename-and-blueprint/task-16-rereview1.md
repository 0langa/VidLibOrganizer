### Finding Verdicts

- **I1 — Concurrent preset instances bypass expectedRevision and regress the active record: ADDRESSED.** `src-tauri/src/rename_preferences.rs:54` opens an independent, permanent app-local lock-file handle and acquires an exclusive fs4 kernel lock. `:233` acquires it before reading/checking the current record and retains the handle through archive allocation/orphan handling and publication at `:288`; production publication still invokes the existing write-plus-flush path (`:216`). A competing writer receives retryable `presetBusy`, and a later stale expectedRevision is checked after acquiring the lock. The lock is released by handle drop on return/error; no marker/PID becomes authority. `:443` adds the deterministic two-AppState interleaving at the exact original failure point, including stale retry rejection and explicit revision-2 advancement to revision 3. `:539` covers stale lock-file contents, prepublication failure and release to another instance; `:592` covers existing symlink rejection.

- **I2 — Structural rendering silently discards unfinished JSON drafts: ADDRESSED.** `ui/recipe/editor.js:7` stores exact draft text by stable rule ID; render at `:21` no longer clears it. `ui/recipe/fields.js:31` restores the draft textarea and invalid state even when the last valid parameters became Keep or another typed family. `editor.js:39` prevents replacing the same rule's type from hiding its draft, while Undo/Redo remain blocked during unresolved drafts. Extraction still fails at `:56`; only correction, explicit removal (`:51`), replacement or destruction clears the applicable draft. Tests at `tests/ui/recipe-editor.spec.mjs:98` cover Add/reorder/other-rule type changes; `:117` verifies actual Rename Apply revocation and absence of preview/save dispatch while invalid; `:143` covers the additional Keep-type visibility edge and correction.

### New Breakage in the Fix Diff

None. No new direct Critical/Important defect found in the lock scope, error/release paths, retained draft state, or changed tests.

### Out-of-Scope Observations

None newly identified. Native Windows locking/write-through/power-loss behavior and WebView2 qualification remain pending; the reported Windows GNU all-target check is compilation evidence only (`src-tauri/src/rename_preferences.rs:54`, `ui/recipe/fields.js:31`).

### Verification Evidence

- Read the official scoped re-review template, the appended fix report, and the entire 31,148-byte `4d0cb80..7b5e124` fix package once. Used targeted line locators for report references. No original full-review repeat, generated diff, helper, suite rerun, or product mutation.
- The appended report names exact behavioral reds for the original two defects and the Keep-type edge; the added tests in the fix correspond to those claimed failures. Final reported passing evidence is 9 persistence adapter tests, 2 saved-recipe/selection preview tests, 8 editor tests, 16 Rename browser regression tests, static checks and Windows all-target cross-compilation. The report correctly records that the 16-test browser run preceded the last draft-only branch adjustment and that the final 8-test editor run covers that adjustment. These results were not independently rerun and are not a new full-workspace result.

### Verdict

**Fix round:** All findings addressed, no new Critical/Important breakage.

**Open findings:** None. **Counts:** Critical 0; Important 0; Minor 0.
