### Task 15: Selection filters, mappings, overrides, and exports

**Files:** Create `crates/vidlib-rename/src/selection.rs`, `crates/vidlib-rename/src/mappings.rs`, `crates/vidlib-rename/tests/selection_mappings.rs`; extend DTOs/evaluate; use a bounded CSV parser rather than split-on-comma.

**Interfaces:** `select(inventory: &Inventory, filter: &SelectionFilter) -> Result<Vec<EntryId>, RenameError>`; `import_mappings(reader, format, inventory, grants) -> Result<MappingSet, RenameError>`; `export_report(plan, SpreadsheetSafe | ExactMapping) -> Result<Vec<u8>, RenameError>`. Explicit mapping format v1 has `old_path,new_path` with quoted CSV or a user-selected delimiter; exact path lookup precedes unique-basename fallback. Pasted new-name lists map the frozen explicit order and require exact cardinality.

- [ ] **Step 1 — Red:** Add `every_filter_dimension`, `exclude_rebuilds_numbers_and_collisions`, `ambiguous_basename_and_outside_root_rejected`, `quoted_csv_and_paste_cardinality`, `mapping_limits_before_allocation`, and `spreadsheet_safe_export_does_not_change_recorded_path`.
  ```rust
  assert_eq!(err.code, RenameErrorCode::AmbiguousMapping);
  assert_eq!(limit_error.code, RenameErrorCode::ImportLimit);
  assert_eq!(stored_original_name, "=SUM(1,2).mkv");
  assert!(spreadsheet_cell.starts_with('\''));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test selection_mappings`.
- [ ] **Step 3 — Implement:** Wildcard/PCRE2 filters across every R11 field, depth/kind/extension/date/size/attribute selection, exact path mapping, explicit row override, 64 MiB/100,000-row streaming limits and safe reports. Reject traversal/duplicate mappings and unknown IDs. Distinguish spreadsheet-safe reports from lossless mapping exports so protection prefixes never accidentally become renamed filenames.
- [ ] **Step 4 — Verify green:** Boundary tests at/above byte/row limits and quoted Unicode/multiline CSV; all-row preflight after selection changes. Formula-like input is literal data and never executed.
- [ ] **Step 5 — Commit:** `feat: add bounded selection mappings and report workflows`.

