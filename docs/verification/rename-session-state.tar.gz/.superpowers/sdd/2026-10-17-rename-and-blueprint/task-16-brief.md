# Task 16: Presets and the single recipe editor


**Files:** Create `crates/vidlib-rename/src/presets.rs`, `crates/vidlib-rename/tests/presets.rs`, `src-tauri/src/rename_preferences.rs`, `ui/recipe/editor.js`, `ui/recipe/history.js`, `ui/recipe/fields.js`, `tests/ui/recipe-editor.spec.mjs`; extend commands/app state.

**Interfaces:** `PresetStore::load/save_revision/import/export`; PresetId with immutable revision/RecipeV1 snapshot, app-local durable save. Implements createRecipeEditor from 4.4 plus edit undo/redo. Blueprint later embeds this same editor without evaluating names in JS.

- [ ] **Step 1 — Red:** Add `recipe_round_trip_and_version_rejection`, `failed_save_preserves_previous`, `import_limits_and_rule_count`, `edit_undo_redo_is_not_filesystem_undo`; browser test reorder/repeat/disable rules and restore the same serialized recipe.
  ```rust
  assert_eq!(reloaded.recipe, original.recipe);
  assert_eq!(too_many_rules.code, RenameErrorCode::ImportLimit);
  assert_eq!(active_revision, old_revision); // failed save cannot replace it
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test presets`; `npx playwright test tests/ui/recipe-editor.spec.mjs`.
- [ ] **Step 3 — Implement:** 1 MiB/100-rule validation, revisioned presets, atomic persistence through create-new temp+flush+safe replacement of the **app-owned** preset record (never a media target), exact recipe import/export, common editor lifecycle and undo/redo state. Exported recipe data grants no access and carries no executable operations.
- [ ] **Step 4 — Verify green:** Preset/browser tests and reproduced preview goldens from saved recipes; edited presets create new revisions rather than mutate attached snapshots.
- [ ] **Step 5 — Commit:** `feat: add versioned presets and shared recipe editing`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.



## Task11 selector and text-schema handoff
Read task-11-report.md for typed TextOperation/RuleParameters::Text, explicit extension/WholeName and full case/exception/Roman behavior. Existing Delimited selects afterNth opening literal through next same delimiter/end, optional opening inclusion. New Between selects the Nth flat opening/closing literal pair with optional inclusion, implementing approved second-bracketed-segment editing. Expose these as typed data in the shared editor when this task owns those controls; do not recreate transformations in JS, silently change selector semantics, or lose configured inactive rules. Original/current fields and current-input segment resolution remain backend-owned. Dotted-I title spelling is a deferred final-triage minor, not permission to normalize names.


## Controller mixed-kind numbering scope ruling
Task15 mixed-kind numbering uses a narrow RecipeV1 NumberingScope::Files (serde default) or explicitly selected Directories with one frozen primary vector for the chosen kind. Number rules consume ordinals/apply only within that scope; other-kind selected rows retain their current name through that Number rule and may use other rules. Do not globally reject mixed file/directory selection, because combined parent/child preview is required. Required template Counter outside the active primary scope produces a clear missing/scope row issue unless the AST explicitly supplies fallback/optional behavior. Generic assign_numbers remains an explicit-vector primitive; Task18 removes companions from primary vectors before freezing. Reason: approved spec separates directory numbering while requiring one consistent file/parent final-path preview, and existing RecipeV1 has one numbering order. Cost if wrong: users expecting independently configured simultaneous file and directory counters in one recipe need an explicit multi-scope rule/binding extension and revised previews; schema default may require import migration. No native authority or scope is granted. Test both explicit scopes with mixed selected kinds, out-of-scope Counter, recomputation/collisions and later companions.


## Shared desktop/editor contract verbatim
### 4.4 Tauri/JavaScript and Blueprint contracts

Task 10 exposes owned command request structs and `Result<_, CommandError { code, message, phase, item_id, operation_id, retryable }>`; serialize using camelCase consistently. Commands clone Arc-managed handles under short locks, release guards, then start blocking workers. Job types carry owned results; query responses page at 200 rows. Never keep a std MutexGuard or rusqlite Connection borrow across await.

Core commands: `select_sources(PickerKind) -> SelectionDto`, `start_inventory(InventoryRequestDto) -> JobId`, `start_rename_preview(RenameRequestDto) -> JobId`, `job_status(JobId) -> JobStatusDto`, `cancel_job(JobId)`, `rename_page(PlanRef, PageQuery) -> Page<PlanRowDto>`, `confirm_rename(PlanRef) -> ConfirmationDto`, `apply_rename(PlanRef, confirmation_nonce) -> JobId`, `operation_history(PageQuery) -> Page<OperationDto>`, `recovery_preview(OperationId)`, `start_recovery(RecoveryRef, choice, nonce)`, `start_undo(OperationId) -> JobId`. Nonces bind the current session/revision/summary and are revoked on edits. Queries do not reauthorize native paths.

All **new** commands use one owned argument named `request` (wrap multi-field cases in the corresponding request DTO) plus managed state; JS invokes them with `{ request: dto }`. Existing commands retain their prior argument shape. Task 10 adds `src-tauri/tests/command_contracts.rs` and `tests/ui/fixtures/command-contracts.json` to verify camelCase/tag/decimal-string serialization against the same golden payloads used by browser mocks. PageQuery contains cursor, limit capped at 200, display sort/filter, and expected data revision; it never changes recipe numbering order.

Common JS interfaces: `watchJob(jobId, {signal, onProgress}) -> Promise<JobResult>` cleans up timers on finish/navigation/error; `createRecipeEditor({recipe, onChange}) -> {getRecipe(), setRecipe(recipe), destroy()}` never computes filenames; `formatExactBytes(decimalString)` uses BigInt and string-safe formatting. `call()` in `ui/api.js` remains compatible with existing commands while new errors are formatted centrally.


Task14 provides pure Template rendering and FrozenInputCache preparation, with a narrow desktop NamingRule::Template route beside Keep/FixedStem. The current shared editor is a small Task10 Keep/FixedStem editor; evolve it under this task into the single lifecycle/roundtrip/edit-history component, preserving existing Rename behavior/tests while Task21 owns the complete control families. Do not lose configured inactive rules or implement filename evaluation in JavaScript. Read current typed schemas before serializing; Task15 may add explicit numbering_scope default Files/Directories.

Task15 is adding serde-default optional RecipeV1.selection_filter to retain full inventory-selection filter configuration in saved recipes, with frozen resulting IDs and explicit exclusions validated rather than silently regenerated during evaluation. Read actual schema/report. Saved IDs grant no access; fresh inventory preparation binds filters to current IDs. Preserve this plus numbering_scope when importing, editing, saving and attaching immutable recipe snapshots.

Rootless SDK update after Task15 cross-check ended: controller added missing /workspace/.tools/mingw-sysroot/usr/bin/x86_64-w64-mingw32-gcc symlink to already pinned gcc-posix. Minimal windres input including windows.h compiled successfully (exit0,188-byte object). No repository/product change. Earlier Task14/15 desktop cross-check runs remain honestly blocked; a later full desktop cross-check can now be attempted for changed Windows code. This preflight is not desktop compilation or Windows runtime proof.

## Reviewed Task15 wire/data boundary
Task15 core RecipeV1 retains its existing portable snake_case serialized schema, including new selection_filter and numbering_scope. Desktop command payloads now use explicit camelCase adapters SelectionFilterDto/SelectionPatternDto/etc in src-tauri/src/selection.rs and RowOverrideDto in commands/rename.rs. Shared command-contracts.json includes a literal nontrivial request; both Rust and Chromium verify it, including exact bounds. Preserve that explicit boundary, rather than leaking core serde fields into new command DTOs. Read Task15 report public interface section and fix-round1 section for current details.

The current Task10 editor/caller is a minimal Keep/FixedStem shape, while this task adds true ordered RecipeV1 editing/preset snapshots. Migrate that integration deliberately: retain usable backend preview and never display multiple configured rules while silently previewing only the first. Necessary narrow current-RecipeV1 preview/command adaptation is within this task's listed commands/app-state ownership; Task21 still owns completing all control families/journeys after metadata/companions/layout/attribute tasks. Do not add a JS filename engine, silently drop inactive rules, or claim later native capabilities are complete.

## Controller postpublication preset durability ruling

Ruling: Task16 preset save failures before atomic current-record replacement preserve the previous active record. Atomic replacement is the publication/commit point; if a subsequent directory flush fails, return a distinct presetCommitUncertain outcome requiring reload, retain the prior immutable revision, and never describe it as rolled back or an ordinary uncommitted save failure. Reason: the approved atomic/durable-save requirement cannot make a completed filesystem rename disappear when a later durability acknowledgement fails; a compensating overwrite can fail too and would hide the actual state. The plan's failed_save_preserves_previous test applies to prepublication failures, with a separate postpublication uncertainty regression. Cost if wrong: callers/users expecting every error to mean the old active revision remains must handle an uncertainty/reload state and may see a newly published revision after reload; additional UI and recovery-state handling is required. No media target or native execution authority is involved. Require actual precommit-fault preservation and injected postcommit-flush uncertainty coverage, old immutable record retention, and visible reload behavior; Windows write-through/runtime qualification remains pending.
