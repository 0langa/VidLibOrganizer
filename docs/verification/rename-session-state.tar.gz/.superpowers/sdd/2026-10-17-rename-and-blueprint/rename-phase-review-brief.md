# Rename phase review — controller preparation, not yet dispatched

The user changed today's boundary to finish Rename throughTask23, then pause before Blueprint24 until tomorrow. This is the broad review of the Rename implementation at that phase boundary. The full canonical32-task plan remains in force for the later continuation; this is not the final whole-project Task32 review or a completion claim.

## Required inputs when dispatched

- Official requesting-code-review/code-reviewer.md template.
- Canonical plan docs/superpowers/plans/2026-10-17-rename-and-blueprint.md, Rename Tasks01–23 and traceability/safety contracts.
- Approved docs/superpowers/specs/2026-10-17-renaming-design.md and library-tools-design.md. Blueprint is a later optional implementation; current Rename marker/protected-root/independent-operation contracts still apply.
- Final committed docs/verification/rename.md, actual final validation logs/report and supplied full branch merge-base..HEAD package. Controller supplies exact range/path at dispatch; do not substitute HEAD~1 or Task23-only diff.
- deferred-minors.md: every existing item must receive a disposition, including resolved-by-earlier-task and native-qualification-pending facts, without silently discarding open findings.
- Literal Ruling paragraphs from progress.md (currently20; use current actual count) and the final tracked Rename handoff. Review the actual implementation under those documented decisions, including stated compatibility costs.

## Scope and method

Review Rename R01–R18 completeness, current duplicate/preferences regressions, native/exact authority, complete graph/counter/companion/destination/metadata composition, all-selected validation, UI revision/confirmation races, full journal/inverse/crash compatibility, platform evidence and offline packaging. Check interface joins across earlier tasks, not only the latest report. Actual native Windows runtime/MSVC/installer/NTFS/exFAT/share/storage/power-loss and reference-hardware qualification stay explicitly pending where unavailable, with Windows production mutation gates closed. Compile/Chromium/portable evidence cannot establish those checks or the independent Rename release gate.

The checkout/index/HEAD/branch are read-only; write only the supplied /workspace/scratch review report. No helpers or extra reviewers. Read the provided whole-branch package in manageable passes if needed; do not duplicate suite runs to confirm logs. Run only a narrowly focused check for a concrete code doubt that existing evidence does not answer; recommend heavier validation rather than running it without need. Separate code findings from acknowledged pending native qualification and later Blueprint ownership, and state any Cannot-verify item for controller resolution. Do not pre-judge severity; report concrete file:line, trigger, impact and corrective direction.

## Output

Return spec/coverage and code-quality verdicts, Critical/Important/Minor findings, every deferred finding's disposition, and any unresolved evidence or platform limits. Controller owns ONE broad Rename fix dispatch and ONE scoped re-review of that fix range, then explicit adjudication of residuals. No further implementation or review agents are dispatched by this reviewer. No push/merge/publish/release is authorized.

The plan's ignored process workspace must remain for Blueprint continuation; no full-plan cleanup is authorized at today's pause. All retained handoff facts/rulings/costs and pending checks must also be committed outside it before stopping.

Concrete Task23 scale checkpoint to assess using final evidence:1000 real forward items took476397ms, Undo plan4744ms, Journal::begin5579ms;100items4198/40/79ms. Begin wall time includes pretransaction validation/serialization and only upper-bounds actual SQLite write-lock hold; no isolated lock timer or100k mutation pass. Actual100k metadata/page/frozen fixture timings are separate from full-preview runtime recipe binding1MiB refusal. Judge user impact and remaining scale qualifications explicitly; do not convert these observations into a release pass or assume every performance observation has already been resolved by keyed lookups.

Dispatch checkpoint: Task23 approved0Critical/0Important/1Minor. Current deferred index has16items (new16 timing-dependent metadata-tail cancellation test); tracked handoff preserves historical15snapshot plus explicit16addition. Use current index and tracked Task23review, not the entry snapshot alone. Final available633Rust/4Node57browser4Python/Clippy/fmt/JS/Linuxrelease/GNUcfg/helper8/NSISsourcecompile pass; realWindows remainsPENDING/gatesCLOSED.
