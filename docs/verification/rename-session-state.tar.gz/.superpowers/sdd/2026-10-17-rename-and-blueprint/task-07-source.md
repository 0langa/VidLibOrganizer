### Task 07: Journaled in-place rename execution

**Files:** Create `crates/vidlib-fileops/src/rename.rs`, `crates/vidlib-fileops/tests/rename.rs`; extend platform/journal/events; export execute from src/lib.rs.

**Interfaces:** Implements execute from 4.3 for in-place rename graph groups, consuming the exact approved PlanRef/source snapshots, Write lease, Journal and Filesystem. It emits receipts/events, never generates target names at runtime.

- [ ] **Step 1 — Red:** Add `executes_exact_reviewed_plan`, `late_stale_item_changes_nothing_in_preflight`, `no_runtime_collision_suffix`, `all_graph_steps_have_prior_durable_intent`, and `failed_group_stops_following_groups`.
  ```rust
  assert_eq!(std::fs::read(&expected_target)?, b"fixture");
  assert!(!unexpected_suffix.exists());
  assert_eq!(recorded_intents_before_actions, executed_step_ids);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test rename`.
- [ ] **Step 3 — Implement:** Whole-selection preflight, then per-step identity/ancestor/freshness checks and no-replace execution under the writer lease. Flush intent before action and completion after; stop on journal or filesystem error. Retain unresolved steps and invalidate path-dependent results before releasing the writer. Avoid broad refactors of old duplicate actions.
- [ ] **Step 4 — Verify green:** Rename tests on real temporary files and fault-injection adapter; Windows tests for sharing violations and timestamps. Cancel at deterministic group boundaries; assert completed groups are reported honestly.
- [ ] **Step 5 — Commit:** `feat: execute reviewed rename plans with durable receipts`.

