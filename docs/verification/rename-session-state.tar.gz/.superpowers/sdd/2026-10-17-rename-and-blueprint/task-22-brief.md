# Task 22: Native multi-selection, drop, and Explorer entry


**Files:** Create `src-tauri/src/entrypoint.rs`, `src-tauri/installer/hooks.nsh`, `src-tauri/tests/entrypoint.rs`, `tests/ui/native-selection.spec.mjs`; extend selection/commands, tauri.conf.json/capabilities and UI source selection.

**Interfaces:** select_sources accepts Files/Folders/LibraryRoots; entrypoint parses a path argument list into inactive backend grants and opens review. Optional installer-controlled Explorer integration uses arguments directly, not a shell script; uninstall removes only app-owned registrations.

- [ ] **Step 1 — Red:** Add `native_picker_preserves_paths`, `explorer_arguments_select_without_applying`, `multiple_instances_forward_selection_safely`, `malicious_quoted_path_is_data`, `cancelled_picker_changes_nothing`, and keyboard/drop fixtures.
  ```rust
  assert_eq!(selected_native_paths, expected_os_paths);
  assert_eq!(mutation_calls, 0);
  assert!(!selection.applied);
  ```
- [ ] **Step 2 — Verify red:** Windows desktop entrypoint tests and `npx playwright test tests/ui/native-selection.spec.mjs`.
- [ ] **Step 3 — Implement:** Native rfd multi-selection with no to_string_lossy round-trip, Tauri native drop paths resolved on Rust side, explicit argument framing/validation and optional opt-in Explorer registration. A second instance forwards only selection to the active app or presents it after acquiring the coordinator; never accepts an apply command from process arguments. Keep capabilities narrowly scoped and local CSP intact.
- [ ] **Step 4 — Verify green:** Windows Explorer right-click/multi-file/Unicode/UNC/cancel smoke tests and uninstall registry cleanup; record actual evidence, not just a parsed argument unit test.
- [ ] **Step 5 — Commit:** `feat: add native collection selection and Explorer entry`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.1 Native paths, IDs, observations

Task 01 owns opaque UUID newtypes in `vidlib_inventory::ids`: `InventoryId`, `RootId`, `EntryId`, `GrantId`, `SessionId`, `JobId`, `PlanId`, `GroupId`, `StepId`, `OperationId`, `EventId`, `PresetId`, `CollectionId`, `AttemptId`, `AttachmentId`. IDs are not permissions. Revisions are Rust `u64`; schema versions are small `u32`.

`NativePathRecord { platform: WindowsUtf16Le | UnixBytes, bytes: Vec<u8> }` round-trips exact OS strings. Persist path keys as bytes, with a separate display string; only root-relative validated records enter portable inventories. Never use display strings or physical file IDs as unique path keys. Unsupported/unroundtrippable rename names remain visible issues. All new JSON u64/i128 counts/times/revisions are validated decimal strings; UUIDs are strings. SQLite stores exact quantities as decimal text, with fixed-width big-endian numeric sort keys where numeric indexing is required. Do not cast them to SQLite REAL or JS Number.

`FileStamp` contains optional physical identity, size for regular files, native-precision created/modified/accessed epoch-nanoseconds (`Option<i128>`), and Windows attribute bits. `PhysicalId` includes platform, volume identity, and file identity. `EntrySnapshot` contains EntryId, RootId, exact relative path, Rust-owned absolute PathBuf, display_name/display_path, kind, FileStamp, observation time, and issue state. File hard-link aliases remain separate entries. `RootBinding` contains RootId, backend-owned source grant, PathBuf, evidence, and capability facts; a binding records evidence absence separately from mismatch.

`Inventory { id, generation, roots, entries, coverage, window, issues }` is immutable. `ScopeCoverage` records exact directory, **listed child names even if stat fails**, `children_complete`, `subtree_complete`, outcome, filter fingerprint, observation interval, and issues. `JobControl` owns cancellation (`Arc<AtomicBool>`) and a bounded progress sink; `Progress { phase, done, total, current_entry }` is throttled to 10/s.

Public inventory interface: `scan(request: &InventoryRequest, control: &JobControl) -> Result<Inventory, InventoryError>`. Request grants come from backend native selection/validated manual paths; inventory sources can be roots or explicit files. Child traversal never follows a link/reparse point.

Task 01 also defines read-only `DirectoryFacts` and `NamespaceSnapshot` in inventory/model.rs: exact observed parent paths/entries, per-parent case/name/length facts, filesystem capabilities, source grants, protected-root/marker policy, persisted namespace/policy epoch and capture interval. `PlatformFs::capture_namespace(grants: &GrantSet, candidates: &[PathBuf])` in Task 02 populates these data types. Their definition never imports Rename/fileops. A test adapter can supply this same data to the pure planner.


### 4.4 Tauri/JavaScript and Blueprint contracts

Task 10 exposes owned command request structs and `Result<_, CommandError { code, message, phase, item_id, operation_id, retryable }>`; serialize using camelCase consistently. Commands clone Arc-managed handles under short locks, release guards, then start blocking workers. Job types carry owned results; query responses page at 200 rows. Never keep a std MutexGuard or rusqlite Connection borrow across await.

Core commands: `select_sources(PickerKind) -> SelectionDto`, `start_inventory(InventoryRequestDto) -> JobId`, `start_rename_preview(RenameRequestDto) -> JobId`, `job_status(JobId) -> JobStatusDto`, `cancel_job(JobId)`, `rename_page(PlanRef, PageQuery) -> Page<PlanRowDto>`, `confirm_rename(PlanRef) -> ConfirmationDto`, `apply_rename(PlanRef, confirmation_nonce) -> JobId`, `operation_history(PageQuery) -> Page<OperationDto>`, `recovery_preview(OperationId)`, `start_recovery(RecoveryRef, choice, nonce)`, `start_undo(OperationId) -> JobId`. Nonces bind the current session/revision/summary and are revoked on edits. Queries do not reauthorize native paths.

All **new** commands use one owned argument named `request` (wrap multi-field cases in the corresponding request DTO) plus managed state; JS invokes them with `{ request: dto }`. Existing commands retain their prior argument shape. Task 10 adds `src-tauri/tests/command_contracts.rs` and `tests/ui/fixtures/command-contracts.json` to verify camelCase/tag/decimal-string serialization against the same golden payloads used by browser mocks. PageQuery contains cursor, limit capped at 200, display sort/filter, and expected data revision; it never changes recipe numbering order.

Common JS interfaces: `watchJob(jobId, {signal, onProgress}) -> Promise<JobResult>` cleans up timers on finish/navigation/error; `createRecipeEditor({recipe, onChange}) -> {getRecipe(), setRecipe(recipe), destroy()}` never computes filenames; `formatExactBytes(decimalString)` uses BigInt and string-safe formatting. `call()` in `ui/api.js` remains compatible with existing commands while new errors are formatted centrally.

Blueprint Task 24 owns `BlueprintStore::open(path: &Path) -> Result<Self, BlueprintError>`, collection/RootBinding revision records, and paged queries. Task 25 owns `recognize(evidence: &RecognitionInput) -> RecognitionDecision` (`Known`, `CandidateNeedsConfirmation`, `IdentityConflict`, `MarkerOnlyNoLocalData`, `Unknown`), `register`, and `rebind` with expected binding revision. Task 26 owns `begin_refresh(collection_id, request) -> AttemptId`, `stage_inventory(attempt, inventory)`, and `promote_refresh(attempt) -> RefreshReport`; promotion commits baseline scopes and observed events together.

Task 27 owns `project_events(events: &[OperationEventV1]) -> ProjectionReceipt` with EventId uniqueness and transactional cursor updates. Task 28 owns `attach_template(collection, scope, preset_id, revision, recipe_snapshot) -> AttachmentId` and `summarize_patterns(selection, baseline_revision) -> PatternSummary`. Task 30 owns `export_bundle`, `validate_import`, `import_inactive`, `prune_history`, and `remove_collection`; none grants filesystem access or accepts executable journals.

Blueprint queries return `Page<MapEntryDto>`, `CollectionSummaryDto`, `Page<ChangeDto>` with observation interval/origin/confidence and separate last-attempt/last-complete times. Its commands mirror the store operations through owned DTOs, not SQL rows. Sending cached items to Rename resolves an explicit fresh native selection and scans again; stale EntryIds are never reused.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.



## Native selected-folder root boundary carried from Task19

Task19 fix-round testing found an uncovered producer boundary, not a valid recovery test: `tests/support/crash_child::replan(root=Tree, mapping Tree -> Moved)` scans Tree's children but emits no Tree EntrySnapshot, so the helper panics before creating any plan. The current native picker uses RootBinding(path) with the same inventory producer. Task19 surviving-target proof is tested with Tree selected beneath an ancestor grant; it does not claim that fixture proves a selected item equal to its exact native grant root.

During the R18 Files/Folders/LibraryRoots producer work, explicitly verify the chosen-folder root case end-to-end, including deliberate folder-kind selection, consistent final-path preview and Rename/Move recovery when the selected folder equals its native grant root. If the scan producer needs a root EntrySnapshot, derive it from fresh native binding/evidence, preserve overlap deduplication and exact native paths, and retain complete carried descendants. Do not synthesize parent mutation grants, use lossy display paths or cached Blueprint identity as authority. Registered Blueprint roots remain guarded under25. Add a real portable producer-to-plan regression; actual native Windows picker/drop/Explorer runtime stays pending when unavailable. Read Task19 final fix report and recovery proof signatures before extending this path.

## Approved R18 and root policy wording

From the approved Rename specification:

- "Native file/folder selection, drag/drop, keyboard access; optional Windows Explorer entry point passing selected paths."
- "Shell arguments select files for review; they never trigger execution or evaluate a command string."
- "Protect configured library roots and active Blueprint markers from ordinary rename selection. Subfolders are supported; root relocation is a separate explicit rebind workflow. Never move a directory into its own descendant or create a traversal path outside an approved root/destination."

Keep ordinary folder selection distinct from configured LibraryRoots selection/protection. Blueprint24–32 is deferred until tomorrow; preserve the existing protected-policy seam without implementing Blueprint features here. The controller will provide the final reviewed Task21 commit/report and current UI reducer/selection interfaces after that gate passes. Today's last implementation task is23, followed by controller-owned Rename phase review and committed handoff; do not start24.

## Task21 integration handoff (read final report including later fix appendices)

Read sibling task-21-report.md before implementing: Task21 now owns one createRecipeEditor with setSelectionItems/excludeItems hooks and one current-ticket/revision reducer in ui/rename/main.js, strict native summary/metadata projections, explicit mapping/export commands and CPU-controlled selection/evaluation. Feed new picker/drop/argv selection through that lifecycle; old jobs/pages/nonces must remain revoked. The controller supplies reviewed final HEAD at dispatch; do not assume the initial implementation commit is the final accepted interface. Selection replacement must preserve exact backend paths/IDs and invalidate stale imported bindings explicitly rather than silently reusing prior inventory EntryIds. All new source modes must retain existing finder/libraries behavior and cancelled-picker no-change semantics.

## Controller selected-root authority ruling19

Ruling: Task22 may add narrow, explicitly selected directory-root entry authority equivalent to the existing exact-file sibling-rename boundary: a fresh native selection authorizes the selected folder and its granted subtree, and the canonical in-place rename of that exact root entry to a validated sibling name under its observed native parent. Read-only target namespace capture is not a parent grant. Require exact source identity/path, durable held-parent/source/target bindings, no-clobber and current protected-policy/epoch checks at execution; retain these constraints through compiled provenance, receipt lineage, recovery and Undo. No arbitrary sibling content access, parent metadata writes, general parent mutation grant, fabricated identity, traversal, or fresh-listing-only authority is introduced. Explicit MoveTo outside that parent still requires its existing native destination grant. Configured library roots, protected markers and carrying-ancestor guards remain authoritative; stale Blueprint identity cannot activate selection. Preserve old grant decoding/meaning conservatively if adding capability data, with checked migration only where genuinely needed. Produce the selected root as a truthful inventory item with exact native path, complete descendant/overlap evidence and actual producer-to-plan/execution/recovery/Undo tests. Reason: the approved selected-folder Rename feature cannot be implemented by a scan that omits the selected root or by a blanket candidate.starts_with(root) check that rejects its necessary sibling target; granting the parent would exceed the user's selection. Cost if wrong: a broader inventory/grant/namespace/compiler/native/recovery compatibility seam and more identity/substitution/protection/crash tests; older readers may reject new data, conservative proof failures may require re-selection/recovery review, and mistaken authority handling requires rework. Native Windows qualification remains pending and production mutation gates stay CLOSED.
