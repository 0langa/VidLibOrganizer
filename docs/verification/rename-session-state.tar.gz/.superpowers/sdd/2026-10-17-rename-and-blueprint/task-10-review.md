## Spec compliance

**❌ Issues found.** Task10 implements most of the requested vertical slice, but the stale-result guarantee, recovery-review revocation, and complete paged-query contract have current-scope gaps. **Task quality: Needs fixes.** Findings: **0 Critical, 4 Important, 3 Minor**.

Reviewed the supplied `173adc0..fce2ae2` package against the task brief and official reviewer contract. This is a task-scoped review, not complete Rename/Blueprint release approval.

## Strengths

- Native selection/grants remain Rust-owned. Selection IPC exposes grant IDs and display strings; mutation requests contain references/nonces rather than display-derived paths (`src-tauri/src/selection.rs:43`, `src-tauri/src/commands/rename.rs:172`, `src-tauri/src/commands/rename.rs:566`). The owned command macro clones AppState before `spawn_blocking`; no MutexGuard or SQLite borrow crosses its await (`src-tauri/src/commands/rename.rs:725`).
- Planner/executor authority remains in the established engines. Forward preview calls evaluate/plan, Apply consumes confirmation under a Write lease, and Undo uses fresh namespace capture followed by `plan_undo` and the ordinary confirmation/executor path (`src-tauri/src/commands/rename.rs:421`, `src-tauri/src/commands/rename.rs:566`, `src-tauri/src/commands/rename.rs:680`). Arc snapshots do not confer execution authority (`src-tauri/src/app_state.rs:113`, `crates/vidlib-rename/src/model.rs:442`).
- Forward namespace capture includes selected originals, carried unselected descendants and empty-directory listings. Real native tests cover nested and empty directory Undo plus individual-file grants (`src-tauri/src/commands/rename.rs:473`, `src-tauri/tests/command_contracts.rs:397`, `src-tauri/tests/command_contracts.rs:624`, `src-tauri/tests/command_contracts.rs:173`). Private app-data policy and ancestor-carry protection have native regression coverage (`src-tauri/src/app_state.rs:23`, `src-tauri/tests/command_contracts.rs:504`, `src-tauri/tests/command_contracts.rs:524`).
- Exact decimal revisions/counts/bytes and signed timestamps are projected without JS numeric conversion; `formatExactBytes` rejects numeric input and uses BigInt. Plan/inventory pages cap output at 200 while the full selection is planned and validated (`src-tauri/src/commands/rename.rs:368`, `src-tauri/src/commands/rename.rs:523`, `ui/exact.js:1`, `src-tauri/tests/command_contracts.rs:321`). Golden tests verify representative real Rust projections against the external browser fixture (`src-tauri/src/commands/rename.rs:818`, `src-tauri/tests/command_contracts.rs:160`).
- Existing finder command bodies/signatures are preserved in the new library, and the browser test retains sample finder search behavior (`src-tauri/src/lib.rs:25`, `src-tauri/src/main.rs:3`, `tests/ui/rename-basic.spec.mjs:13`). Test bridge/tooling stays outside `ui`; packaged UI has no mock desktop authority or JS filename transformation engine (`tests/ui/fixtures/desktop-bridge.js:1`, `ui/recipe/editor.js:12`, `ui/rename/main.js:106`).
- Factual partial results survive cancellation; computed history eligibility supports terminal Failed/Cancelled records with retained effects and suppresses active-inverse originals. Unknown legacy interruption is independently surfaced and never cleared by an empty pending list (`src-tauri/src/jobs.rs:243`, `crates/vidlib-fileops/src/journal/mod.rs:141`, `src-tauri/src/commands/rename.rs:588`, `ui/rename/history.js:12`). Recovery refs/nonces are consumed, durable Restore restricts available choices, and the existing engine rechecks matching lease/store/current evidence (`src-tauri/src/commands/rename.rs:621`, `src-tauri/src/commands/rename.rs:635`; focused unchanged-engine check at `crates/vidlib-fileops/src/recovery.rs:240`).

## Important — should fix

### I1. Delayed job-start replies can enable an older preview after a newer preview

**`ui/rename/main.js:33`, `ui/rename/main.js:37`, `ui/rename/main.js:39`, `ui/rename/main.js:68`, `ui/rename/main.js:90`.** `run()` does not set pending/busy state until `call(start_rename_preview)` returns. A second Preview can therefore start while the first start reply is delayed. Both requests capture the same edit generation, so `acceptPlan` accepts whichever result arrives last, even when that result belongs to the older plan. Generation changes on edits do not order two requests for unchanged inputs.

Focused real-Chromium reproduction, using the existing external desktop bridge and only delaying its first start reply:

1. Choose sources, select an item, enter FixedStem, click Preview; hold the first `start_rename_preview` reply after the bridge has completed the job.
2. Preview remains enabled. Click Preview again and let plan B render.
3. Release the first reply. The UI requests pages in order B (`...000002`) then A (`...000001`), enables Apply, and submits A when the user confirms.
4. The bridge's existing backend-like stale check rejects A: `appliedTargets` remains `[]`.

Observed output: `secondPreviewEnabledWhileFirstStartPending true`; `applyEnabledForOlderPlan true`; `applyRequestedPlan ...000001`; `appliedTargets []`.

This directly violates Step 4's requirement that out-of-order job completion cannot enable a stale plan. **This is a stale UI/confirmation defect, not evidence of bypassing the real backend's mutation checks.** Mark the operation pending before awaiting command dispatch, and use a monotonically ordered request token that covers start replies, terminal results, paging and confirmation. Add this delayed-start race to the browser tests.

### I2. Recovery reconciliation can republish a nonce after an edit revoked it

**`src-tauri/src/commands/rename.rs:252`, `src-tauri/src/commands/rename.rs:598`, `src-tauri/src/commands/rename.rs:617`, `src-tauri/src/commands/rename.rs:631`, `src-tauri/src/commands/rename.rs:635`.** `recovery_preview_owned` releases the Rename lock before native reconciliation, then unconditionally inserts the reviewed snapshot. Unlike inventory/preview/Undo workers, it captures and checks neither input revision nor selection generation. An `update_inputs_owned` call or native selection replacement during reconciliation clears reviews, but the old request subsequently inserts a new valid review into that cleared map. `recovery_owned` then accepts it because the stored entry has no originating input epoch.

The Recovery lease does not prevent this interleaving: `update_inputs_owned` and source replacement modify Rename state without obtaining that lease. The existing recovery engine rechecks durable/current filesystem evidence, but does not know the UI input revision; unchanged disk evidence therefore does not repair this revocation gap. The UI usually drops the late response, but the backend contract itself requires edit revocation.

Capture revision and selection generation before reconciliation, compare both under the publication lock, and retain/check the binding on consumption. Test an edit/source replacement between recovery snapshot capture and publication, asserting that the old reference/nonce cannot start recovery. This finding is based on a concrete static interleaving; no native race test was rerun or claimed.

### I3. Operation history does not implement its required PageQuery interface

**`src-tauri/src/commands/rename.rs:183`, `src-tauri/src/commands/rename.rs:588`, `ui/rename/history.js:9`.** The 4.4 contract requires `operation_history(PageQuery)` with capped limit, display sort/filter and expected data revision. The implemented `HistoryRequest` accepts only `cursor` and denies unknown fields; the response has no revision. Thus a caller using the required query shape is rejected, and bounded size/sort/filter/revision semantics are unavailable. The stable backend high-water cursor is useful and should be preserved, but it does not implement these missing fields.

Add an owned history query adapter consistent with the required interface, or have the controller explicitly revise that interface before approving the task. Extend the shared golden contract to include history request/response shapes, not just PlanRef/PageQuery and a representative row/error.

### I4. Recovery actions above 200 are truncated, with no next page

**`src-tauri/src/commands/rename.rs:629`, `ui/rename/main.js:119`, `ui/rename/main.js:120`.** Recovery returns only `preview.actions.iter().take(200)` and a total actionCount. There is no action cursor or page query, and the UI provides no way to inspect later actions, while offering Resume/Restore for the complete reviewed operation. A 201+ action recovery is permanently incomplete in the review interface. Bounding a response by truncation does not satisfy the paged-query requirement.

Keep the backend-owned reviewed snapshot and add a bounded page operation keyed by its opaque reference, with generation/revision checks; expose navigation to every action before confirmation. Add a 201+ action recovery case that can reach the last page without reconstructing native paths or renewing authority.

## Minor — nice to have / contract reconciliation

### M1. Inventory kind tags violate the new camelCase serialization convention

**`src-tauri/src/commands/rename.rs:418`.** Inventory rows serialize kind using `format!("{:?}", e.kind)`, yielding `File`/`Directory`, whereas the required new enum tags use camelCase and plan/recovery tags already do so. Use an explicit public kind enum or the same stable conversion, and include an inventory row in the golden fixture. The current UI does not consume kind, so this is presently a contract consistency defect rather than a broken interaction.

### M2. Two explicitly listed modified files have no hunk

**`.superpowers/sdd/2026-10-17-rename-and-blueprint/task-10-brief.md:12`, `.superpowers/sdd/2026-10-17-rename-and-blueprint/task-10-report.md:37`, `ui/api.js:3`, `ui/dom.js:21`.** The file list calls for modifications to `ui/api.js` and `ui/dom.js`, but neither appears in the package. The reviewer contract explicitly requires recording listed-file omissions. Focused inspection confirms that existing `call()` already normalizes structured errors and existing `el()` uses textContent; I found no missing behavior that would justify artificial edits to those files. The controller should reconcile the file checklist with the verified carry-forward implementations. This is a file-list discrepancy, not a request to duplicate those helpers.

### M3. Compressed frontend orchestration/tests make lifecycle review unnecessarily difficult

**`ui/rename/main.js:25`, `ui/rename/main.js:138`, `tests/ui/rename-basic.spec.mjs:7`, `tests/ui/fixtures/desktop-bridge.js:15`.** Several independent state transitions, listener registrations and complete test journeys occupy single long lines. This makes race cleanup and failing assertion locations harder to inspect and contributed no runtime advantage. Format these modules into ordinary statements and extract a small explicit pending-request lifecycle. The 849-line Rust module has identifiable DTO, handler and adapter sections within its assigned orchestration responsibility; length alone is not an additional blocker.

## Cannot verify from this diff / qualification limits

- Actual Windows native runtime, installed/offline desktop packaging, WebView/native-picker behavior, multiple installed instances and power-loss/hardware qualification remain **pending**, as stated in `.superpowers/sdd/2026-10-17-rename-and-blueprint/task-10-report.md:110`. Core Windows cross-compilation is not desktop runtime evidence. No release gate is approved here.
- Journal durability/WAL/FULL, platform no-replace operations, regex/probe/import limits and Blueprint persistence/marker behavior are primarily unchanged earlier/later-task responsibilities. This package preserves their interfaces but cannot independently establish all global constraints. The controller should use those owners' accepted evidence and retain final release qualification.
- Broad verification counts are implementer-reported: workspace 306 tests, Node 4, Chromium 10, lint/static checks and core Windows cross-check. I did not rerun those suites. The only new execution was the focused delayed-start Chromium reproduction above; it ran an ephemeral localhost server and in-memory bridge wrapper, without editing checkout/test files.

## Focused checks outside the packaged diff

- Named risk: unchanged `ui/api.js`/`ui/dom.js` might fail the promised structured-error and text-only rendering interfaces. Inspected `call()` and `el()` (plus surrounding definitions); the needed behavior exists. This resolves the behavioral question while retaining M2's file-list discrepancy.
- Named risk: shared Undo capture context and computed eligibility might become alternate mutation authority. Inspected `crates/vidlib-fileops/src/undo.rs:82` through the initial historical/retained-effect validation; `plan_undo` still checks terminal/unresolved state, history visibility, active inverses and retained rename receipts.
- Named risk: the recovery engine might independently revoke an edit-raced review. Inspected `crates/vidlib-fileops/src/recovery.rs:240`; it validates matching exclusive Recovery lease/store, legacy status, unchanged durable record and fresh actions, but has no input-generation binding. This confirms I2 is the desktop adapter's responsibility.

## Assessment

**Spec compliance: Issues found. Task quality: Needs fixes.** The implementation has strong native authority boundaries and meaningful filesystem tests, but the reproduced stale-preview UI race and recovery revocation interleaving require fixes, and the history/recovery pagination contracts need completion or explicit controller resolution. No backend overwrite or stale-plan execution bypass was demonstrated.
