### Task 30: Portable records, retention, and local repair

**Files:** Create `crates/vidlib-blueprint/src/portability.rs`, `crates/vidlib-blueprint/src/retention.rs`, `crates/vidlib-blueprint/tests/portability_retention.rs`; extend commands and Blueprint settings/history UI with `tests/ui/blueprint-records.spec.mjs`.

**Interfaces:** Implements 4.4 export/import/prune/remove functions and structured import-review DTOs. Export v1 contains IDs, relative native paths/observations/coverage, change records and template snapshots; no OS grants, writer locks, native absolute bindings or executable operation journals. SQLite backup/export uses a consistent read snapshot/backup API.

- [ ] **Step 1 — Red:** Add `export_while_refreshing_is_consistent`, `import_rejects_escape_unknown_envelope_and_limits`, `import_never_activates_root`, `copy_import_remaps_ids_and_references`, `prune_keeps_each_root_baseline_and_dedup_tombstones`, `remove_collection_does_not_remove_marker_or_media`, and `repair_preserves_original_db`.
  ```rust
  assert!(imported.active_root_grants.is_empty());
  assert_eq!(oversize.code, BlueprintErrorCode::ImportLimit);
  assert!(store.last_complete_scope(root_a)?.is_some());
  assert!(store.last_complete_scope(root_b)?.is_some());
  assert!(media_file.exists() && marker.exists());
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test portability_retention`; `npx playwright test tests/ui/blueprint-records.spec.mjs`.
- [ ] **Step 3 — Implement:** Bounded streaming imports (256 MiB/1,000,000 entries), strict envelope/path/reference validation, inactive candidates, explicit replace/import-as-copy review and complete ID/reference remapping. Unknown embedded recipes remain opaque inactive within a recognized envelope. Age-based pruning preserves mixed-age root/scope baselines and non-content dedup EventId tombstones needed to prevent delayed replay from resurrecting pruned history. Do not prune pending source outbox/recovery records. User-triggered local record removal and separate marker removal are distinct actions. Offer consistent backup/export and preserve corrupt/original DB before explicit repair/reset.
- [ ] **Step 4 — Verify green:** Export/import during refresh, concurrent event delivery/pruning, interrupted export, known-ID collision, invalid path codecs/limits, removal/re-registration and all baseline scopes. A deleted collection stays deleted when late events arrive; markers and media are unchanged unless their separate explicit action is confirmed.
- [ ] **Step 5 — Commit:** `feat: manage portable Blueprint records and retention`.

