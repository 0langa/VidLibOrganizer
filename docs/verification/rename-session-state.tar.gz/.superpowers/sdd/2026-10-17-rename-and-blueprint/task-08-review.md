# Task08 combined spec and quality review

## Spec compliance

**Issues found.** The implementation supplies the requested durable recovery protocol, real process-crash fixtures, reviewed native mutation authority, and current-group compensation, but explicit Restore can reverse a fully completed earlier group at a restart boundary. This violates the requirement that completed prior groups remain completed.

Reviewed package: `review-b81d868..2d708f0.diff`, base `b81d868070d5eb992f5e909c28285d2f407e79fd`, head `2d708f0a46cd94493956ed417e10fd4af65ed53b`.

## Strengths

- `crates/vidlib-fileops/src/journal/recovery.rs:38` records non-application evidence and resets the existing compiled intent in one journal transaction, without inventing a completion receipt or filesystem event. `tests/recovery.rs:490` checks the audit, preserved bytes, and absence of fake events.
- `crates/vidlib-fileops/src/journal/recovery.rs:55` separately persists inverse steps and their links; `:75` requires a durable inverse completion before marking the original compensated. Original compiled actions and receipts remain available.
- `crates/vidlib-fileops/src/recovery.rs:240` requires a matching exclusive Recovery lease, consumes non-cloneable reviewed authority, checks the current durable snapshot, and repeats reconciliation. Native mutation requests retain the expected parent identities; `tests/rename.rs:1097` tests parent replacement immediately before native handle acquisition.
- `crates/vidlib-fileops/src/recovery/evidence.rs:363` reconstructs directory namespace evidence through forward and inverse renames and checks complete listings, ownership, and unchanged material state. `:503` reuses the stamp captured with the verified listing instead of taking a newer stamp as authority.
- `crates/vidlib-fileops/src/journal/recovery.rs:14` adds separate verified-durability evidence without rewriting the original receipt. `tests/rename.rs:1175` covers the unsupported-flush gate and retained original evidence.
- `crates/vidlib-fileops/tests/support/crash_child.rs:140` and `:146` actually terminate children around native effects. `tests/recovery.rs:179` and `:362` exercise forward and inverse action gaps and event cardinality. `tests/recovery.rs:619` checks already-applied persisted phase reconciliation. Unknown creation ownership and unsupported digest algorithms remain unresolved; later copy/metadata execution is correctly left to its designated owners.
- `crates/vidlib-fileops/tests/rename.rs:1159` covers preservation of an earlier completed group during ordinary automatic compensation. The approved partial-cycle cancellation changes are consistent with the task requirement and are not a finding.

## Findings

### Important — Restore chooses a completed earlier group at durable boundaries

**Location:** `crates/vidlib-fileops/src/recovery.rs:327`, with the inverse selection at `:473` and the reset transition at `crates/vidlib-fileops/src/journal/recovery.rs:38`.

`recover` selects the restoration group using the last original step whose state is anything other than `Planned`. That includes `CompletionDurable` steps in an entirely completed group. `restore` then deliberately reverses completed steps in the selected group.

Concrete failing sequence:

1. A batch contains independent groups G1 (`a -> new`) and G2 (`b -> other`). G1's final receipt commits with `Durability::Synced`.
2. The process exits before G2's first durable intent. The operation is still `Running`, G1 is wholly `CompletionDurable`, and G2 is wholly `Planned`.
3. Reconciliation reports Completed/Planned with no unresolved group. Reviewed Restore passes validation, selects G1 at line 327, and creates inverse effects that move `new` back to `a`.

G1 was already complete and must remain factual. No interrupted effect in G2 grants authority to compensate G1. The same error occurs after recovery durably proves G2's first intent did not apply and resets it to Planned, then crashes before its next action/finalization: the reset removes G2 from this selector, causing the next Restore attempt to fall back to G1.

The existing earlier-group preservation test exercises the ordinary executor, which supplies the current group explicitly; it does not cover this restart selector. The process fixtures stop inside native calls, so they also miss the durable receipt-to-next-intent boundary and the post-reset boundary.

**Required correction:** derive/persist the interrupted group's authority across receipts, reset audits, and recovery retries, and never select a fully durably completed prior group merely because it is the last non-Planned group. Preserve the distinction between a completely durable group and a final action/receipt gap or unresolved filesystem durability; a simple blanket exclusion of all groups whose steps are CompletionDurable would mishandle unsupported-flush recovery. Add focused child-process regressions for both boundaries above, asserting G1's paths, contents, original step states, and event count remain unchanged and that G2 is not executed during Restore. Retain the current positive partial-cycle, inverse-retry, and unsupported-durability restoration cases.

### Critical

None identified.

### Minor

None requiring a separate change request.

## Cannot verify from this diff

- Actual Windows native runtime, sharing/handle/timestamp behavior, removable-hardware loss/reconnection, and hardware power-loss durability remain pending. Linux process exits, simulated path unavailability, SQL trigger failures, and Windows cross-compilation do not establish those outcomes.
- The reported 261 workspace tests, static checks, and cross-compilation results were not independently rerun; this review evaluated the assertions and implementation in the prepared package. No broad confirmation runs were performed.
- Release-wide constraints owned by other tasks, including packaging and desktop IPC integration, are outside this task diff. This is not a complete Rename release approval.

## Focused cross-interface check

Named risk: whether a completed group's receipt actually leaves a pending operation that can reach the erroneous Restore selector. Inspected only the relevant journal transitions in `crates/vidlib-fileops/src/journal/mod.rs`: `complete` at line 188 updates step completion and only changes operation state for unconfirmed durability; `pending` at line 279 includes Running operations; `set_state` at line 350 makes terminal finalization a separate transaction. This confirms the boundary is reachable and that no durable group-completion guard elsewhere in these transitions prevents the inverse. No tests or checkout mutations were performed. The prepared diff was read in sequential chunks; truncated output was recovered only for the omitted portion.

## Task quality

**Needs fixes.** The evidence/transition/orchestration split and preservation tests are sound foundations. The restart group selector is a substantive correctness defect in the task's core preservation contract and needs the focused correction above before approval.
