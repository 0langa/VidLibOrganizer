### Task 04: Durable operation journal and event outbox

**Files:** Create `crates/vidlib-fileops/src/journal/mod.rs`, `crates/vidlib-fileops/src/journal/schema.rs`, `crates/vidlib-fileops/src/journal/migrations.rs`, `crates/vidlib-fileops/src/events.rs`, `crates/vidlib-fileops/tests/journal.rs`; modify src/lib.rs and manifests/Cargo.lock. Enable rusqlite bundled/backup; add dependency on vidlib-rename.

**Interfaces:** Produces Journal, StepReceipt, OperationEventV1 and state machine from 4.3. Consumes ExecutionPlan/ExecutionStep from Task 03 and native codec; no filesystem mutation occurs in SQLite methods.

- [ ] **Step 1 — Red:** Add `intent_survives_reopen`, `receipt_and_event_commit_together`, `commit_error_prevents_next_step`, `published_copy_without_source_removal_is_distinct_fact`, `unknown_schema_preserves_original`, and exact numeric/native-path persistence tests.
  ```rust
  assert_eq!(reopened.pending()?.len(), 1);
  assert_eq!(events.items[0].phase, CompletedPhase::CopyPublished);
  assert!(!events.items.iter().any(|e| e.phase == CompletedPhase::SourceRemoved));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test journal`.
- [ ] **Step 3 — Implement:** Implement the specified local schema/PRAGMAs, checked migration transactions, explicit commit/error propagation, per-phase receipts, stable outbox IDs and pending-operation queries. Create a small private failpoint seam for commit failures; failpoints are fixture/development code, not a production IPC switch. Keep journal import impossible.
- [ ] **Step 4 — Verify green:** Journal tests against real temporary database files (not in-memory WAL substitutes); inspect effective PRAGMA values after reopen and force SQLITE_BUSY/failed commit. Confirm the original migration fixture is retained.
- [ ] **Step 5 — Commit:** `feat: persist operation intents receipts and outbox events`.

