# Task 12 implementation report

Status: DONE. Base `b338eda` (Task 11 reviewed canonical update).
Commit: `8ca48e17f1acb00bf7779a52ff2e39d1f1c03fd7` — `feat: add resource-bounded PCRE2 renaming rules`.
Worktree: `/workspace/VidLibOrganizer/.worktrees/rename-blueprint`; branch `feat/rename-blueprint` retained. No helpers/subagents, canonical edits, pushes, merges, or branch/worktree changes.

## Scope and interfaces

Implemented the real PCRE2-8 adapter in `crates/vidlib-rename/src/regex.rs`, its tests in `tests/regex.rs`, recipe/evaluator integration, and the narrow shared segment/error extension in `text.rs`. New dependency `pcre2-sys = 0.2.10` owns bundled PCRE2 10.46 (2025-08-27). Lockfile adds pcre2-sys and jobserver; cc's parallel feature adds its existing libc/jobserver dependencies. No unrelated lockfile updates.

- `RegexRule { pattern, replacement, scope: MatchScope, case_sensitive }` rejects unknown serialized fields. `RuleParameters::Regex { rule }` extends the existing tagged rule schema.
- `CompiledRegexRule::compile(&RegexRule) -> Result<Self, RenameError>` validates/compiles the pattern and validates replacements before any row can run. Invalid patterns/references are `InvalidRecipe`, including when selection is empty. Messages identify the rule on recipe evaluation/import; native pattern diagnostics include the byte offset.
- `CompiledRegexRule::apply(&str) -> Result<String, RuleIssue>` uses PCRE2's native substitution API, including its documented global empty-match retry and Unicode advancement. It returns unchanged text on a genuine nonmatch and errors on native failures.
- `RegexLimits` and `REGEX_LIMITS` expose exactly 16384 pattern bytes, 1000000 match limit, 1000 depth limit, 8192 KiB heap limit. These are the actual setter inputs, not an elapsed-time promise.
- `RuleIssue` gains `code: RuleIssueCode` and `native_code: Option<i32>` alongside its existing message/Display/Error behavior. Categories are `InvalidInput`, `RegexLimit`, `RegexNative`. `RenameErrorCode` gains the latter two categories. The existing PlanIssue contains the category, entry ID, rule ID and native diagnostic message; native numeric codes remain a structured field at the adapter boundary and are included in the row message.

Replacements support `$number`, `${number}`, `${name}`, and `$$`; `$0` is the whole match, maximal digit runs specify numeric captures, adjacent literal characters remain literal, and backslashes remain literal. All references are checked against the compiled pattern even if no subject would match. Valid optional unmatched captures expand to empty text. Duplicate names explicitly enabled by PCRE2 use the first participating named capture. Unsupported replacement syntax is rejected rather than silently interpreted as another dialect.

The adapter sets UTF/UCP, forbids `\C` (which would split Unicode scalars), never calls JIT compilation, and passes NO_JIT to substitution. Case sensitivity and First/All are explicit. The engine performs no implicit normalization or filename sanitization.

`RecipeV1::validate_and_compile_regex` validates structure and compiles every enabled expression once before the evaluator's row loop. The evaluator uses the returned map keyed by already-unique rule IDs. Import/standalone validation also checks expressions; it is a separate operation from evaluation and does not promise a process-wide cache. Disabled regexes are neither compiled nor applied. Ordered rules operate on current input.

`text::apply_segment` extracts only the shared Task 11 current-input selection/reassembly/component validation from `apply_text`. Regex calls the same helper, preserving text outside a selected range, explicit extension rules, unchanged separator spelling, original native paths and previous explanations. A failed regex blocks its row, restores the original target/name, and keeps prior explanations. Existing text behavior/serde and backend path ownership are retained. No filter dialect, JavaScript engine, frontend controls or filesystem mutation is added.

## Native ownership and unsafe contracts

All unsafe operations are confined to regex.rs and documented at their call sites:

1. NonNull RAII owners for code, compile context, match context and match data are constructed only from successful matching PCRE2 allocations, are never cloned, and free exactly once through the matching PCRE2 free function. Early returns drop every already-created owner.
2. Null general-context arguments select PCRE2's default allocator. Compile-context and match-context setters receive live uniquely owned contexts; every return status is checked.
3. Compile inputs are Rust UTF-8 buffers with explicit byte lengths; PCRE2 neither requires a terminating NUL nor retains the Rust string. Error/offset outputs are valid aligned local storage. Pattern length is bounded both in Rust and through `pcre2_set_max_pattern_length_8`.
4. Each apply allocates private match context/data. Compiled code remains alive and immutable. The match/depth/heap setters receive respectively 1000000, 1000, and 8192 (KiB). No match data/context is shared across calls.
5. Substitute receives separately allocated writable output and readable subject/replacement with exact byte lengths. OVERFLOW_LENGTH reports required capacity including NUL; allocation failure is propagated, and substitution retries with the larger buffer. Error returns do not expose partial output. Successful bytes pass checked `String::from_utf8`. Global empty-match control stays inside PCRE2.
6. Pattern-info CAPTURECOUNT writes to an aligned u32. Named lookup uses a NUL-terminated CString and two valid pointer output slots. Those borrowed code-table pointers are never dereferenced or retained. Error-message output is a valid fixed buffer, read only for the returned length.

No raw native pointers escape the adapter API. No unsafe Send/Sync assertion is introduced. The library may contain JIT support, but this adapter never creates or executes JIT code; NO_JIT is also explicit on every substitution.

## Test-first evidence and recovery

Environment refresh preserved the worktree and raw logs. Recovery inspected existing code/logs/processes rather than restarting implementation; no cargo processes were active at recovery. The recorded original native bootstrap exercised the real PCRE2 dependency before replacement/limit/integration behavior was implemented. No missing-interface compiler errors are counted as red evidence.

All logs named below are beside this report in the ignored `.superpowers/sdd/2026-10-17-rename-and-blueprint/` directory. All cargo commands run from this worktree with command-scoped environment:

```
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

1. `cargo test -p vidlib-rename --test regex` → exit 101, six behavioral failures, `task-12-red.log`.
   - `lookarounds_pattern_backrefs_and_capture_replacement`: expected `Show - S02E03 END`, actual `Show 02x03 END`.
   - `literal_dollar_and_unmatched_optional_capture`: expected `$--b-b`, actual `b`.
   - `first_all_and_case_modes`: expected `A-x-a`, actual `A-a-a`.
   - `empty_matches_progress_without_losing_nonempty_alternative`: expected `XéX🦀X`, actual `é🦀`.
   - `invalid_references_and_patterns_are_recipe_errors`: `(a)`/`$2` incorrectly accepted.
   - `resource_limits_are_real`: child expected an exhaustion error but got successful unchanged `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!`; parent reported child exit 101. This was a real result assertion, not harness timeout or compilation failure.
2. After implementing adapter, same test command → exit 0, six passed, `task-12-green-adapter.log`.
3. Added evaluator behaviors; `cargo test -p vidlib-rename --test regex` → exit 101, seven passed/four failed, `task-12-red-integration.log`. `disabled_and_repeated_rules`, `current_segments_and_explicit_extensions_use_shared_reassembly`, and `failed_regex_restores_original_target_and_keeps_prior_explanation` received existing UnsupportedRule; `invalid_replacement_is_rejected_even_without_selected_rows` expected InvalidRecipe but received UnsupportedRule. Then implemented compilation/integration through the shared current-input pipeline.
4. `cargo test -p vidlib-rename --test regex --test text --test graph --test contracts` → green 11 regex + 14 text + 40 graph + 18 contracts, `task-12-green-focused.log`. Extended subprocess coverage for actual native depth and heap exhaustion also passed with `cargo test -p vidlib-rename --test regex resource_limits_are_real`, `task-12-limits.log`. These added assertions are green qualification, not separately claimed behavioral reds.
5. Recovery self-review added replacement-boundary/duplicate-name coverage, shared invalid-component coverage and compile-count evidence. `cargo test --locked -p vidlib-rename --lib --test regex --test text --test graph --test contracts` → exit 101, `task-12-red-duplicate-name.log`. `named_optional_duplicate_names_and_adjacent_literals` failed with InvalidRecipe/unknown named reference for a valid duplicate name. Inspection of PCRE2 confirmed null lookup outputs demand a unique name. Fixed lookup to supply both pointer outputs. No expectation was changed.
6. Same exact locked scoped command after the fix → exit 0; **86 distinct tests passed** (1 unit + 13 regex + 14 text + 40 graph + 18 contracts), `task-12-green-final-focused.log`. Resource subprocess repeats its one fixture internally; that extra result line is not counted as another distinct test.

The compile-count unit test `regex::tests::evaluation_compiles_each_enabled_rule_once_for_all_rows` counts successful native pcre2_compile_8 calls via test-only thread-local instrumentation. Across three real scanned temporary files, two enabled regexes and one disabled invalid regex, evaluation produces correct names and the counter is exactly 2. It catches per-row or duplicated validation/evaluation compilation. The test is qualification of already-implemented compile-once behavior, not claimed as an earlier red. Instrumentation is absent in production builds.

The real resource subprocess tests exercise:
- Match exhaustion: `(*NO_START_OPT)(a+)+$` on 30 `a` characters plus `!` yields native MATCHLIMIT and RuleIssueCode::RegexLimit.
- Depth exhaustion: `^(a(?1)?b)$` on 600 `a` then 600 `b` yields native DEPTHLIMIT.
- Heap exhaustion: `^(a(?1)?b)` followed by 1000 empty captures and `$`, on 400 `a` then 400 `b`, yields native HEAPLIMIT.
- Pattern cap coverage accepts exactly 16384 ASCII bytes and rejects 16386 UTF-8 bytes.
The parent kills/reaps a child exceeding 15 seconds solely to diagnose a hung test. This is never described as an engine timeout. Native recursive-loop failure is also covered as RegexNative rather than a nonmatch.

Additional literal checks cover UTF/UCP word matching, lookahead/lookbehind, pattern backreferences, numeric/named captures, duplicate and optional names, literal dollars/backslashes, adjacent capture/literal boundaries, output buffer growth, First/All and sensitivity, empty Unicode matches and competing nonempty alternatives, empty input, no match, recipe round-trip, disabled invalid rules, ordered repeated rules, current segments/extensions, failed-row restoration and invalid component rejection without sanitization.

## Final verification

All checks below ran after the final production fix. No unexplained warnings/errors remain.

- `cargo test --locked -p vidlib-rename --lib --test regex --test text --test graph --test contracts` → exit 0, 86 distinct tests; `task-12-green-final-focused.log`.
- Fresh shell: `source /workspace/.tools/desktop-env.sh` then `CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace` → exit 0, **345 distinct tests passed**, no failures/ignored/warnings. Raw `task-12-workspace.log`; summing result lines gives 346 because the isolated resource child repeats one test. Includes existing engine/finder, fileops, inventory and desktop suites. Full workspace run performed once after final source changes.
- `cargo clippy --locked -p vidlib-rename --all-targets -- -D warnings` → exit 0, `task-12-clippy.log`.
- `cargo fmt --all --check` → exit 0, `task-12-fmt.log` (empty successful output).
- `git diff --check` → exit 0, `task-12-diff-check.log` (empty successful output).
- Fresh shell: `source /workspace/.tools/windows-check-env.sh` then `cargo check --locked -p vidlib-rename --all-targets --target x86_64-pc-windows-gnu` → exit 0, `task-12-windows-check.log`.
- Fresh shell: `source /workspace/.tools/windows-check-env.sh` then `cargo test --locked -p vidlib-rename --target x86_64-pc-windows-gnu --no-run` → exit 0. All five test executables linked, `task-12-windows-link.log`. They were not executed on Windows.
- `/workspace/.tools/mingw-sysroot/usr/bin/x86_64-w64-mingw32-objdump -p target/x86_64-pc-windows-gnu/debug/deps/regex-c8c8f581f920fa33.exe` → exit 0, `task-12-windows-imports.log`. Imports are Windows OS DLLs (KERNEL32, msvcrt, ntdll, USERENV, WS2_32, api-ms-win-core-synch-l1-2-0, bcryptprimitives); no PCRE2 DLL import.
- `rg 'cargo:rustc-link-lib=static=pcre2' target/x86_64-pc-windows-gnu/debug/build/pcre2-sys-*/output` → exit 0, `task-12-static-link.log`, confirms static native linkage in the Windows-target build.

## Offline native dependency mechanism

Narrow root `.cargo/config.toml` sets `[env] PCRE2_SYS_STATIC = { value = "1", force = true }`. pcre2-sys 0.2.10 build.rs checks that setting before pkg-config; when true it skips system-library discovery, compiles bundled PCRE2 C sources with PCRE2_STATIC/SUPPORT_UNICODE, and emits static=pcre2. The setting applies consistently to workspace Linux and Windows builds and prevents an inherited value from selecting a dynamic system installation. This needs a C compiler at build time, no installed script runtime or PCRE2 DLL at user runtime. Source artifacts still must be available to perform an offline development build; this task promises the offline release runtime, not a newly vendored Cargo registry.

## Self-review and qualification limits

Reviewed native lifetimes, drop paths, explicit buffer lengths, UTF invariants, duplicate-name lookup outputs, all limit units/setters, growth/error handling, empty matches, reference validation, disabled/compile-once semantics, current-input reconstruction, original-target restoration, serde compatibility, dependency direction and changed file ownership. The self-review duplicate-name bug was fixed with recorded red/green evidence. No unresolved implementation correctness concern identified; controller independent review is still required.

Changed tracked files are limited to root .cargo/config.toml and Cargo.lock, owning crate Cargo.toml, lib.rs/model.rs/recipe.rs/evaluate.rs/text.rs, new regex.rs and tests/regex.rs. All process reports/logs remain ignored and are never force-added.

Actual Windows CI/native runtime, MSVC packaged release, NTFS/exFAT/share behavior and hardware/performance checks remain pending. GNU cross-compilation/link/import evidence does not establish these. Match/depth/heap bounds are per native interpreter matching operation; output storage and total batch wall time are not represented as those limits. The 15-second deadline belongs only to the test harness. No gates are opened: Rename remains an intermediate backend slice and Blueprint remains separately incomplete.

Final staged `git diff --cached --check` passed before commit. After commit `git status --short` is empty; only ignored SDD process files remain. No canonical files were edited.
