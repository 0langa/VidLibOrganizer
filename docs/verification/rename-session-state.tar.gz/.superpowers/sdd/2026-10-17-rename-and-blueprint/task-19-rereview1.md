### Finding Verdicts

1. **Directory receipt gaps become unrecoverable after the directory leaves its old path. — ADDRESSED.** `crates/vidlib-fileops/src/recovery/evidence.rs:77` separates durable lineage/grant checks from live material observation. At `:389`, source absence selects that durable proof instead of inspecting a missing old path. Directory rename gaps verify the surviving target against the projected full namespace (`:460`, `:673`); unknown, missing and replaced children remain blockers. Absent owned-directory cleanup requires its exact creation lineage and a factual namespace with no expected descendants (`:588`). The relocated grants at `:736` are local read-only capture inputs after identity/lineage validation, not persisted or expanded mutation grants. `crates/vidlib-fileops/src/recovery/directory.rs:280` tracks planned versus live parent locations and verifies actual parent identity at the live path before compiling dependent inverses; it retains the persisted native parent identity and ordered dependencies.

   Covering tests at `crates/vidlib-fileops/tests/copy_move.rs:2190` and `:2204` exercise actual directory quarantine/removal receipt gaps and complete Restore, verify bytes/empty destination and require no pending journal. The latter reproduces the original review's 86/86/101 scenario and now requires successful recovery. `crates/vidlib-fileops/tests/recovery.rs:1109` verifies intact/unknown-child/missing-child/replacement cases and that read-only reconciliation persists no receipt. Their failures are present in `round1-red-folder-behavior.log` and `round1-red-directory-proof.log`; all named tests pass in `round1-fileops-covering.log`.

2. **Resume cannot finish a folder Move once child effects have changed the source directory stamp. — ADDRESSED.** `crates/vidlib-fileops/src/recovery.rs:413` now obtains `material()` immediately before verification and the resumed rename. This uses the named-child/full-namespace evidence while preserving the original metadata intent and existing reviewed native parent checks. Real-process regressions at `crates/vidlib-fileops/tests/copy_move.rs:2194` and `:2200` cover publication/source removal and the first removed source subdirectory. Their shared helper verifies complete source-tree removal, destination bytes, preserved original receipts and a cleared pending journal. Both tests fail with StaleState in `round1-red-folder-behavior.log` and pass in `round1-fileops-covering.log`.

3. **A hash requested only by a destination layout is computed but returned as Missing. — ADDRESSED.** `crates/vidlib-rename/src/hashes.rs:100` introduces a private computed-content cache, populated only after verified native reads (`:225`) and reset by regeneration/inventory change (`:118`, `:159`). Requested hashes are projected into the exact scope/rule owner (`:252`, `:261`), while explicit seeded values and missing decisions stay in the scoped retained-input lookup. Requested entries still pass native source verification even when explicit choices or cached values require zero content bytes (`:198`). `crates/vidlib-rename/src/template.rs:90` removes the cross-scope fallback that could leak a missing choice.

   `crates/vidlib-rename/tests/templates_hashes.rs:821`, `:906`, and `:969` cover destination-only and simultaneous naming/layout SHA256, repeat retention, one actual content read, missing choices in both directions, distinct fallback choices, seeded text isolation and source-staleness rejection. The adjusted older output-count assertion checks every requested owner; full-byte and zero-reread assertions remain. Meaningful failures are recorded in `round1-red-hashes.log` and `round1-red-seeded-revalidation.log`; all three tests pass in final `round1-rename-final.log`.

### New Breakage in the Fix Diff

- **Critical:** None identified.
- **Important:** None identified.
- **Minor:** None identified.

### Out-of-Scope Observations

- No additional untouched-code defect is raised.
- The removed selected-folder-equals-grant-root fixture did not produce a plan and is not coverage evidence. The retained namespace-proof test at `crates/vidlib-fileops/tests/recovery.rs:1109` covers a selected directory beneath an ancestor grant. The controller's Task 22 native-selection producer/coverage follow-up remains nonblocking for this scoped fix review; no broader selected-root support claim is made here.
- Native Windows runtime/sharing, MSVC, installer/offline deployment, removable/storage semantics and power-loss qualification remain pending. The fix does not touch production mutation gates; GNU compilation is not runtime evidence. Complete UI and release qualifications remain outside this range.

### Checks and Evidence

- Reviewed only the three original findings and the complete supplied 1,218-line, nine-file fix package `453d404f59eab2a9999075086a804a8f455073d7..b9b9b38dd829952e7499bcb38c63a5739cc6eec5`. Read it once in three sequential bounded chunks; no diff hunk was truncated. Used targeted symbol searches for current file:line references. Did not regenerate a diff, reread the old full package or inspect unchanged files.
- Checked the appended fix report from line 90 against the changed implementation/tests and its named logs. An initial combined red-log search emitted long diagnostic lines; a bounded follow-up recovered all relevant named failure/results. Scaffold/invalid-fixture failures were not treated as behavioral proof.
- Verified named new regressions and parent results in `round1-fileops-covering.log` (51 copy + 29 recovery), `round1-rename-final.log` (184, including 21 template/hash tests), `round1-undo-journal.log` (23 journal + 22 Undo), and `round1-desktop-file-grant.log` (1): 310 parent-level passes, no failures. Nested child summaries are excluded; benign helper entries remain included as documented.
- `round1-clippy-final.log` and `round1-windows-final.log` record successful completion. `round1-fmt-final.log` and `round1-diff-final.log` are empty. No warning/error/FAILED diagnostics were found in the final covering/static logs examined. These are existing implementer runs, not reviewer reruns. The initial 539-workspace and 4-Node/25-Chromium results are pre-fix evidence only.
- No unresolved source doubt required another executable test. No suites were rerun, no helpers/subagents were dispatched, and no checkout/index/HEAD/branch state was changed. This new report is the only authored file; the original review is preserved.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** No open finding remains from the original Task 19 review. The scoped Task 19 quality gate is **Approved**, subject to the explicitly retained later-task/native qualifications rather than a release-completion claim.
