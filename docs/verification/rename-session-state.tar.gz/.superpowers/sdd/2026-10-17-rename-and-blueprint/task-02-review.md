## Spec Compliance

- ❌ Issues found: the new seam implements the requested native primitives and preserves destination no-replace behavior, but metadata and owned removal do not consistently establish the actual poststate of the requested pathname before reporting success (`crates/vidlib-fileops/src/platform/mod.rs:586`, `:627`). These are freshness/actual-state reporting gaps in Task 02, independent of future journal implementation.
- ✅ Scope/dependencies: platform files, typed errors, platform tests, capability documentation, manifest and lock changes are present. `src/lib.rs:1` only adds module exports to the existing duplicate interface. The authorized `DirectoryFacts`/name-validation extension stays in inventory; the manifest introduces no Rename dependency or dependency cycle.
- ⚠️ Cannot verify from diff: actual Windows NTFS/exFAT/removable/SMB behavior, metadata/flush qualification, packaging/offline release behavior, and distinct sensitive/insensitive sibling-directory behavior. Windows mutation remains explicitly disabled at `crates/vidlib-fileops/src/platform/windows.rs:364`; cross-compilation and Linux's zero-test Windows binary do not establish Windows runtime support. The report correctly marks these pending.
- ⚠️ Cannot verify from diff: journal-before-mutation, persisted epoch coordination, process-termination reconciliation, and later executor grants/ownership provenance. These are caller responsibilities or later tasks; this review did not broaden into their implementations. OS flush acknowledgment is represented separately from unsupported hardware/power-loss guarantees (`docs/verification/filesystem-capabilities.md:94`).

## Strengths

- Linux rename calls `renameat2(RENAME_NOREPLACE)` without an overwrite fallback (`crates/vidlib-fileops/src/platform/linux.rs:185`). Both file and directory collision tests check retained source and destination contents; symlink destinations and arrivals after capture are covered (`crates/vidlib-fileops/tests/platform.rs:34`, `:48`, `:350`).
- Rename retains source/parent handles, verifies expected identity, checks destination poststate, and converts post-effect uncertainty into `RecoveryRequired` (`crates/vidlib-fileops/src/platform/mod.rs:248`). This is a useful model for the other mutation methods.
- Capture checks every candidate against grants before parent deduplication, retains listed names on stat failures, and records per-parent facts (`crates/vidlib-fileops/src/platform/mod.rs:327`). Staging refresh checks both the held content handle and pathname against ownership (`:528`).
- Windows mutation capability is deliberately closed (`crates/vidlib-fileops/src/platform/windows.rs:364`); the evidence matrix distinguishes native Linux tests, Windows compilation, OS flush acknowledgment, and pending hardware/runtime evidence (`docs/verification/filesystem-capabilities.md:17`).

## Issues

### Critical (Must Fix)

None established.

### Important (Should Fix)

1. **Metadata success is not bound to the requested pathname after mutation.** `crates/vidlib-fileops/src/platform/mod.rs:586` calls the native setter, then verifies only the parent binding and observes the already-open file. On Linux another process can rename `source` to `moved` and install a replacement after the source handle opens. The adapter updates the old object and returns `Ok(MutationOutcome)` even though `source` now names a different file (or is absent). A stable parent identity does not detect this. A caller could durably record a completed metadata step against the wrong path. Revalidate the child identity immediately before mutation and verify the requested child still names the held object after it; classify post-effect rebinding as `RecoveryRequired`. Add a focused deterministic replacement test at the mutation boundary.

2. **Owned cleanup can report success after unlinking a replacement and leaving the owned object elsewhere.** `crates/vidlib-fileops/src/platform/mod.rs:627` calls native removal and then checks only the parent binding. Linux removal ignores the held file and unlinks by basename (`crates/vidlib-fileops/src/platform/linux.rs:234`). If an external process moves the verified owned entry away and replaces its name between the final check and `unlinkat`, the replacement is removed and the method returns an ordinary flush outcome. Unlike rename, cleanup never examines evidence that the intended object was actually removed. The documented unavoidable check-to-unlink race does not justify silently declaring the intended removal complete. Retain/check native evidence on the held object across unlink (including link-count/deletion evidence as appropriate), inspect the resulting name binding, and return `RecoveryRequired` whenever intended removal cannot be established. If the chosen API cannot meet the promised ownership semantics, expose that limitation through the capability/result contract rather than successful completion. Cover this interleaving with a deterministic native-boundary regression test.

### Minor (Nice to Have)

1. **Windows staging-handle lifetime needs an explicit publication/cleanup contract and fixture.** `crates/vidlib-fileops/src/platform/windows.rs:414` creates staging with write and delete access, while mutation opens use `FILE_SHARE_READ` only (`:103`). Consequently, opening a staging object for publish/remove while the returned `StagingFile.file` remains live conflicts with its existing write/delete access under Windows sharing rules. The portable lifecycle test keeps that handle live through publication (`crates/vidlib-fileops/tests/platform.rs:232`), but Windows qualification does not cover this flow. Before enabling the Windows gate, either explicitly require and test closing the staging writer after refresh and before publish/remove, or design publication to consume/use the held ownership handle. This is a dormant Windows integration issue, not a claim of failed native qualification.

## Assessment

**Task quality:** Needs fixes.

**Reasoning:** The no-replace primitives, conservative platform gate, and evidence reporting are sound foundations. The two poststate gaps must be addressed so later execution/journal layers can distinguish intended completion from an action on an object whose pathname binding changed.

**Review checks:** Read the task-review contract and exact referenced reviewer template, task brief, report, and complete supplied diff in bounded sections. A focused `rg -n` lookup supplied exact finding locations; no additional whole-file reads, suite reruns, checkout/index/HEAD/branch mutations, or subagents were used. No runtime claim beyond the supplied evidence was independently established. Only this review report was written.
