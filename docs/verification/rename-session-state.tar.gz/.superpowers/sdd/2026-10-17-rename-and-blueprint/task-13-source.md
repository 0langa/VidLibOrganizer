### Task 13: Deterministic numbering and explicit dates

**Files:** Create `crates/vidlib-rename/src/numbers.rs`, `crates/vidlib-rename/src/dates.rs`, `crates/vidlib-rename/tests/numbers_dates.rs`; update recipe/evaluate and lockfile. Use chrono/chrono-tz with an explicit local-zone resolver; no locale date guessing.

**Interfaces:** `assign_numbers(entries, order: &NumberingOrder, rule: &NumberRule) -> Result<NumberAssignments, RenameError>`; `format_date(value: &DateValue, rule: &DateRule, env: &FrozenEnvironment) -> Result<String, RuleIssue>`. FrozenEnvironment records now, zone/offset, and selected ambiguity policy.

- [ ] **Step 1 — Red:** Add `natural_display_sort_does_not_change_number_order`, `counter_repeat_step_reset_and_formats`, `pad_existing_number_in_segment`, `ambiguous_date_requires_format`, `missing_recording_timezone_stays_unknown`, and `dst_ambiguity_is_explicit`.
  ```rust
  assert_eq!(alphabetic_values, ["Y", "Z", "AA"]);
  assert_eq!(repeated_values, ["01", "01", "03", "03"]);
  assert_eq!(reformatted, "2026-10-17"); // %d-%m-%Y input, %Y-%m-%d output
  assert_eq!(ambiguous.code, RuleIssueCode::DateNeedsFormat);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test numbers_dates`.
- [ ] **Step 3 — Implement:** All R06 settings and source-parent resets; checked decimal/hex/alphabetic arithmetic; original vector tie-breaks; date parsing, insert/reformat and fixed/UTC/IANA modes. Distinguish filesystem-created/modified/accessed from recording time. Resolve DST only through recipe policy; freeze now/zone once.
- [ ] **Step 4 — Verify green:** Counter/date tests, including overflow, negative step, repeat_each=0, absent file dates, and a Europe/Berlin repeated/nonexistent local time fixture.
- [ ] **Step 5 — Commit:** `feat: add stable numbering and explicit date formatting`.

