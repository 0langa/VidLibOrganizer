# Task05 — app-wide and cross-process coordination

Status: DONE_WITH_CONCERNS (implementation/available validation complete; installed Windows app/runtime qualification remains pending).

Base: `4a722e4e415faae0c6d263b927675c690a1c8616`.
Commit: `bc34cf5f00a1e236c571f5dcd3f461d5b8e28181` — `feat: coordinate collection reads writes and recovery`.

Read the supplied Task05 brief, implementer contract, Task04 report, official SDD implementer prompt, official TDD skill and writing-good-tests reference. No full-plan reread, design restart or delegated work. The controller explicitly approved the narrow legacy interrupted-write marker in operations.sqlite3 and the minimal typed-error UI compatibility adapter. No canonical checklist edits.

## Interfaces and implementation

`vidlib_fileops::coordinator` now provides:

- `Coordinator::open(app_data: &Path) -> Result<Coordinator, OpError>`; requires absolute app-data, canonicalizes it, classifies local storage, rejects linked/reparse/non-regular managed database/lock paths and initializes/upgrades the journal while holding the exclusive OS lock. Opening a current store while another lease is active uses a separate read-only connection and does not grant mutation authority.
- `try_acquire(LeaseKind::{Read, Write, Recovery}) -> Result<Lease, OpError>`; fs4 shared/exclusive, nonblocking OS lock on `operations.lock`. Each lease independently opens and owns its file handle. Lease is not Clone; it is Send for worker handoff and deliberately not Sync to prevent sharing one write authority among concurrent workers. Drop unlocks/closes the owned handle on errors/unwind. Process exit also releases the OS lock.
- `database_path()`, `blueprint_path()`, `owns_lease(&Lease)`, `has_active_writer()`. The writer counter is process-local to the shared Coordinator and supports close handling; OS locks provide exclusion across independently opened Coordinators/processes.
- `Lease::{kind, status, epochs, verify_epochs, advance_namespace, advance_policy}`. `CoordinationStatus { epochs: Epochs { namespace, policy }, pending_journal, interrupted_legacy_write }` separates the recovery causes; `requires_recovery()` combines them. These are backend-only exact u64 fields with no Serialize implementation; future IPC adapters must encode them as decimal strings.
- `begin_legacy_mutation() -> Result<LegacyMutation<'_>, OpError>` and consuming `LegacyMutation::finish() -> Result<Epochs, OpError>`, described below.

Every ordinary lease acquisition checks pending operation state and the legacy marker while holding the OS lock. Busy returns `ErrorCode::Busy` immediately at the OS lock boundary; pending recovery returns `RecoveryRequired`. Recovery acquisition is exclusive but is allowed through the persistent gate. Read leases cannot advance epochs or begin legacy effects; Recovery cannot begin a new legacy batch. Cached desktop result browsing/export remains available without a physical scan lease. New physical scans require a Read lease and are refused during writes/recovery.

Epoch comparisons use `StaleState`, unauthorized lease use uses `PermissionDenied`, and unknown/locality-unverified storage is `Unsupported`. Existing OpError code/phase/IDs/message/retryability DTOs remain the command error contract. No fabricated operation/step IDs are attached to legacy batches.

Local-storage classification is separate from media mutation capabilities: Linux accepts the known local ext-family, XFS, Btrfs, tmpfs, overlayfs and ZFS families; other filesystem families fail closed. Windows requires GetVolumePathNameW/GetDriveTypeW to identify a fixed local volume. The existing reviewed native media capability gates were not changed. Windows classification has compile evidence only.

### Operation store v3

The v1/v2 SQL and checksums remain unchanged. A checked, BEGIN IMMEDIATE v2 -> v3 migration adds:

- `coordination(singleton=1, namespace_epoch TEXT, policy_epoch TEXT, interrupted_write INTEGER)` initialized to exact decimal `0`, `0`, `0`.
- `pending_operations`, a partial state index for Prepared/Running/RecoveryRequired.

Schema identity checks recognize v3 coherently and validate the coordination singleton/epoch values. Initialization from empty and older v1 stores passes through the supported migrations. Migration failure rolls back version/schema changes and preserves existing evidence. Namespace/policy increments use checked u64 arithmetic and canonical decimal storage. Status queries read scalar values and indexed EXISTS, never reconstruct whole operations or inspection snapshots. The Task04 operation_effect_header and unfinished_steps indexes and bounded hot paths remain intact.

Every journal connection is created/used on its owning thread; effect-related marker/finalization writers live on the blocking action worker, initialization runs during app setup, and short lease-status reads use separate connections on the acquiring thread. Journal remains !Send/!Sync and is never stored in desktop state. Reader queries open separate read-only connections. Existing verified WAL, FULL, foreign_keys=ON and busy_timeout=5000 ms settings remain. Coordination transactions are committed before media work starts or after it completes; no transaction spans filesystem effects.

### Transitional legacy marker: exact meaning and handoff

The controller authorized this conservative gate to cover the existing duplicate engine until Task27 adds its per-item journal/event bridge.

1. Only an ordinary Write lease may begin a legacy batch. It rechecks recovery state and durably commits `interrupted_write=1` before calling existing fileops.
2. The actual legacy function executes outside every SQLite transaction.
3. A known return, including `Ok(ActionReport)` with partial success or a normal validation `Err(String)`, consumes the token. One transaction increments namespace_epoch and clears interrupted_write. Conservative increments on rejected/no-effect batches are intentional.
4. Panic, abrupt process death, or failed finalization does not clear the marker. Drop performs no fabricated completion and Coordinator::open never clears it. A failed actual COMMIT rolls both the increment and marker clearing back.
5. Recovery leases expose `status().interrupted_legacy_write` independently of `pending_journal`, so an empty Journal::pending() does not hide this uncertainty.

There is intentionally **no marker-clear/reset API** in Task05. Tasks08/27 must add a reviewed reconciliation/audit path, require fresh Recovery authority and advance the namespace epoch before clearing the marker. The marker has no per-item paths, receipts, actual destination facts or automatic resume/restore authority. No per-item execution journal or recovery completeness is claimed for legacy actions. Task27 owns that bridge.

Future Rename executors/policy writers must retain their exclusive lease through preflight, effects, durable completion and epoch advancement. Journal pending state provides the recovery gate if intent/receipt/epoch completion fails. Policy update orchestration remains Task25; these APIs do not implement protected-root policy itself.

### Desktop integration

`src-tauri/src/app_state.rs` owns Arc-managed Jobs, PlanRegistry and Coordinator plus operations.sqlite3/blueprint.sqlite3 paths. Tauri setup obtains those from `app.path().app_local_data_dir()`. `libraries.json` remains at the existing `app_config_dir()` location and uses the existing preferences code/lock.

`PlanRegistry` wraps the existing backend PlanStore privately. It supplies fresh session IDs and publish/current/confirm/consume/invalidate methods. Each authority-bearing operation verifies the lease belongs to this Coordinator and compares immutable plan namespace/policy epochs under that lease. Epoch mismatch invalidates the stored plan and nonce. Confirmation consumption additionally requires an ordinary Write lease. A foreign collection's lease cannot authorize a plan. Recipe/inventory/selection adapters must call invalidate when those inputs change, as required by their later tasks. No caller-supplied paths enter Apply authority.

Existing duplicate Jobs acquire a Read lease for the entire physical scan worker and a Write lease before taking action authority. Scan results capture both epochs. Other-process changes revoke old action authority while leaving cached results browsable. After a known own action outcome the remaining result snapshot adopts the current epoch only when status confirms no recovery gate. This preserves both repeated partial-success workflows and correction of ordinary validation errors without an unnecessary rescan. Uncertain outcomes retain stale authority and recovery gating. Short Jobs mutex sections never span media effects.

`jobs::run_action` wraps the existing implementation in the durable legacy token and catch_unwind. Both thread-spawn failure and worker completion drop leases. Window close now waits for every local Write/Recovery lease and signals cancellation to physical scans; poisoned Jobs state fails closed.

`ui/api.js` only normalizes structured invoke rejections into Error objects while retaining code/phase/IDs/retryability and message fields. Existing string errors and successful payloads are unchanged. Job-status errors remain readable strings and flow through the existing textContent notification path. No frontend framework was added.

The tracked ICO has one 64 x 64 representation. `src-tauri/icons/icon.png` is its faithful RGBA PNG encoding, produced with Pillow and verified pixel-for-pixel after decoding. No visual redesign. This fixes the existing generate_context! baseline and enabled actual Linux desktop test execution.

## Test-first evidence

Cargo environment for portable focused commands:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

Desktop commands source `/workspace/.tools/desktop-env.sh` and set `CARGO_TARGET_DIR=/workspace/.tools/desktop-target`. Logs below contain raw command output; all paths are under `/workspace/scratch/`.

1. `cargo test -p vidlib-fileops --test coordinator`: `task05-compile-red.log` records the missing coordinator import. This was a missing-interface compilation failure, not behavioral red evidence.
2. The same command against unguarded/no-op scaffolding: `task05-intended-red.log`, **6 failed, 2 passed**. `readers_exclude_writer`, `writer_excludes_second_process` (inside the actual child process), `startup_pending_journal_blocks_writes`, `other_process_epoch_revokes_old_plan`, `read_lease_cannot_advance_epochs` and `relative_app_data_is_rejected` all incorrectly returned Ok at their intended boundary. `panic_releases_lease` and the parent invocation of subprocess_fixture passed vacuously at this stage and are not counted as reds. `task05-green1.log` records **8 passed** after implementation.
3. `cargo test -p vidlib-fileops --test coordinator legacy` and `... failed_epoch_commit`: `task05-marker-red.log`, **three intended failures**: interrupted marker failed to survive, known outcome left namespace at 0 instead of 1, and failing epoch finalization incorrectly returned success. `task05-marker-green.log`: **11 passed** after durable marker implementation. The final failure fixture was strengthened from a statement-abort trigger to an AFTER UPDATE trigger inserting a deferred FK violation: UPDATE succeeds, COMMIT fails, epoch/marker changes roll back. Final workspace evidence covers this actual COMMIT boundary.
4. `cargo test -p vidlib-tauri jobs::tests::duplicate`: `task05-desktop-red.log`, **3 failed** with `duplicate scan bypassed exclusive writer`, `duplicate action bypassed active reader`, and `stale duplicate results retained action authority`. `task05-desktop-green1.log`: **6 job tests passed** after integration, including existing job fixtures.
5. `cargo test -p vidlib-tauri app_state::tests`: `task05-plans-red.log`, **2 failed, 1 passed**. A confirmed old plan was incorrectly consumed after another Coordinator changed policy; a Read lease incorrectly consumed confirmation. The close-handling regression passed and is not counted as an intended red. Later `cargo test -p vidlib-tauri foreign_epoch_revokes_plan_queries`: `task05-plan-query-red.log` shows old plan data still returned after another namespace epoch increment. These pass in the final suite along with a successful same-collection confirmation and rejection of a foreign collection writer.
6. `cargo test -p vidlib-tauri known_partial_action`: initial `task05-partial-red.log` revealed an incorrect fixture assumption (legacy moves select suffixes rather than rejecting ordinary name collisions). Corrected the fixture to use an existing 255-byte name whose suffix exceeds the component limit. `task05-partial-intended-red.log` then reaches the intended failure: `known own mutation must refresh remaining duplicate authority`. The real scan/move fixture proves one successful move, one issue, preservation of the existing destination, epoch 1 and subsequent action availability. `task05-desktop-focused.log`: **12 passed** at that stage.
7. `node --test tests/ui/api.test.mjs`: `task05-ui-red.log`, **1 failed, 2 passed**. Structured error rendered `[object Object]` instead of the useful message. `task05-ui-green.log` and final `task05-ui-final.log`: **3 passed**; code/phase/IDs/retryability preserved, legacy strings readable and status payload unchanged.
8. `cargo test -p vidlib-fileops --test coordinator managed_store_links`: `task05-links-red.log` shows a linked operations.lock incorrectly accepted. `task05-coordinator-focused.log`: **12 passed** after managed-path validation. The final thirteenth test abruptly exits a child after a real filesystem effect and durable marker: OS lock is released, Write is RecoveryRequired, Recovery succeeds, marker is true, pending_journal false, namespace remains 0. This explicitly avoids equating process death with completion.
9. `cargo test --locked -p vidlib-tauri known_validation_error`: `task05-validation-error-red.log`, **1 failed**, ordinary empty-selection rejection unnecessarily revoked the cached scan. Fixed finalization to refresh epochs only when live status has no recovery gate. Final desktop tests assert the exact useful status message and subsequent action availability.
10. `cargo test -p vidlib-fileops --lib journal::tests`: `task05-migration-focused.log`, **8 passed**. Added v2 evidence-preservation and migration-rollback regression fixtures, plus all existing PRAGMA/commit and bounded-work tests. The core stored-epoch behavior had already failed in round 2; preservation tests are additional regression coverage, not claimed independent red evidence.

Subprocess tests call the same compiled integration-test executable with `--exact subprocess_fixture`, passing the same temporary app-data directory through environment variables. The child independently opens Coordinator and a separate OS lock handle. They verify active-writer exclusion, reader-handle independence, epoch changes from another process and abrupt process death. The panic test was strengthened to first prove child exclusion while the lease is held, then prove another child can acquire after unwind. No subprocess tests simulate contention using only one Jobs mutex.

## Final validation

Only one full workspace test run was performed after the focused iterations:

```sh
source /workspace/.tools/desktop-env.sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace
```

`/workspace/scratch/task05-workspace-final.log`: **161 passed, 0 failed**, all doc tests successful. Breakdown: engine scan 14; fileops unit 16; duplicate actions 21; coordinator integration 13; journal integration 19; native platform 18; inventory 22; path codec 5; Rename contracts 18; desktop 15. Windows-only runtime test binary contains zero active tests on Linux and is not counted as Windows evidence. This run includes actual desktop/job tests with the native GTK/WebKit SDK and the repaired icon baseline.

Final scoped checks:

- `source /workspace/.tools/desktop-env.sh; CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo clippy --locked -p vidlib-fileops -p vidlib-tauri --all-targets -- -D warnings`: **passed**, no warnings. `/workspace/scratch/task05-clippy-final.log`. Initial dev-profile dependency compilation is retained in `task05-clippy.log`; final rerun covers the last job/error-handling correction.
- `cargo fmt --all -- --check`: **passed**, no output. `/workspace/scratch/task05-fmt-final.log`.
- Fresh shell: `source /workspace/.tools/windows-check-env.sh; cargo check --locked -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu`: **passed**, no warnings. `/workspace/scratch/task05-windows-final.log`; original compile/download detail in `task05-windows-check.log`. Fileops Windows code/tests compile; this is not a desktop Windows runtime or installed application test.
- `node --test tests/ui/api.test.mjs`: **3 passed, 0 failed**. `/workspace/scratch/task05-ui-final.log`.
- ICO/PNG decoded size/mode/byte equality assertion: **passed**, same 64 x 64 RGBA pixels. `/workspace/scratch/task05-icon-check.log`.
- `git diff --check` and staged diff check: **passed**.

The lockfile contains only fs4 and the owning package dependency additions. The incidental Cargo resolver cssparser-macros syn2 -> syn3 drift was restored before final --locked validation. Existing dependency direction remains inventory <- rename <- fileops, with desktop owning orchestration; the engine implementation was not changed.

## Self-review and pending checks

Reviewed the complete changed/new code and tests, migration checksums, lease lifetime, worker error/panic paths, partial outcomes, plan authority and UI error rendering. Corrected the two duplicate compatibility regressions with named intended reds. Kept scalar coordination queries and preserved Task04's performance indexes/tests. Confirmed Journal ownership never crosses a thread and no transaction spans media effects. Core, desktop and UI checks have no unexplained warnings or failures.

Task-owned files include coordinator implementation/integration tests; narrow journal schema/migration/status additions and migration tests; AppState/PlanRegistry; Jobs/main integration; owning Cargo manifests/lock; faithful icon PNG; minimal ui/api.js adapter and its test outside packaged ui. Preferences, native media adapters, Rename algorithms and canonical checklist remain untouched.

Pending/unavailable:

- Two installed Windows app instances contending while actual scans/mutations/recovery run; Windows OS lock runtime, fixed-volume classification, MSVC packaging and close-window behavior on Windows. No Windows runtime exists in this environment. Backend subprocess and actual Linux desktop tests are distinct evidence.
- Task08 reviewed legacy uncertainty inspection/audit/reset; Task27 per-item legacy journal/event/actual-destination bridge. Until that exists, an interrupted legacy batch remains conservatively gated and cannot be reset by opening the app. This is intentional, controller-approved transitional scope, not completed recoverable legacy execution.
- Task07/Task25 must use the epoch APIs at executor/policy mutation boundaries and retain the lease through finalization. Task10 input adapters must invalidate the registry on recipe/inventory/selection edits. No new Rename Apply or Blueprint feature is claimed here.

No push, merge, publish, branch/worktree switch or canonical checklist change was performed.
