# Task 15 fix round 1

**I1 — nested desktop request DTOs violate camelCase: ADDRESSED.**

**Fix round: All findings addressed, no new Critical/Important breakage.** New finding counts: **Critical 0; Important 0; Minor 0.**

## Finding verdict

- **I1: ADDRESSED** — `src-tauri/src/commands/rename.rs:153` now uses desktop `SelectionFilterDto` and `RowOverrideDto`; `RowOverrideDto` explicitly deserializes camelCase and converts to the unchanged core override type. `src-tauri/src/selection.rs:38` defines the filter DTO with camelCase members and strict unknown-field rejection. Its pattern/kind/field/syntax DTOs cover the multiword tags, and explicit typed conversions preserve every filter field. Exact bounds reuse the existing strict decimal codecs. Recursive omission preserves the core default, while explicit false remains false.
- **Regression evidence** — `src-tauri/tests/command_contracts.rs:1146` deserializes the literal shared fixture, checks complete/filter-only/override-only payloads, verifies converted fields and exact quantities, and asserts that portable core serialization remains unchanged. Its adjacent negative test rejects unknown fields, snake_case command members, incorrect tags, and numeric bounds. `tests/ui/fixtures/command-contracts.json:71` supplies the nontrivial shared payload; `tests/ui/rename-basic.spec.mjs:67` forwards it through the browser API and checks the request envelope and literal/exact values. The real-file preview test at `src-tauri/src/commands/rename.rs:1119` now exercises camelCase overrides plus depth, pattern, and exact-size filtering before checking old-plan revocation.

## New breakage in the fix diff

None found. The conversion changes occur before the existing select/evaluate pipeline; they do not replace native path authority, input preparation, plan invalidation, namespace capture, or publication checks. No core recipe serialization or dependency files change in this fix.

## Saved verification checked

- Reviewed the full unique `review-54d8f6d..d3fd552.diff` once: fix base `54d8f6d`, head `d3fd552ff0522ad71f6327fa2fdb74a21ec03f8e`. Read the appended fix report and official scoped re-review prompt. Scope was I1 and direct breakage introduced by the five-file fix.
- Saved red desktop evidence reports rejection of `entryId` before the adapter (`task15-logs/fix1/red-desktop.log:13`), and the saved isolated wire red names complete/filter-only/override-only failures.
- Saved covering results: 21 desktop unit tests and 23 command-contract tests passed (`task15-logs/fix1/desktop-contracts.log:28`, `:57`); 23 backend selection/mapping tests passed (`task15-logs/fix1/backend.log:30`). This is 67 distinct covering Rust tests, without double-counting preliminary focused runs.
- Saved UI evidence contains 4 passing Node tests and 16 passing Playwright tests, including shared-golden forwarding (`task15-logs/fix1/ui.log:11`, `:37`). The log has no warning lines. This satisfies the original M1/ledger Minor10 disposition for the next necessary UI run; no product fix or warning-only rerun was required.
- Saved scoped Clippy ends successfully without warnings (`task15-logs/fix1/clippy.log:2`); saved format and diff-check logs are empty as reported.
- No suites were rerun, no helpers dispatched, and no checkout/index/HEAD/branch changes were made. The only write is this report. Windows runtime and desktop platform qualification remain pending as previously recorded; the fix does not claim new Windows evidence.

## Out-of-scope observations

None.
