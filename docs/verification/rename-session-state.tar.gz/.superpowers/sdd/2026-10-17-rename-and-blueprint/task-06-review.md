# Task06 combined review

## Spec compliance

**Issues found.** The task implements the requested pure planner, identity-bound target parents, deterministic dependency groups/reservations, material freshness comparison, and protected staging policy. One Important gap remains in global final-path validation: unselected descendants carried by directory moves do not receive final path-limit validation.

Reviewed BASE `7f7d2d2a1e874183114ebcf2a5dd382c1e6e934d` through HEAD `838cb034b41d5b907f6780956c578fbf918f1a99`, using the supplied complete prepared diff package. No unrelated feature expansion or dependency-direction violation was found.

## Strengths

- `crates/vidlib-rename/src/graph.rs:19` binds destination parents before spelling changes; swaps and suffixes retain the original parent policy/identity rather than reconstructing authority from final display paths.
- `crates/vidlib-rename/src/graph.rs:431` prevents both direct and temporary descendant steps while a selected ancestor remains pending, including parked ancestors. The material-state interpreter at `crates/vidlib-rename/tests/graph.rs:892` checks observed and receipt prestates, exact receipt paths, parent mtime effects, and final locations for the reported escape shape and selection permutations.
- `crates/vidlib-inventory/src/model.rs:324` provides a narrow reservation-policy predicate while ordinary exclusion retains the canonical staging namespace. The graph separately checks reservation occupancy and native path limits.
- `crates/vidlib-rename/src/validate.rs:344` retains complete observations but compares material freshness, preserving the required access-time exception without ignoring identity, size, mtime, supplied creation time, or Windows attributes. Its comparison matches the inspected `PlatformFs::check_stamp` contract at `crates/vidlib-fileops/src/platform/mod.rs:144`.

## Findings

### Important — validate final paths of unselected carried descendants

**Location:** `crates/vidlib-rename/src/validate.rs:332`, with the selection-only loop at line 139 and carried-descendant handling at line 226; `crates/vidlib-rename/src/graph.rs:153` computes carried paths only for collision occupancy.

`validate_rows` applies `DirectoryFacts::validate_path` only to `PlanRow` targets. An unselected descendant is counted and checked for coverage, issues, and protection, but its rebased final path is never checked against its observed parent's path limit. The second validation pass after collision suffixing has the same limitation.

Concrete trigger: inventory and namespace contain directory `/media/old` and file `/media/old/child`, with complete subtree coverage. Select only `old`, rename it to `longer`, and give the observed `/media/old` directory facts a `max_path_units` limit equal to the native-unit length of `/media/old/child`. The directory's own destination passes its outer parent's limits, and the plan emits its rename with zero blocked rows. That step nevertheless carries the child to `/media/longer/child`, beyond the captured limit. An automatically added directory collision suffix creates the same problem. The existing regression `suffix_must_revalidate_descendant_path_lengths` at `crates/vidlib-rename/tests/graph.rs:617` leaves the child selected, so it exercises only the existing row-level check.

This violates Task06's global final-path/length validation and can approve a directory move that makes carried contents exceed supported path limits. A later native rename may fail or may move the directory while leaving descendants inaccessible through supported paths; checking the directory's own target at execution does not validate its carried tree.

**Fix:** After final directory targets and suffixes are frozen, resolve final paths for every carried inventory descendant, including unselected entries. Validate each against facts tied to its original parent identity, and block the responsible selected directory if required facts are unavailable or the final path is invalid. Add pure regressions with the child removed from selection for both direct directory-name growth and collision-suffix growth. No weakening of material prestates or new executor behavior is needed.

### Critical / Minor

No additional actionable findings at these severities.

## Cannot verify from diff / controller handoffs

- **Actual Windows runtime remains pending.** The available evidence compiles Windows code/tests; it does not execute UNC/share, case-sensitive NTFS, unpaired UTF16, native mutation, or installed-application behavior. No runtime qualification is inferred.
- **Native reserved-path execution and durable expected-namespace inspection serialization remain explicit Task07 handoffs.** The current pure reservation data and expected namespace provide the required inputs; this review does not treat their deferred native authorization/persistence as missing Task06 implementation.
- **End-to-end individual-file namespace capture remains an integration check.** The pure planner test at `crates/vidlib-rename/tests/graph.rs:351` preserves sibling output for an individually granted file. The existing capture producer at `crates/vidlib-fileops/src/platform/mod.rs:342` accepts candidate paths only within grants, so passing the new sibling target itself would fail. Capturing the granted source supplies the shared parent listing needed by this planner. The later orchestration must use that supported capture shape without expanding source authority; its actual caller is not part of this diff.
- Full process/session invalidation, write-lease orchestration, effect-time race checks, and recovery are later-task wiring; this diff cannot establish those release-level guarantees.

## Verification and scope

- Read the brief, task-review contract, implementer report, reviewer prompt, and entire prepared diff once. No git diff was regenerated, no helper was dispatched, and no checkout/index/branch mutation or test rerun was performed.
- Focused cross-interface inspections addressed named risks: source freshness semantics (`PlatformFs::check_stamp`), individual-file namespace capture (`capture_namespace` grant filtering/listing), native source/target validation (`move_entry`), native path-limit production (`platform/windows.rs::facts` and producer references), and the Task04 receipt-path/material authority handoff. These checks did not expand into executor implementation review.
- Existing final logs confirm 36 graph tests plus 18 contract tests passed, three protected-policy tests passed, Clippy finished without reported warnings, formatting produced no output, and the Windows cross-compile finished. These are inspected existing results, not newly executed checks. The earlier workspace run predates the final focused corrections, as the report states.
- The Important finding is established by the selected-row validation loop and the missing carried-path validation; no new executable reproduction was run under the read-only/sole-report-write constraint.

## Assessment

**Task quality: Needs fixes.** The separation of pure planning from effects, bounded scheduling progress, and material-prestate regression are sound improvements. Approval should wait for validation of unselected carried descendants' final paths.

Report: `/workspace/scratch/task06-review.md`.
