### Task 11: Text, case, extension, and segment rules

**Files:** Create `crates/vidlib-rename/src/text.rs`, `crates/vidlib-rename/tests/text.rs`; extend recipe/evaluate; add unicode-segmentation and explicit transliteration dependency.

**Interfaces:** Implements R01–R03/R10 through `apply_text(input: &NameParts, rule: &TextRule) -> Result<NameParts, RuleIssue>` and `resolve_segment(current: &str, selector: &SegmentSelector) -> Result<Range<usize>, RuleIssue>` using 4.2 semantics. Public positions are logical grapheme positions; the returned Rust Range is a checked zero-based, half-open UTF-8 byte range for safe slicing. NameParts separates stem/ext; rules produce intermediate explanations for evaluate.

- [ ] **Step 1 — Red:** Add table-driven `text_rule_goldens`, `segment_resolves_each_current_input`, `unicode_graphemes_are_not_split`, `case_exceptions_and_roman_are_explicit`, and `extension_requires_explicit_mode`. Include prefix/suffix/insert, ordered replacement, removal/range/crop, move/copy/reverse, trim/collapse, translation/transliteration, every case mode, Keep/Fixed/Remove stem, extension add/remove/replace/case, and WholeName.
  ```rust
  assert_eq!(actual.filename(), "BBC Show III.mkv");
  assert_eq!(reversed.stem, "e\u{301}faC");
  assert_eq!(ordinary.ext, "MKV"); // stem-only lowercase leaves ext unchanged
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test text`.
- [ ] **Step 3 — Implement:** Resolve grapheme/delimiter ranges, apply only within the segment, reassemble NameParts, and validate without implicit sanitization. Add transliteration only when the recipe enables it; preserve original/current fields separately.
- [ ] **Step 4 — Verify green:** Text goldens, contract tests and Clippy; test negative/zero/out-of-range positions and expanded Unicode case mappings.
- [ ] **Step 5 — Commit:** `feat: add composable Unicode text and extension rules`.

