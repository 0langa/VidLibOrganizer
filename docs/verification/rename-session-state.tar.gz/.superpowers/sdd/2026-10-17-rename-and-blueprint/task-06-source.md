### Task 06: Validate final paths and build dependency graphs

**Files:** Create `crates/vidlib-rename/src/validate.rs`, `crates/vidlib-rename/src/graph.rs`, `crates/vidlib-rename/tests/graph.rs`; extend model/evaluate; consume NamespaceSnapshot/DirectoryFacts from `vidlib-inventory::model` without creating a fileops dependency cycle.

**Interfaces:** Produces `plan` from 4.2 and an identity-based graph of ExecutionSteps/data. Native Filesystem effects stay in fileops; graph data belongs to rename. Namespace capture from Task 02 returns this shared data contract.

- [ ] **Step 1 — Red:** Add `swap_and_three_cycle_plan_without_overwrite`, `case_only_rename_uses_reserved_temp`, `parent_and_child_keep_one_location_model`, `target_parent_case_policy_controls_collisions`, `root_and_marker_protected`, `outside_destination_and_ancestor_cycle_blocked`, and `hidden_page_conflict_blocks_entire_approval`.
  ```rust
  assert!(plan.rows.iter().any(|r| r.status == RowStatus::Blocked));
  assert_eq!(plan.summary.blocked_count, 1);
  assert_eq!(final_child_path, expected_renamed_parent.join("new.mkv"));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test graph`.
- [ ] **Step 3 — Implement:** Resolve final paths globally, use per-parent name policy, derive strongly connected rename dependencies and recorded temporary reservations, update current locations when ancestors move, and expose carried-descendant counts. Validate source/destination ancestry, Windows names/lengths/ADS/device targets, grants, collision suffixes frozen in preview, and protected roots. Conflicting descendant exclusions become issues rather than impossible promises.
- [ ] **Step 4 — Verify green:** Graph tests include invalid Unicode display aliases, long/UNC paths, case-sensitive siblings, hard-link paths and target-created-after-preview preflight fixtures. Domain graph tests never write source fixtures.
- [ ] **Step 5 — Commit:** `feat: plan collision-safe hierarchical renames`.

