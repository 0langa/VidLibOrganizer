- **I1 — JSON ↔ typed authoritative synchronization: ADDRESSED.** `ui/recipe/fields.js:26` updates the mounted JSON representation after typed parameter changes. Accepted JSON updates the shared editor/history and rebinds typed controls from the accepted parameters (`ui/recipe/fields.js:80`, `:83`); `renderTyped` aborts old listeners before replacement (`:33`). The JSON textarea itself remains mounted, preserving focus/caret rather than replacing the active input. The regression alternates both representations, preserves unrelated prefix/suffix fields and exact `9007199254740993`, checks focus, and compares saved versus previewed rules (`tests/ui/rename-workflows.spec.mjs:117`). The original stale-clone overwrite no longer exists on this path.
- **I2 — Malformed lazy-regex raw retention and blocking: ADDRESSED.** `ui/rename/rules.js:78` checks the deferred controls' required object/string/boolean structure synchronously, before installing the lazy disclosure. Failed JSON acceptance retains raw text outside accepted parameters and rebuilds without unsafe parameter controls (`ui/recipe/fields.js:85`, `:45`). The existing invalid-draft mechanism therefore blocks preview/save; corrected JSON can rebind the lazy controls. The regression checks retained `{"type":"regex"}` after Add rule, absence of preview/save IPC and unsafe disclosure, disabled Apply, successful correction/disclosure, and zero page errors (`tests/ui/rename-workflows.spec.mjs:135`). Native schema/expression validity remains native responsibility; this guard does not add another filename engine.
- **I3 — Clear-selection override cleanup and selected-only submission: ADDRESSED.** Clear selection now clears `overrides` alongside selected IDs (`ui/rename/main.js:48`), and preview emission filters remaining overrides against selected opaque IDs (`:358`). The browser regression verifies both B-only preview and subsequent reselecting A have no resurrected override (`tests/ui/rename-workflows.spec.mjs:144`). The new actual-filesystem command-contract test preserves native `unselectedEntry` rejection for B plus stale A, then accepts B without the override and verifies the original file remains untouched (`src-tauri/tests/command_contracts.rs:2489`).

## New Breakage in the Fix Diff

- None found: no new Critical, Important, or Minor finding in this scoped fix review. Typed control listeners follow the parent editor lifetime (`ui/recipe/fields.js:11`, `:34`), structural edits still use the shared editor callback, and the wrapper preserves the existing grid through scoped CSS (`ui/styles.css:1736`). No native product implementation, dependency, journal, plan/nonce authority, or command contract was changed.

## Out-of-Scope Observations

- No new out-of-scope issue identified. Original M1/ledger 14 (page projection cost) and M2/ledger 06 (dense orchestration) remain deferred to final Rename triage; this fix does not close them.
- Windows runtime qualification remains pending and production gates remain CLOSED. Chromium/browser regressions and the portable command-contract test do not establish Windows WebView2/native storage/metadata behavior. This scoped approval does not replace the final broad Rename review or extend today's Rename 23 boundary into Blueprint 24.

## Checks

- Reviewed the supplied fix-only package once, from base `589087f0f5bf6515be304eb060aac11436ff8489` to head `ab4dadc02b2eb6db30af42466d700ec21c7c40ee`, against the existing task brief/contract and verbatim I1–I3. All six changed files are covered. No git commands, product edits, checkout/index/HEAD/branch changes, helpers, or test reruns were performed. Only this report was written.
- Compared the appended fix report with the changed tests and recorded output. `task21-fix1-green.log` records the three targeted browser regressions passing (4.9s); `task21-fix1-regressions.log` records 49 browser regressions passing (39.7s); `task21-fix1-native.log` records the focused actual native contract passing (one passed, 36 filtered). `task21-fix1-clippy.log` and `task21-fix1-static.log` record clean Clippy, all 19 packaged module syntax checks, formatting, and diff checks.
- Examined recorded red evidence for the original stale-values and malformed-regex failures, plus the corrected loaded I3 red in `task21-fix1-red-clear-attempt2.log`. The initial wrong-label failure and intervening port-4173 startup failure are explicitly identified as harness/scaffold failures, not product-red evidence. No unexplained warning was found in the examined final outputs. The diff raised no additional unresolved doubt requiring a focused execution.

## Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.**

**Scoped spec-compliance and task-quality gate: Approved for this fix round.** I1, I2 and I3 are closed at `ab4dadc02b2eb6db30af42466d700ec21c7c40ee`; deferred minors, separate Windows runtime gates and final Rename review remain open under their existing scopes.

Report: `/workspace/scratch/task21-rereview1.md`.
