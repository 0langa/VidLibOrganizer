# Task 14: Typed templates and lazy frozen hash/random inputs


**Files:** Create `crates/vidlib-rename/src/template.rs`, `crates/vidlib-rename/src/hashes.rs`, `crates/vidlib-rename/tests/templates_hashes.rs`; extend metadata field model/evaluate. Add explicit hash/UUID/random dependencies without changing the old engine's MD5 interface.

**Interfaces:** `render_template(parts: &[TemplatePart], context: &TemplateContext) -> Result<String, RuleIssue>`; `freeze_inputs(request: &InputRequirements, inventory: &Inventory, control: &JobControl) -> Result<FrozenInputs, RenameError>`. File I/O is a separate input-preparation stage, not inside pure evaluation; source freshness is checked before/after content reads.

- [ ] **Step 1 — Red:** Add `all_template_field_families`, `missing_required_optional_and_fallback`, `original_and_current_stem_differ`, `hashes_match_independent_full_file_vectors`, `text_recipe_reads_no_contents`, `generated_tokens_survive_repeated_preview`, and `hash_cancel_and_stale_source`.
  ```rust
  assert_eq!(optional_result, "Movie (2020)"); // no dangling resolution brackets
  assert_eq!(abc_sha256, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  assert_eq!(content_read_count_for_text_only, 0);
  assert_eq!(first.uuid_tokens, second.uuid_tokens);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test templates_hashes`.
- [ ] **Step 3 — Implement:** Template AST fields/formatters, fallback/optional behavior, exact numeric/date formatting; prepare each requested full-file CRC32/MD5/SHA-1/SHA-256/SHA-512 digest once using a bounded 1 MiB buffer and chunk cancellation. Store clock/random results in FrozenInputs. Verify all five algorithms against fixed independent known vectors, not another call to the production hash function.
- [ ] **Step 4 — Verify green:** Template/hash tests plus date contracts; compare files differing only beyond the first buffer and assert a required missing metadata property blocks the row.
- [ ] **Step 5 — Commit:** `feat: render typed templates with frozen lazy inputs`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.


## Read-only input preparation boundary

Preserve inventory <- rename <- fileops dependency direction: Rename cannot import fileops::open_verified and create a cycle. If current inventory APIs do not expose a suitable verified content reader, a narrow read-only inventory/platform handle seam or extraction is authorized as required integration, with focused tests. Reuse existing no-follow/grant/root-binding/physical-identity observations; do not fall back to blindly opening the stored absolute display/native path. Check source/ancestry binding and material freshness before/after the held-handle content read; a read-induced access-time change alone is not external material change. Parent/link/source replacement or changed content must fail closed and never freeze an unrelated source as the selected item. Keep all I/O in preparation, evaluation pure, Windows runtime checks pending, and avoid a second filesystem mutation adapter. Document the exact seam and tests in the report for review.


## Task13 date/error/model integration
Read task-13-report.md for NumberAssignments, DateValue/DateRule/FrozenEnvironment and typed LocalTimestamp civil recording times. Reuse format_date and the existing pinned format subset rather than a second date engine. A missing recording timezone stays unknown unless explicitly assumed; filesystem date fields remain distinct. New FixedOffset serialization is exact-string; old durable inspection can contain numeric offsets as raw JSON, so any new typed historical reader must accept/migrate that evidence appropriately instead of breaking recovery. The evaluator still prepares enabled regexes once and number assignments before rows. Preserve that preparation order and shared apply_segment error/restoration semantics. Narrow desktop preparation/cache wiring, if needed to connect lazy freezing and same-inventory repeated-preview retention to the actual current preview path, is authorized with focused integration tests; do not leave a duplicate or display-derived producer. Keep new requested media values missing until Task17's real producer, not guessed.

## Controller Counter ruling (provenance: preimplementation ledger)
The controller supplied this to the worker during Task14 and recorded it in progress.md before implementation; appended here during review to keep the brief self-contained. Unparameterized FieldKey::Counter defaults to stable 1-based ordinal over the explicitly frozen selected-primary vector when no explicit frozen per-entry/per-rule Integer Counter exists; retain explicit frozen values. Do not infer a binding to the first/last Number rule. The AST has no binding/config and multiple independently configured R06 Number rules are legal, retaining their own settings. Cost if wrong: users expecting configured Number inheritance need an explicit future typed binding and revised previews; no filesystem authority changes. Test default/override retention, frozen-order/selection change, nonprimary exclusion and same-inventory cache. Approved scope rule remains: selected primary vector, companions inherit/no counters, directory numbering a separate explicitly selected scope. Task14 primitive keeps explicit scope input; Tasks15/18/21 complete orchestration and Task23 acceptance.
