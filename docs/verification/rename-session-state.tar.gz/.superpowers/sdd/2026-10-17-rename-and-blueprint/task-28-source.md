### Task 28: Template attachments and descriptive Patterns

**Files:** Create `crates/vidlib-blueprint/src/templates.rs`, `crates/vidlib-blueprint/src/patterns.rs`, `crates/vidlib-blueprint/tests/templates_patterns.rs`; extend schema/query and shared editor DTOs.

**Interfaces:** Implements attach_template/summarize_patterns from 4.4. Attachment records AttachmentId, collection/optional relative subtree, preset ID/revision, immutable RecipeV1 snapshot and timestamps. PatternSummary records recognizer version, baseline/coverage revision, denominator, examples and matched rule ID.

- [ ] **Step 1 — Red:** Add `new_preset_revision_does_not_mutate_attachment`, `multiple_matching_attachments_require_choice`, `unknown_embedded_recipe_stays_inactive`, `patterns_are_coverage_qualified`, and `plain_year_or_digits_are_not_episode_identity`.
  ```rust
  assert_eq!(attachment.recipe_revision, original_revision);
  assert_eq!(recognized_episode_examples, ["Show.S02E03.mkv", "Show.2x03.mkv"]);
  assert!(!recognized_episode_examples.contains(&"Movie.2020.mkv"));
  assert_eq!(pattern.observed_count, freshly_observed_count);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test templates_patterns`.
- [ ] **Step 3 — Implement:** Explicit collection/subtree attachments, revision updates by user choice and the same Rename schema/editor. Derive extension/case/delimiter distributions and explicit SxxExx/NxNN recognizers with examples; do not infer canonical names, media identity, episode completeness or a statistical confidence score. Cache only against the exact observation/filter revision; clicking a pattern later filters its explicit examples.
- [ ] **Step 4 — Verify green:** Attachment/denominator tests across partial refresh and removed presets, suffix/Unicode filenames, non-media layouts and unsupported recipe versions. Opening a pattern/template cannot perform any filesystem mutation.
- [ ] **Step 5 — Commit:** `feat: add Blueprint template attachments and pattern summaries`.

