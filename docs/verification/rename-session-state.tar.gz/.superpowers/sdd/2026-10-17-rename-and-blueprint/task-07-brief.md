# Task 07: Journaled in-place rename execution


**Files:** Create `crates/vidlib-fileops/src/rename.rs`, `crates/vidlib-fileops/tests/rename.rs`; extend platform/journal/events; export execute from src/lib.rs.

**Interfaces:** Implements execute from 4.3 for in-place rename graph groups, consuming the exact approved PlanRef/source snapshots, Write lease, Journal and Filesystem. It emits receipts/events, never generates target names at runtime.

- [ ] **Step 1 — Red:** Add `executes_exact_reviewed_plan`, `late_stale_item_changes_nothing_in_preflight`, `no_runtime_collision_suffix`, `all_graph_steps_have_prior_durable_intent`, and `failed_group_stops_following_groups`.
  ```rust
  assert_eq!(std::fs::read(&expected_target)?, b"fixture");
  assert!(!unexpected_suffix.exists());
  assert_eq!(recorded_intents_before_actions, executed_step_ids);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test rename`.
- [ ] **Step 3 — Implement:** Whole-selection preflight, then per-step identity/ancestor/freshness checks and no-replace execution under the writer lease. Flush intent before action and completion after; stop on journal or filesystem error. Retain unresolved steps and invalidate path-dependent results before releasing the writer. Avoid broad refactors of old duplicate actions.
- [ ] **Step 4 — Verify green:** Rename tests on real temporary files and fault-injection adapter; Windows tests for sharing violations and timestamps. Cancel at deterministic group boundaries; assert completed groups are reported honestly.
- [ ] **Step 5 — Commit:** `feat: execute reviewed rename plans with durable receipts`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


### 4.3 Execution, journal, events, and coordination

Task 04 owns Journal, StepReceipt, event/state persistence and `Journal::open(path: &Path) -> Result<Journal, OpError>`, `begin(&mut self, plan: &ExecutionPlan) -> Result<OperationId, OpError>`, `intent(&mut self, op, step: &ExecutionStep) -> Result<(), OpError>`, `complete(&mut self, op, receipt: &StepReceipt) -> Result<(), OpError>`, `pending(&self) -> Result<Vec<PendingOperation>, OpError>`, `events_after(cursor, limit) -> Result<EventPage, OpError>`, and `ack_events(&mut self, ids: &[EventId]) -> Result<(), OpError>`. ExecutionPlan/ExecutionStep are imported from Rename's pure model, not redefined. A connection is opened/used on its owning blocking thread; read queries use separate connections. Set/verify WAL, FULL, foreign_keys=ON, busy_timeout=5000 ms; migrations/intent/receipt transactions use BEGIN IMMEDIATE and explicit commit. No SQLite transaction spans filesystem I/O.

Own schema: `schema_migrations`, `operations`, `steps`, `receipts`, `operation_events`, `outbox_ack`, `history_visibility`; Task 25 adds protected-root policy tables. Each step stores full native path codec, expected prestate, object/temporary ownership, group/sequence, and observed poststate; plan/recipe inputs are stored for inspection but recovery uses the compiled steps. State machine: Prepared -> Running -> Completed / Cancelled / Failed / RecoveryRequired; steps Planned -> IntentDurable -> Applied -> CompletionDurable, or Compensated/Unresolved. Applied is the observed in-memory action state until its receipt transaction commits; a restart without that receipt follows reconciliation, not a fabricated durable flag. SQLite commit failure stops the next filesystem step.

`ExecutionStep` variants cover RenameEntry, CreateDirectory, StageCopy, PublishCopy, RemoveSource, SetMetadata, RemoveOwnedCopy, and RemoveOwnedEmptyDirectory, with exact expected states. `StepReceipt` records actual paths/identity, digest when applicable, metadata, completed phase, and durability result. Store intent before action and receipt after action; reconcile the action/receipt gap by identity, not blind retries. One dependency group is the compensation unit; completed prior groups remain completed.

Rename-cycle temporary names are logical reservations recorded in the graph/journal; the first no-replace move materializes the path atomically. Do not create an empty placeholder and then overwrite it. Copy staging uses create-new ownership with a recorded native identity, and publication still uses no-replace semantics.

`OperationEventV1` contains stable EventId, OperationId, GroupId, StepId, kind, completed phase, native before/after paths, before/after FileStamp, digest if available, observed time, `origin: App`, and journal sequence/provenance. Emit facts for each completed phase, including a verified published copy whose later source removal fails. Events and receipts commit together. Imported reports never become executable journals.

Task 05 owns `Coordinator::open(app_data: &Path) -> Result<Coordinator, OpError>` and `try_acquire(kind: LeaseKind) -> Result<Lease, OpError>` with RAII Read/Write/Recovery leases. Use Tauri's `app.path().app_local_data_dir()` for the two databases and lock file, validate local storage, and retain the existing app_config_dir libraries.json location. Use a per-app-data OS advisory lock file (shared readers, exclusive writer), plus process-local job registry and startup pending-journal gate. A recovery lease is exclusive but may enter RecoveryRequired state. No destructive job bypasses it, including legacy duplicate actions. A second instance cannot write to this app data concurrently. Denied acquisition returns Busy/RecoveryRequired, not a blocking UI wait.

The operation store also owns a monotonic namespace/policy epoch. Read/capture it under a read lease, store it with the plan, and compare again inside the write lease before preflight. Increment it after any app path mutation or protected-root policy update, including partial success, before releasing the lease. Read queries/registries use it to revoke stale results across app instances. An intent/receipt failure leaves the recovery gate active rather than authorizing a stale plan. Blueprint root registration cannot retroactively permit an older plan to rename a newly protected root.

Task 07 owns `execute(plan: &RenamePlan, lease: &Lease, journal: &mut Journal, fs: &mut dyn Filesystem, control: &JobControl) -> Result<OperationReport, OpError>`. The real Windows and Linux adapters and fault-injection test adapter implement `Filesystem`: capture/verify state, no-replace rename/publish, owned directory/staging creation, verified content I/O, metadata changes, and flush results. `OpError` has stable code, phase, operation/step/item IDs when known, message, and retryability; UI receives a serializable DTO, not a panic/debug dump.

Task 08 owns `reconcile(op: &PendingOperation, fs: &mut dyn Filesystem) -> Result<RecoveryPreview, OpError>` and `apply_recovery(preview, choice: Resume | Restore, lease, journal, fs, control) -> Result<OperationReport, OpError>`. Task 09 owns `plan_undo(completed: &OperationRecord, namespace: &NamespaceSnapshot, version: PlanRef) -> Result<RenamePlan, OpError>`; inverse operations use the same executor/journal/confirmation flow.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.


## Task03 integration carry-forward

Task06 resolved the earlier deferred grant-snapshot consistency finding: PlanStore::publish now rejects divergent duplicated grants as well as frozen inputs. Preserve that single authority snapshot. Task06 also tests deterministic graph/DTO construction from identical frozen inputs (apart from the supplied PlanRef). Task10 owns actual fresh process sessions and invalidation on inventory/recipe/selection changes; pure PlanStore alone does not establish that wiring.

## Task04 compiled-step handoff

Task04 corrected the initial Task03 action model to the eight section4.3 variants with action-specific native fields. Read task-04-report.md for EntryPrestate/ExpectedIdentity/OwnedEntryPrestate, private persistence and exact Journal APIs; do not reintroduce flattened dummy source fields or duplicate ExecutionStep in fileops. References resolve to committed poststates of earlier steps in the same group or declared dependencies; owned compensation stays in its dependency group. Task09 must validate historical receipt/identity/digest ownership for undo through the same journal/executor and may extend the typed inverse data as its plan specifies; current-operation receipt references alone do not establish historical undo authority.

Task04 review boundary: Task07 remains in-place rename only. The initial StageCopy data is not a complete partial-copy ownership protocol; copy effects stay unavailable until Task19 adds individually journaled staging creation/streaming phases with identity durable before streaming. Task08 owns durably resolving proven non-application without fabricating a completion receipt. See those briefs for concrete protocols.

## Task05 coordinator/registry handoff

After review clears, read task-05-report.md for Coordinator/Lease/Epochs/PlanRegistry APIs and schema v3. Lease is Send for worker handoff, !Sync and not Clone; Journal remains thread-owned !Send/!Sync. Hold the appropriate lease through all physical work and durable finalization. CoordinationStatus distinguishes pending_journal from interrupted_legacy_write; an empty Journal::pending() does not erase legacy uncertainty. Epoch values are backend u64 data without Serialize; any new IPC must use exact decimal strings. PlanRegistry validates coordinator ownership and namespace/policy epochs under a lease; consume needs ordinary Write. Task10 still owns inventory/recipe/selection invalidation. Native installedWindows/runtime remains pending.

## Task06 expected-namespace handoff

Native swap integration exposed an exact-unit producer defect in graph::relocate: target.join(empty_relative) adds a trailing separator to a moved root's later FromReceipt source. Path equality masked it, while Journal correctly rejects the unequal NativePathRecord. Task07 owns the narrow prerequisite correction (exact moved root returns target.clone(), descendants join only nonempty suffix) and an exact-native-unit pure regression plus the real swap regression. Do not weaken Journal receipt-path equality or broadly refactor the graph. Include the correction in Task07's report/review package.

Read task-06-report.md for final pure planner/preflight interfaces and compiled-step scheduling behavior. ExecutionPlan now owns expected_namespace (all native entries/parents, DirectoryFacts.stamp, grants, name/case/capability policy, guarded/excluded roots and epochs). Task07 must preserve this read-only snapshot alongside inspection provenance through a checked compatible journal migration/private codec; Task06 intentionally did not alter journal serialization. Round-trip exact native units and quantities. Persisted inspection is not restart mutation authority: Task08 still reconciles compiled effects against fresh evidence. Use validate::preflight with a fresh capture under the matching ordinary Write lease before any effect, then retain per-step native no-replace/identity checks. Directory and entry freshness ignore access time consistently with the existing material Fs comparison.

Preserve Task06's individual-file grant case in native preflight/execution: only the selected file may rename to an absent sibling name in its original parent. Current capture_namespace classifies each candidate with candidate.starts_with(grant.path), so blindly submitting that new sibling target rejects a file grant. Supply a valid same-parent capture representative or make a narrow tested read-only capture adaptation; do not widen sibling source authority, rename the parent, or infer grants from display strings. Test the native one-file success and unrelated-sibling refusal.

Task06's reviewed carried-tree validation needs original parent facts for unselected descendants too. Namespace preparation/recheck must include those observed parents for any selected directory move, using native inventory/grants; selected rows alone are insufficient. Do not fake limits, omit unselected contents or weaken the fail-closed missing-facts validation. A representative descendant path can request its original containing-parent facts through the existing capture contract.

## Native cycle-temporary integration check

The broader native regression run exposed an additional concrete Task06 policy interaction: old PlatformFs::permit_staging removed STAGING_NAME_PREFIX from configured prefixes before calling excludes, but excludes now correctly protects that canonical prefix unconditionally. This breaks existing legitimate owned-copy creation/publication/removal tests. Task07 owns the narrow compatibility repair to explicit internal staging authorization, retaining marker/guard/protected-root/custom-prefix checks and refusing the dedicated rename-reservation namespace for ordinary copy staging. Keep normal exclusions intact and keep ownership/material-state native checks. Add focused boundary regression and rerun the failed broader suite. This is preserving the existing platform interface, not enabling Task19 copy execution or changing the deferred Windows writer-sharing lifecycle.

Final Task06 interface: shared `vidlib_inventory::RENAME_TEMP_PREFIX` is `.vidlib-staging-rename-`; names use the frozen EntryId and deterministic reservation ordinal. `ProtectedPolicy::allows_rename_reservation` is only a pure path-policy predicate, not an execution permission token. Task06 now protects ordinary selection/inventory/output from these names and preserves extra prefix/marker/guard exclusions. Consume this shared predicate rather than recreating its policy logic; native use still requires the exact compiled operation reservation and durable receipt lineage.

Concrete current producer/consumer boundary: platform/mod.rs rename_no_replace calls permit(source) and permit(target), which reject the canonical staging prefix through ProtectedPolicy.excludes. Task06 records logical cycle temporary reservations under that namespace. Task07 must integrate narrowly scoped internal reservation authority so those exact reviewed steps can materialize/use their recorded temp paths atomically, while ordinary/unowned staging paths, protected roots and markers remain refused. Do not globally remove staging policy or create/overwrite placeholder files. Keep the platform seam independent of Rename recipe/step types; preserve expected identity and journal-owned reservation/receipt provenance. Add real native swap/case-temp coverage and an unowned-temp refusal regression before enabling the path.
