# Rename phase broad review — working notes (not final verdict)
Range 711b422..f7595687788376343c1c8067e6b03167dde0b200. Read-only checkout. Supplied package only; no test reruns or helpers.

Read review contract, phase brief, current 16-item index, approved Rename + overview, Rename tasks/shared contracts, verification, 20 ruling paragraphs, Task23 review and handoff sections (rulings duplicate not reread). Native Windows gate remains closed. Future Blueprint24–32 excluded as implementation, current protections in scope.

Pass coverage so far: supplied diff 25990–28316: all inventory production source (content pins, exact quantities, IDs, model/policy/name semantics, codec, Unix/Windows no-follow inventory adapters, scan/coverage).
- Strength: exact paths/IDs separate display; root/content binding checked through held ancestry; helper Windows denies source write/delete and ancestor delete, Linux proc-fd; content freshness ignores volatile atime only.
- Deferred01 persists at scan.rs seen_directories branch: cloned scope switches root_id/relative_directory but copied issue.relative_path stays old root-relative. Presentation/coverage diagnostic defect; namespace paths remain native. Need disposition/report ref.
- Deferred16 consistent with JobControl 100ms throttling; metadata test not yet inspected.
- Inventory dedup shallow roots deterministic, distinct hardlinks retained. Native selected folder emits root entry then descendants; legacy root scan excludes root. Protected markers/staging skipped, listed-name coverage preserved.

Open interface checks: authority and epochs from selection->namespace->plan->executor; per-step inverse and factual prestate; R01–18 UI/read-only evidence.
