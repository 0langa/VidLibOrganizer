### Finding Verdicts

1. **Remaining original finding 2: Restore adopts changed controlled access time after a durable quarantine receipt — ADDRESSED.** `crates/vidlib-fileops/src/recovery.rs:598` derives the controlled fields from the original source lineage. For constrained objects, `:604` now resolves an EntryPrestate through `FromReceipt { step_id: original.step.id }` using the field-aware material resolver. The new inverse therefore receives the durable expected poststate instead of a generic live accessed-time refresh. Generic operations retain their previous behavior, and the existing named-child-effect directory exception remains in the field-aware resolver.

   `crates/vidlib-fileops/tests/metadata_actions.rs:1974` adds the missing committed-receipt crash case. Before editing accessed time, `:2006` asserts that the rename is CompletionDurable with its Renamed receipt while cleanup is Planned with no receipt. Changed-state Resume and Restore both refuse, preserve the surviving copy and external timestamp, preserve the original receipt, and append no recovery inverse based on the changed value (`:2072`). Unchanged cases still complete. The crash seam at `crates/vidlib-fileops/tests/support/copy_faults.rs:312` terminates the actual child during the next historical-digest check; the parent's persisted-state assertions establish the intended boundary rather than assuming it from the hook's name.

2. **New Important from round 1: path-or-physical-ID lookup selects an unrelated occupant at an occupied future target — ADDRESSED.** `crates/vidlib-rename/src/validate.rs:523` records preceding canonical rename effects. At `:544`, preflight reverses those effects to locate the constrained object's currently observed path, including cycle reservations and ancestor carries. Both entry lookup (`:558`) and parent-facts fallback (`:566`) now require that resolved path **and** the expected physical ID. An unrelated current occupant of the future path can no longer win the lookup, and missing physical identity is rejected.

   `crates/vidlib-fileops/tests/metadata_actions.rs:2091` executes a real directory swap with distinct modified/accessed Increment values, then executes Undo and checks original paths, native identities, original timestamps, and payload bytes. Its supplemental parent-facts-only preflight case verifies the fallback and rejection of an edited controlled accessed time without using the altered test snapshot to authorize filesystem effects.

### New Breakage in the Fix Diff

- None established: no new Critical, Important, or Minor finding. The two product changes remain confined to receipt-derived restoration authority and canonical path resolution at preflight. No schema, dependencies, native mutation gate, or transaction/I/O boundary is changed.

### Out-of-Scope Observations

- None newly raised. Prior findings 1, 3, and 4 remain closed and were not re-reviewed. Previously indexed Minor13 remains controller-owned final Rename triage, not a condition of this fix round.

### Checks and Evidence

- Read the complete 476-line supplied fix package once, in sequential passes: BASE `692fa34c154319f858827a15a9530d00cda427fb` to HEAD `d78cba7e21b2f49b3eeaaebd75a3c0b0ef1bad91`. Applied the official scoped re-review contract, the same Task 20 brief/Ruling18, and the appended round-2 report. No additional cross-interface code read was necessary beyond the already reviewed resolver contracts and supplied fix context.
- Inspected the claimed red/final evidence. `fix2-red.log` records the two intended assertion failures (35 passed, 2 failed); both named tests are green in `fix2-covering.log`. Its summaries support 460 passing parent-harness tests: fileops 276 and rename 184, with the regex helper's separate success excluded from that total. The final covering, Clippy, and Windows compile logs contain no warning/error/FAILED diagnostics. No suite or focused test was rerun.
- No helpers, git commands, checkout/index/HEAD/branch changes, or writes other than this report. No independent native Windows runtime result is claimed: GNU all-target compilation remains compilation evidence only. Windows runtime/precision/sharing/read-only behavior, MSVC, packaging/offline deployment, removable storage, and power-loss qualification remain pending; production gates remain CLOSED.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** Both cases under verification are closed. This approves the scoped Task 20 round-2 fixes; it does not open native Windows or release gates, clear Minor13, or authorize Blueprint work.
