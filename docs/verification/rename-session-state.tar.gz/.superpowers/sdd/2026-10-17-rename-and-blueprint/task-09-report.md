# Task09 — validated inverse plans and bounded operation history

Status: DONE. Implementation base: `e9dfbc92aa45b0c5c6fb29a90d9205f28b0bc241`. Work is confined to `/workspace/VidLibOrganizer/.worktrees/rename-blueprint`; no canonical checklist edits, branch/worktree changes, push or merge. The controller supplies independent review.

## Interfaces and integration

- `vidlib_fileops::undo::plan_undo(completed: &OperationRecord, namespace: &NamespaceSnapshot, version: PlanRef) -> Result<RenamePlan, OpError>` is a pure inverse planner. It uses original retained `CompletionDurable` rename receipts and exact original native entry paths; recovery inverse rows remain separate facts. It selects completed earlier groups even if the terminal batch state is Failed/Cancelled and rejects pending/unresolved or fully compensated operations. Unsupported copy/metadata phases remain with Tasks19/20.
- `RenamePlan`, `RenamePlanDto`, and `ExecutionPlan` now carry `inverse_of: Option<OperationId>`. Normal graph plans use None. PlanStore and the executor verify agreement. The inverse uses the existing graph compiler for all selected rows, collisions, native policies, ancestry, cycles, logical temporary reservations, and exact target paths. Changed/missing source material or recreated originals produce blocked preview rows. Reconfirmation and execution use existing PlanStore / executor APIs; no second undo mutation engine exists.
- Historical ownership is checked against the **live original operation** inside the Journal begin transaction. For an inverse, begin loads original receipts, compensation states and history availability, recompiles the canonical inverse against the reviewed namespace, and requires exact groups/dependencies/compiled steps. An arbitrary target or stale history snapshot cannot confer historical ownership. Current-operation FromReceipt references continue to serve later cycle steps only; they are not claimed as historical authority. No filesystem I/O occurs inside this transaction.
- Schema v7 adds `operation_inverses(operation_id, original_operation)` and an original-operation index, with its own checksum and transactional migration. Existing v1–v6 SQL/checksums are unchanged. The inverse link is also present in the private inspection snapshot. Older schema-v6 readers reject v7. Migration does not invent links or rewrite original receipts/events/recovery scope.
- `OperationRecord` remains the backend-only PendingOperation alias, adding `inverse_of`, `history_visible`, and `active_inverses`. Pending inverses and inverse operations with retained completed original steps prevent duplicate Undo of the same original. Fully compensated inverse recovery ceases to block a fresh retry. Original receipt rows remain factual and unchanged.
- `Journal::history(cursor: Option<HistoryCursor>) -> Result<HistoryPage, OpError>` uses a separate read-only SQLite connection and transaction. It returns at most 200 lightweight `HistoryItem`s in operation insertion order, with operation ID/state, inverse link and factual completed-original-step count. A high-water mark plus rowid keyset cursor excludes later inserts and avoids shifts when earlier history is removed. It does not hydrate inspection/receipt payloads for every row. Cursor bounds and counts serialize as exact decimal strings; no new native paths cross the DTO boundary.
- `Journal::remove_history(op) -> Result<(), OpError>` is explicit removal of completed history visibility and eligibility for new Undo. Pending/unresolved operations return RecoveryRequired. This policy retains the execution ledger, receipt facts, recovery audits, inverse lineage and outbox acknowledgments/events. It is **not physical evidence purging or automatic storage retention**. Removing original completed history while its inverse is pending leaves that inverse recoverable; acknowledgments/removals for original and inverse events remain independent. Missing legacy visibility rows mean hidden/no new Undo, not missing recovery evidence.
- Fresh namespace capture must carry the historically transformed grants and current coordinator namespace/policy epochs. As with existing execution, the PlatformFs used at execution carries those current epochs. The caller captures all affected directory children/subtrees. Original file grants remain narrow; namespace paths are backend native data, never reconstructed from display strings.

## Namespace evidence and retained work

Crate-private recovery helpers now expose exact-path rebase, original/recovery parent-identity mapping, and extracted `transformed_namespace` evidence. The existing recovery verification uses that same extracted transformation without changing its behavior. Undo verifies original plus compensation factual moves before using a fresh directory stamp. It checks complete historical/fresh child sets, kinds, physical IDs, material freshness and unchanged creation/attribute fields; directory size/modified changes are accepted only for proven owned child namespace effects. Every carried directory requires a historical complete listing. A current complete scan cannot replace missing historical subtree evidence.

The inverse compiler can restore a parent and renamed child together while retaining reviewed parent identities through the normal held-handle native APIs. Unknown children, changed child material, missing historical nested listings, replaced parent identities, and new original-path occupants block the preview or executor preflight. The later executor re-capture also prevents a previously approved preview from overwriting a newly recreated original. No unbound native rename path or Windows mutation gate was added.

Terminal cancellation with completed G1 and untouched G2 offers only G1's inverse; fully compensated originals keep their receipts/audit facts but offer no Undo. An interrupted Undo is an ordinary pending operation with its own compiled inverse steps, namespace and durable intents. Existing reconciliation Resume/Restore handles it, including native action/receipt gaps and cycle reservations; it does not need original history to remain visible.

## Test-first evidence

All bare Cargo commands below used this command-scoped SDK environment:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

No missing-interface compiler error is counted as a behavioral red. Initial public scaffolding deliberately returned Unsupported/empty history/permitted removal so the assertions could execute; it is fully replaced. A subsequent intermediate implementation compile failed on rusqlite's lack of u64 FromSql and was corrected to SQLite i64 conversion; that compiler error is also not counted as red.

1. Named initial tests, before behavior implementation:

```sh
cargo test --locked -p vidlib-fileops --test undo
```

`/workspace/scratch/task09-first-red.log`: six intended failures:

```text
undo_requires_current_poststate ... FAILED
recreated_original_blocks_inverse ... FAILED
interrupted_undo_is_recoverable ... FAILED
unfinished_history_cannot_be_removed ... FAILED
history_pages_are_stable ... FAILED
inverse_executes_through_confirmation_and_preserves_facts ... FAILED
history_pages_are_stable: left: 0, right: 200
unfinished_history_cannot_be_removed: pending evidence must stay visible and retained
undo_requires_current_poststate: undo must produce a reviewable blocked plan: Err(... "undo not implemented")
test result: FAILED. 1 passed; 6 failed
```

The first removal/outbox test was vacuous under scaffolding and was not counted as red. It was immediately strengthened to require visible/undoable completed history before removal:

```sh
cargo test --locked -p vidlib-fileops --test undo removing_completed_history
```

`/workspace/scratch/task09-removal-red.log`: one intended assertion failure, visible history length 0 versus 1. After implementation, the same overall command passed **7/7** in `/workspace/scratch/task09-first-green.log`, including meaningful blocked-row assertions, pending-removal RecoveryRequired, stable 200-row paging, actual cycle Undo, and recovery of a real native rename gap.

2. Additional hierarchy, retained-group, compensation, authority and outbox coverage:

```sh
cargo test --locked -p vidlib-fileops --test undo
```

`/workspace/scratch/task09-hierarchy-first.log`: **14/14 passed**. These are additional coverage, not falsely represented as new failures. `parent_child_undo_uses_complete_transformed_namespace`, `unknown_child_or_changed_material_blocks_directory_undo`, `cancelled_operation_retains_undo_for_completed_earlier_group`, `compensated_original_receipts_do_not_offer_another_undo`, `historical_authority_is_rechecked_at_begin`, `newly_created_original_after_preview_cannot_be_overwritten`, and `original_and_inverse_outboxes_survive_independent_history_removal` exercise actual files, SQLite and native adapters.

3. Actual process-crash/migration coverage:

`/workspace/scratch/task09-crash.log`: **18/18 passed**. `undo_crash_child` uses the existing test-only CrashFs adapter and real PlatformFs, Coordinator and Journal. Parent tests assert process exit code 86 before/after the first inverse native cycle move, reopen the database, remove original history while the inverse is pending, and recover through existing Resume. Files regain exact original content and six original/inverse events survive both history removals. These are real process exits without destructors, not mocked Result failures. `v6_history_migrates_without_inventing_inverse_authority` and `failed_v6_inverse_migration_retains_original_evidence` cover real SQLite success/rollback with retained receipts/events/evidence.

4. Deterministic preview correction:

```sh
cargo test --locked -p vidlib-fileops --test undo inverse_preview_keeps
```

`/workspace/scratch/task09-determinism-red.log`: one intended failure, unselected namespace entry IDs differed across the same receipt/namespace/version. Replaced random IDs with deterministic native-path-derived IDs; selected sources retain their historical IDs. Graph validation still rejects duplicate IDs. `/workspace/scratch/task09-focused.log` includes the corrected green test.

5. Interrupted Undo Restore:

```sh
cargo test --locked -p vidlib-fileops --test undo interrupted_undo_restore
```

`/workspace/scratch/task09-inverse-restore.log`: one parent test passed after an actual child exit 86. Existing Restore compensates the incomplete inverse group, preserves original receipts, yields five original/inverse/compensation events, removes active-inverse eligibility blocking, and permits a freshly captured retry. This is added coverage of the reused recovery engine, not a separate undo implementation.

6. Final self-review and broader-suite corrections:

The first workspace run `/workspace/scratch/task09-workspace.log` failed three existing unit tests: `journal::tests::effect_writes_operation_header_only_on_state_change`, `effect_work_growth_is_bounded_as_batch_size_rises`, and `effect_reads_do_not_decode_inspection_snapshots`. Their historical SQL fixture omits history_visibility, exposing an incorrect dependency in operation reads. No performance assertion was weakened and their fixture was not edited.

Before fixing that issue and a separately identified missing-subtree authority issue:

```sh
cargo test --locked -p vidlib-fileops --test undo missing_
```

`/workspace/scratch/task09-independent-evidence-red.log`:

```text
missing_history_visibility_never_hides_pending_recovery_evidence ... FAILED
pending recovery is independent of history support: Err(... "Query returned no rows")
missing_historical_nested_namespace_cannot_bless_current_child_material ... FAILED
a current complete scan cannot replace missing historical child evidence
test result: FAILED. 0 passed; 2 failed
```

The second test removes the unselected nested directory from the forward target namespace while retaining its inventory coverage, then externally changes an existing deep child's material. A fresh complete namespace alone incorrectly blessed that child. Undo now requires historical complete listing evidence for each carried directory and returns a blocked graph when it is absent.

After correction:

```sh
cargo test --locked -p vidlib-fileops --lib --test undo
```

`/workspace/scratch/task09-independent-evidence-green.log`: **16 unit + 22 undo tests passed**, no warnings. All three existing performance tests pass unchanged.

## Final verification

Focused adjacent regression (before the final two self-review corrections, superseded by the full final workspace run):

```sh
cargo test --locked -p vidlib-fileops --test undo --test recovery --test rename --test journal --test actions
```

`/workspace/scratch/task09-focused.log`: **123 passed** — 19 undo, 28 recovery, 36 executor, 19 journal, 21 duplicate actions. No warnings.

The substantive evidence fixes and first workspace failure justified the final workspace rerun:

```sh
source /workspace/.tools/desktop-env.sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace
```

`/workspace/scratch/task09-workspace-final.log`: **289 passed, 0 failed**, all doctests successful, no warnings. Includes 22 undo tests (one is the child entrypoint harness), 28 recovery, 36 executor, 19 journal, 21 duplicate actions, 16 fileops unit, 20 platform, 13 coordinator, 40 graph, 15 desktop and all other inventory/engine/contract tests. The initial failing workspace log is retained and not represented as green.

```sh
cargo clippy --locked -p vidlib-fileops -p vidlib-rename --all-targets -- -D warnings
cargo fmt --all -- --check
# fresh shell:
source /workspace/.tools/windows-check-env.sh
cargo check --locked -p vidlib-inventory -p vidlib-rename -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu
git diff --check
```

- `/workspace/scratch/task09-clippy-final.log`: passed, `Finished dev profile ... in 2.22s`, no warnings.
- `/workspace/scratch/task09-fmt-final.log`: passed, empty output.
- `/workspace/scratch/task09-windows-final.log`: passed, `Finished dev profile ... in 1.29s`, no warnings. Cargo package/build lock messages reflect concurrent checks, not failures.
- `git diff --check`: passed, empty output. Staged check is recorded with commit below.

## Changed files and self-review

New task-owned files: `crates/vidlib-fileops/src/undo.rs`, `crates/vidlib-fileops/tests/undo.rs`. Existing journal query/record/schema/migration modules add history and lineage. Narrow existing model/graph/executor changes add and validate inverse_of. The recovery evidence helper is extracted/reused, and native check_stamp becomes crate-private reusable evidence logic. Existing literal fixtures in journal/rename contracts and desktop app_state tests add inverse_of None. Historical v3/v4/v5 migration fixtures remove the newer v7 table/checksum when constructing old schemas and assert the current v7 destination; their original authority/rollback expectations remain unchanged. No manifest/lockfile or dependency changes.

Self-review checked original-versus-compensated provenance, receipt collapse through cycles/ancestor carries, live historical canonical validation, all-selected conflicts, native grant/parent bindings, exact carried paths, directory material refresh, nested historical completeness, operation/step gates, hidden-history recovery independence, outbox acknowledgment independence, cursor stability/bounds/exact JSON, schema rollback and version rejection. The late missing-visibility and missing-subtree issues were corrected with behavioral reds. Existing per-effect journal performance tests pass. The journal module was already large; changes stay within its existing query/transaction responsibilities, and no unrelated restructuring was performed.

## Limits and pending checks

- Native Windows runtime, sharing/handle/timestamp behavior, installed/offline Windows packaging, and hardware power-loss checks remain pending. Linux child exits, SQLite transaction failures and Windows cross-compilation do not establish those results. Mutation/release gates remain unchanged and closed where previously closed.
- Historical operations without a complete captured directory subtree fail closed for directory Undo, even if a new current scan is complete. Unknown historical children/material cannot be granted authority by that scan. Fresh review still supports ordinary proven parent/child inverses.
- History pages are bounded; removal is a visibility/Undo-eligibility operation retaining the factual ledger and delivery/audit evidence. No age/size cap or automatic physical evidence pruning is invented because no retention quantity/policy was specified. A future evidence-retention owner may prune only with independent recovery/outbox/lineage safety.
- An active inverse with retained effects prevents replay of its original; fully compensated interrupted Undo allows fresh retry. Later copy/metadata inverse extensions, editor undo/redo, desktop history/Undo UI, broad performance qualification and release completion remain with their owners.
- Reconstructing/canonical-checking large inverse plans under the journal begin transaction is pure but not scale-qualified. No filesystem I/O occurs inside that transaction.

## Commit

`e5bcb84` — `feat: add reviewed inverse plans and operation history`. All 17 changed source/test files are committed. Both unstaged and staged diff checks passed; `git status --short` is empty after commit. No push/merge or branch/worktree change. Report remains in the prescribed ignored `.superpowers/sdd` location.
