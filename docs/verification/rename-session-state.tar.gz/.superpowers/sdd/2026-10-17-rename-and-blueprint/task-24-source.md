### Task 24: Blueprint registry and local persistence

**Files:** Create `crates/vidlib-blueprint/Cargo.toml`, `crates/vidlib-blueprint/src/lib.rs`, `crates/vidlib-blueprint/src/model.rs`, `crates/vidlib-blueprint/src/store/mod.rs`, `crates/vidlib-blueprint/src/store/schema.rs`, `crates/vidlib-blueprint/src/store/migrations.rs`, `crates/vidlib-blueprint/src/query.rs`, `crates/vidlib-blueprint/tests/store.rs`; update workspace manifests/Cargo.lock.

**Interfaces:** Implements BlueprintStore and DTO models from 4.4; consumes inventory/path/recipe data and event types only. Local blueprint.sqlite3 failures remain independent of operations.sqlite3 and Rename.

- [ ] **Step 1 — Red:** Add `registry_and_map_survive_restart`, `migration_failure_keeps_original`, `exact_path_and_number_storage`, `cached_queries_page_200`, and `blueprint_db_error_does_not_open_or_mutate_operation_store`.
  ```rust
  assert_eq!(reopened.collection(id)?.display_name, "Archive");
  assert_eq!(page.items.len(), 200);
  assert_eq!(operations_db_writes, 0);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test store`.
- [ ] **Step 3 — Implement:** Local WAL/versioned migrations with failure preservation and thread-owned connections, following Task 04's settings. Own tables: collections, roots (binding_revision/evidence/availability), refresh_attempts, coverage, observations, current_entries, changes, template_attachments, consumed_operation_events, projection_cursors, pattern_cache. Current_entries references **per-entry/scope observation attempts**, not one root-wide snapshot pointer. Index `(root_id,parent_path_key,path_key)`, `(root_id,physical_identity)`, history time/type/origin/operation and exact path. IDs/path codecs/numeric sort keys use section 4 contracts; SQL rows stay private.
- [ ] **Step 4 — Verify green:** Store tests against real local DB files, query-plan/index checks for paging and current old/mixed-age rows, corrupt/migration fixture retention. Schema errors return actionable BlueprintError without changing media or Rename state.
- [ ] **Step 5 — Commit:** `feat: persist Blueprint collections and observations locally`.

