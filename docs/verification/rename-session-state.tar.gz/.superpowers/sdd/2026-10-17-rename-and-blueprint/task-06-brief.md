# Task 06: Validate final paths and build dependency graphs

## Final preflight freshness clarification

Observation may change access times. An access-time-only change must not revoke an otherwise identical namespace/entry preview. Retain full stamps for inspection, but freshness should compare physical identity and material state consistently with PlatformFs::check_stamp (size, modification time, supplied created time/Windows attributes), in addition to existing ancestry/entries/policy checks. Cover harmless access-time changes and genuine identity/material changes with a focused pure regression; this does not authorize effects or relax any uncertainty gate.

## Pre-review compiled-state and temporary-policy correction

The concrete scheduling case directory A->B, file B->A/x (final B/x), child A/x->outside must not consume an ancestor Observed/FromReceipt material stamp after modeled child namespace mutations have made that stamp stale. A focused pure interpreter regression should account for parent-directory material changes. Resolve scheduling/reservations without inventing fresh source authority; parking an ancestor first is insufficient if descendant effects occur before its later final move.

Operation temporary names must participate in the shared inventory/selection protected staging policy. Current first commit uses `.vidlib-rename-*` while the policy protects only `.vidlib-staging`; close that mismatch using the canonical protected namespace or a shared declared protected rename prefix. Pure internal logical-reservation validation may narrowly allow its exact reserved namespace while still honoring excluded/protected roots and markers; ordinary input/output cannot use it. Names remain frozen and EntryId-derived, without media IO or placeholder creation. Task07 owns native reserved-path authorization and ownership checks.


**Files:** Create `crates/vidlib-rename/src/validate.rs`, `crates/vidlib-rename/src/graph.rs`, `crates/vidlib-rename/tests/graph.rs`; extend model/evaluate; consume NamespaceSnapshot/DirectoryFacts from `vidlib-inventory::model` without creating a fileops dependency cycle.

**Interfaces:** Produces `plan` from 4.2 and an identity-based graph of ExecutionSteps/data. Native Filesystem effects stay in fileops; graph data belongs to rename. Namespace capture from Task 02 returns this shared data contract.

- [ ] **Step 1 — Red:** Add `swap_and_three_cycle_plan_without_overwrite`, `case_only_rename_uses_reserved_temp`, `parent_and_child_keep_one_location_model`, `target_parent_case_policy_controls_collisions`, `root_and_marker_protected`, `outside_destination_and_ancestor_cycle_blocked`, and `hidden_page_conflict_blocks_entire_approval`.
  ```rust
  assert!(plan.rows.iter().any(|r| r.status == RowStatus::Blocked));
  assert_eq!(plan.summary.blocked_count, 1);
  assert_eq!(final_child_path, expected_renamed_parent.join("new.mkv"));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test graph`.
- [ ] **Step 3 — Implement:** Resolve final paths globally, use per-parent name policy, derive strongly connected rename dependencies and recorded temporary reservations, update current locations when ancestors move, and expose carried-descendant counts. Validate source/destination ancestry, Windows names/lengths/ADS/device targets, grants, collision suffixes frozen in preview, and protected roots. Conflicting descendant exclusions become issues rather than impossible promises.
- [ ] **Step 4 — Verify green:** Graph tests include invalid Unicode display aliases, long/UNC paths, case-sensitive siblings, hard-link paths and target-created-after-preview preflight fixtures. Domain graph tests never write source fixtures.
- [ ] **Step 5 — Commit:** `feat: plan collision-safe hierarchical renames`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.


## Protected-root integration distinction

Normal contents of saved/registered library roots remain usable by Rename. Protect the root entry itself, active markers, and any selected ancestor move that would carry a protected root; do not exclude every descendant of a Blueprint root. Inventory ProtectedPolicy.roots currently denotes excluded subtrees (for app-local/private/staging protection). Do not feed Blueprint root guards into that subtree-exclusion list without distinguishing exact root-entry/ancestor protection from private subtree exclusion. Keep registered-library rename workflows covered by integration tests.

## Task03 integration carry-forward

PlanStore publication currently checks duplicated frozen inputs but not duplicated grants (rename/model.rs:337); see deferred Minor in progress.md for final triage. Preserve one consistent authority snapshot when building/consuming plans. Task06 must test independently built plans from identical frozen inputs yield byte-identical DTOs except supplied PlanRef. Task10 owns actual fresh process sessions and invalidation on inventory/recipe/selection changes; pure PlanStore alone does not establish that wiring.

## Task04 compiled-step handoff

Task04 corrected the initial Task03 action model to the eight section4.3 variants with action-specific native fields. Read task-04-report.md for EntryPrestate/ExpectedIdentity/OwnedEntryPrestate, private persistence and exact Journal APIs; do not reintroduce flattened dummy source fields or duplicate ExecutionStep in fileops. References resolve to committed poststates of earlier steps in the same group or declared dependencies; owned compensation stays in its dependency group. Task09 must validate historical receipt/identity/digest ownership for undo through the same journal/executor and may extend the typed inverse data as its plan specifies; current-operation receipt references alone do not establish historical undo authority.

## Task05 coordinator/registry handoff

After review clears, read task-05-report.md for Coordinator/Lease/Epochs/PlanRegistry APIs and schema v3. Lease is Send for worker handoff, !Sync and not Clone; Journal remains thread-owned !Send/!Sync. Hold the appropriate lease through all physical work and durable finalization. CoordinationStatus distinguishes pending_journal from interrupted_legacy_write; an empty Journal::pending() does not erase legacy uncertainty. Epoch values are backend u64 data without Serialize; any new IPC must use exact decimal strings. PlanRegistry validates coordinator ownership and namespace/policy epochs under a lease; consume needs ordinary Write. Task10 still owns inventory/recipe/selection invalidation. Native installedWindows/runtime remains pending.

## Narrow captured-fact/provenance integration corrections

Task06 may retain RecipeV1 in EvaluatedBatch, add backend expected namespace/preflight data to ExecutionPlan and carried-descendant counts to rows/DTOs, extend exact guarded-root entries separately from excluded subtrees, and expose shared pure native name/length helpers. DirectoryFacts must retain its observed directory FileStamp so pure planning can prove target volume identity; populate it from the existing retained directory observation with one narrow fileops capture assignment and mechanically update struct literals/tests. Unknown volume evidence remains blocked until supported copy compilation. Preserve the existing individually granted-file workflow: a normal in-place rename may produce a new sibling name for that selected file without granting unrelated sibling sources or the parent directory itself. Cover that boundary explicitly; do not silently drop Task03 individual-file support.
