### Task 03: Versioned recipes and deterministic plan models

**Files:** Create `crates/vidlib-rename/Cargo.toml`, `crates/vidlib-rename/src/lib.rs`, `crates/vidlib-rename/src/model.rs`, `crates/vidlib-rename/src/recipe.rs`, `crates/vidlib-rename/src/evaluate.rs`, `crates/vidlib-rename/tests/contracts.rs`; modify root Cargo.toml/Cargo.lock.

**Interfaces:** Consumes Inventory; produces every 4.2 model, `evaluate`, backend-only RenamePlan/PlanRef, serializable DTO projections, and stable RenameError codes. Rule evaluation initially supports Keep/FixedStem; later tasks supply each rule implementation through the same pipeline.

- [ ] **Step 1 — Red:** Add `unknown_recipe_version_or_rule_rejected`, `preview_freezes_clock_and_random`, `unselected_or_outside_grant_id_rejected`, `json_preserves_large_sizes`, and `explanations_follow_rule_order`.
  ```rust
  assert_eq!(first.rows, repeated.rows);
  assert_eq!(json_row.size_bytes.as_deref(), Some("9007199254740993"));
  assert_eq!(err.code, RenameErrorCode::UnknownRecipeVersion);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test contracts`.
- [ ] **Step 3 — Implement:** Implement 4.2's tagged RecipeV1, typed template AST, FrozenInputs, EvaluatedBatch and owned plan models with backend-only native fields. Pin field/format enums and reject invalid combinations before rows are generated. Implement schema round-trip tests; use checked arithmetic and exact serialization. Do not expose unimplemented rule controls yet.
- [ ] **Step 4 — Verify green:** Contracts test plus `cargo clippy -p vidlib-rename --all-targets -- -D warnings`; repeated identical frozen inputs yield byte-identical DTO plans except explicitly supplied PlanRef.
- [ ] **Step 5 — Commit:** `feat: define deterministic rename recipes and plans`.

