### Task 20: Opt-in filesystem attributes and timestamps

**Files:** Create `crates/vidlib-fileops/src/metadata.rs`, `crates/vidlib-fileops/tests/metadata_actions.rs`; extend rename recipe/evaluate/journal/undo and desktop metadata DTOs.

**Interfaces:** `MetadataChangeSet` carries per-field Keep/Set/Clear or timestamp Set/Offset/Increment; original and requested states are part of the plan and receipt. Extend Filesystem::set_metadata and inverse planning; metadata-only rows are Changed even if their path stays identical.

- [ ] **Step 1 — Red:** Add `all_defaults_leave_metadata_unchanged`, `each_windows_attribute_and_timestamp_can_be_explicit`, `offset_increment_uses_frozen_item_order`, `partial_set_failure_is_reported_and_recoverable`, and `undo_refuses_changed_poststate`.
  ```rust
  assert_eq!(default_receipt.after.modified_ns, before.modified_ns);
  assert_eq!(metadata_only_row.status, RowStatus::Changed);
  assert_eq!(restored.attribute_bits, original.attribute_bits);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test metadata_actions`; run Windows-created/accessed/modified and hidden/read-only/archive/system fixtures there.
- [ ] **Step 3 — Implement:** Native supported setters, typed unsupported results elsewhere, frozen date/time policies from Task 13 and checked per-item increments. Journal expected/current/original states per field, not only filenames. Do not silently clear read-only or write embedded recording metadata to make a rename succeed. Restore only the fields actually changed after verifying expected poststate.
- [ ] **Step 4 — Verify green:** Metadata/undo/recovery tests including failure after a subset of fields; no-op controls stay invisible in the operation summary. Document OS-managed access-time limitations truthfully.
- [ ] **Step 5 — Commit:** `feat: add explicit recoverable file metadata changes`.

