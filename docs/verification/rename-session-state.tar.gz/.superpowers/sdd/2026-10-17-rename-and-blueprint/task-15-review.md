# Task 15 review

**Spec compliance: Issues found.** The requested backend selection, mappings, overrides, export modes, and mixed-kind numbering ruling are implemented, but the new nested desktop request schema violates the shared camelCase command contract.

**Task quality: Needs fixes.** Counts: **Critical 0; Important 1; Minor 1.**

Reviewed immutable package `review-8fd8800..54d8f6d.diff`, base `8fd8800`, head `54d8f6d039598ece2918518d317726aba732165b`, in full once. Applied the task review contract, official task-reviewer prompt, Task 15 brief including the controller scope ruling and Task 14 handoff, and implementation report. The report-only test-count correction does not change this reviewed product revision.

## Strengths and compliant behavior

- `crates/vidlib-rename/src/selection.rs:139`: filtering operates on inventory/native identity, covers the R11 dimensions, compiles expressions outside the entry loop, and deduplicates overlapping native paths. The persisted exclusion overlay rejects unknown IDs and applies to aliases of an excluded native path.
- `crates/vidlib-rename/src/selection.rs:263` and `crates/vidlib-rename/src/evaluate.rs:54`: selection preparation preserves surviving explicit primary order; counters use a separate kind-specific vector. Other-kind rows remain available for ordinary rules, and required out-of-scope template counters become missing fields. This follows the controller's explicit mixed-kind ruling; simultaneous independent file and directory counters are not required here.
- `crates/vidlib-rename/src/hashes.rs:138` and `crates/vidlib-rename/src/validate.rs:40`: scope is carried through input preparation and checked in evaluation/planning provenance. Existing explicit cached counter overrides are retained while default counters are generated from the current scoped vector.
- `crates/vidlib-rename/src/mappings.rs:43`: the reader bounds consumed bytes with one overflow probe; CSV uses the CSV parser rather than comma splitting, and row limits are checked before retaining an excess record. Exact-path lookup precedes basename fallback. Mapping validation checks inventory generation, selected IDs, duplicate native sources/targets, and source/target grant authority. The explicit-file exception is limited to that source's same-parent target.
- `crates/vidlib-rename/src/mappings.rs:414`: explicit mappings and row overrides feed evaluated candidates and retain unsupported-source blockers. The caller still performs complete namespace capture and graph planning. The new tests exercise post-exclusion collisions and a collision on row 205, not just page-visible results.
- `crates/vidlib-rename/src/mappings.rs:510`: spreadsheet reports and exact mappings use distinct headers and paths; spreadsheet protection does not mutate recorded originals. Exact exports fail on unsupported path representations rather than using lossy display text.
- `src-tauri/src/commands/rename.rs:479` and `src-tauri/src/commands/rename.rs:595`: preview invalidation precedes preparation, and publication retains revision/selection-generation checks. The new real-file desktop test verifies filtered override output and rejection of the old PlanRef after an edit.

## Important — fix before accepting Task 15

### I1. Adapt the new nested request fields to the shared camelCase command schema

**Evidence:** `src-tauri/src/commands/rename.rs:153`, `crates/vidlib-rename/src/selection.rs:49`, `crates/vidlib-rename/src/mappings.rs:36`; normative command contract at `docs/superpowers/plans/2026-10-17-rename-and-blueprint.md:170` and `:174`.

`RenameRequestDto` is camelCase only at its outer level. It directly embeds `SelectionFilter` and `RowOverride`, whose serde definitions retain snake_case member names and deny unknown fields. For example, the contract-shaped payload `rowOverrides: [{entryId: id, newName: "edited.mkv"}]` fails deserialization; so do filter members such as `maxDepth`, `excludedIds`, `createdNs`, and pattern member `caseSensitive`. The new desktop regression instead sends `entry_id` and `new_name`, so it establishes the conflicting shape rather than detecting it. The shared browser/Rust contract fixture is not extended by this diff.

**Impact:** clients following the agreed command contract cannot use the new controls. Carrying this shape into Task 21 would require exceptions throughout the UI or another incompatible boundary change.

**Fix:** introduce desktop-facing nested DTOs with the agreed camelCase fields/tags and convert them to the portable core structs, or otherwise provide an explicit boundary serialization adapter. Preserve the core recipe format deliberately rather than changing it incidentally. Extend the shared command golden fixture and deserialize that same camelCase payload in Rust, including a nontrivial filter and row override with exact decimal-string bounds. Cover rejection of unknown fields and rounded numeric bounds.

## Minor

### M1. Remove conflicting color environment variables from UI verification

**Evidence:** `.superpowers/sdd/2026-10-17-rename-and-blueprint/task15-logs/ui.log:17`, `:22`, and `:24`.

The saved successful UI run emits repeated Node warnings because `NO_COLOR` and `FORCE_COLOR` are both set. This is environment noise rather than an application failure, but the reviewer contract explicitly treats warning output as a finding. Set only the intended color mode in the verification environment for the next necessary UI run; a repeat run solely to clean this log is unnecessary.

## Cannot verify from this diff / controller follow-up

- Actual Windows runtime, WebView2 interaction, NTFS/exFAT/removable/network behavior, and packaged offline behavior remain pending. The reported Windows core results are compile/link evidence only. The desktop cross-check failed at the missing unqualified MinGW compiler alias when it ran; the controller's later tooling repair does not establish a successful desktop cross-build or native runtime result.
- Task 18 still owns complete companion association resolution and propagation before freezing. This task tests scope consumption for an already-resolved primary vector and deliberately rejects explicit companion evaluation. It does not establish the full companion workflow. Task 21 still owns complete UI/import/export interactions.
- The complete release's no-overwrite execution, journal durability, restart recovery, Blueprint isolation, and marker behavior are unchanged downstream responsibilities; this task's diff cannot independently qualify those global release properties.
- Saved final workspace evidence and the appended report reconcile to **417 distinct Rust tests**, with **418 passing harness results** because `resource_limits_are_real` is repeated in a child harness (`workspace-final-locked.log:573` and `:577`). The report now distinguishes those counts. This review did not regenerate any results or rerun suites.

## Focused boundary checks and review limits

- **Source/target authorization:** checked `SourceGrant`/`RootBinding` in unchanged inventory model code and the planner's existing target-authority/root-protection branch. Completed the diff-cut-off `validate_inventory` function. The importer’s file exception is consistent with the planner's file-only same-parent exception; directory-root relocation remains blocked.
- **Frozen selection/scope/cache provenance:** checked the cut-off cache validation/output-retention portions needed to assess the added scope behavior. Default counter values are not added to retained cache values; explicit retained values can survive a temporary scope exclusion. No content-read behavior was added to pure selection/evaluation/mapping parsing.
- **Desktop revocation and nested serialization:** checked the cut-off preview publication tail and the exact shared command-contract paragraphs. Publication still checks the current revision and selection generation; the nested DTO mismatch is I1.
- **Parser/export semantics:** reviewed the full new module and its behavior tests in the package. Checked the existing `valid_component` helper, whose definition was outside the recipe diff, to interpret pasted-name/override and exact-export validation.
- No product files, index, HEAD, or branch were changed. No helpers/subagents were dispatched. No confirmatory test suite was run. The only write is this review report.
