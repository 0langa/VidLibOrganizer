# Task08 scoped re-review, round 1/5

## Finding verdict

**Restore chooses a completed earlier group at durable boundaries — ADDRESSED.**

`crates/vidlib-fileops/src/recovery.rs:563` replaces the last-non-Planned selector with durable Restore context, compatible existing inverse lineage, or the first unfinished/durability-unconfirmed group. Fully completed, confirmed prior groups no longer become inverse authority by recency. A wholly Planned following group has no completed effects for Restore to reverse.

`crates/vidlib-fileops/src/recovery.rs:285` saves the selected optional group before resetting intents, recording recovered completions, or resolving durability. `crates/vidlib-fileops/src/journal/recovery.rs:6` persists that decision transactionally and rejects a subsequent different group; `:166` distinguishes absent context from an explicit no-group decision. Restart can therefore retain legitimate interrupted-group authority after every original step becomes CompletionDurable. Resume is rejected after a Restore decision, and inverse continuation is constrained to the selected group at `crates/vidlib-fileops/src/recovery.rs:438`.

The selector separately checks unsupported/failed receipt durability and its verified-durability audit. It therefore preserves the existing ability to Restore a final durability gap, rather than simply excluding every wholly receipted group. Existing v5 inverse links supply continuation authority when the newly migrated context is absent.

## Boundary and preservation evidence

- `crates/vidlib-fileops/tests/recovery.rs:911` covers an actual child exit after G1's durable receipt and before G2's intent. `:916` covers a second child exit after G2's durable NotApplied reset. Their shared assertions preserve G1's destination bytes, absent original source, original states and receipts, and exact event list; they leave G2 unexecuted, append no inverse, and report G1 completed.
- `crates/vidlib-fileops/tests/recovery.rs:978` covers an actual Restore-child exit after resolving the final forward receipt but before creating an inverse. All original steps are CompletionDurable with zero inverse rows at restart; persisted context still authorizes Restore, rejects Resume, and produces exactly the three required inverse facts once.
- `crates/vidlib-fileops/src/recovery.rs:338` advances the namespace epoch while the operation remains pending, before terminal finalization at `:345`. The ordinary executor's transition at `crates/vidlib-fileops/src/rename.rs:335` likewise follows its existing epoch advancement. `tests/recovery.rs:939` rejects the epoch update with a SQLite trigger and verifies the gate, original effects, and events remain intact; a fresh Restore finishes after the trigger is removed.
- `crates/vidlib-fileops/src/journal/migrations.rs:47` and `:147` check and transactionally add schema v6. The patch leaves v1–v5 SQL/checksums unchanged. `tests/recovery.rs:1038` verifies migration preserves the original operation/events without inventing Restore context, and `:1057` verifies failed migration retains v5 state and evidence.

## New breakage in the fix diff

**None identified.** The selected-group persistence and terminal-finalization changes address the reported boundaries without removing the existing identity, namespace, parent-binding, or inverse-intent requirements.

## Out-of-scope observations

**None.** The documented cancellation ruling and unrelated earlier implementation were not reopened.

## Verification and limits

Read the supplied fix package once in two sequential chunks, from `2d708f0a46cd94493956ed417e10fd4af65ed53b` to `f5a26f5f76b49d233838c71620776e10e2a8d479`, and the appended round-1 report. The report names the three intended behavioral reds and provides final output for 19 journal, 28 recovery, 36 executor, and 13 coordinator tests (96 total), plus passing static/format/Windows cross-compilation checks. The changed tests exercise the described boundaries and meaningful preservation assertions. No suites were rerun, no helpers were dispatched, and the checkout remained read-only.

Actual Windows runtime, removable-hardware behavior, and hardware power-loss durability remain pending. The reported checks and process-crash fixtures do not establish those outcomes.

## Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.**

**Scoped spec verdict: compliant. Scoped quality verdict: approved.**
