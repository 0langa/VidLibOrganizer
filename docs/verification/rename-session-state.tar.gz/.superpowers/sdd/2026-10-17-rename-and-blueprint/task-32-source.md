### Task 32: Whole-project regression and execution handoff

**Files:** Update README.MD, docs/verification/rename.md, docs/verification/blueprint-foundation.md and this canonical plan's execution ledger; update older design status references only to reflect actual completion. No competing implementation-plan file.

**Interfaces:** Preserve existing duplicate commands/preferences and both features' independent completion statuses.

- [ ] **Step 1 — Check coverage:** Walk the traceability table below and both approved specs. Link each item to a committed automated test or recorded Windows/native evidence. Open checkboxes or unavailable platform evidence remain visible; do not infer completion from code presence.
- [ ] **Step 2 — Run final regression:** After final code fixes, run the platform-appropriate Rust workspace/core checks, JS checks, browser suites and release build from Task 23. Do not repeat broad suites after a passing unchanged state merely to accumulate output.
- [ ] **Step 3 — Document actual behavior:** Describe offline runtime requirements, bundled helper/resources, new app-data/marker behavior, recovery/undo limitations, native entry points and the experimental Blueprint scope. Keep the earlier duplicate-only verification record as history. Document remaining unsupported filesystem cases and unresolved platform checks precisely.
- [ ] **Step 4 — Review readiness:** Use Superpowers verification-before-completion and requesting-code-review; review the whole implementation branch for plan/spec coverage and regressions after task-level reviews. Integrate fixes with their owning regression tests. No production library benchmark or destructive user-file test is authorized by this plan.
- [ ] **Step 5 — Commit/handoff:** `docs: record Rename and Blueprint implementation evidence`. Report completed gates, exact checks, remaining limitations, worktree/branch, and next incomplete task. Follow finishing-a-development-branch for integration; pushing/publishing/releasing is a separate action, not implicit in this planning request.

## 7. Requirement-to-task traceability

| Rename requirement | Implementation owner | Verification |
| --- | --- | --- |
| R01 text editing | 11, 21 | text goldens + complete UI rule scenarios |
| R02 substring/reverse/translations | 11, 21 | grapheme/translation/move/copy tests |
| R03 case/exceptions/Roman | 11, 21 | explicit case goldens and Unicode cases |
| R04 regex | 12, 21 | native PCRE2 captures/backrefs/lookarounds/limits |
| R05 segment/ordered repeated rules | 03, 11, 12, 16, 21 | intermediate explanations + editor reorder/undo |
| R06 numbering | 03, 13, 21 | frozen vector, repeat/reset/formats/display sort |
| R07 dates | 13, 17, 20, 21 | format/timezone/DST/source distinctions |
| R08 templates/properties | 14, 17, 21 | every field family, optional/fallback/missing |
| R09 hashes/generated values | 14, 21 | five independent vectors, full read/lazy/cancel/frozen |
| R10 stem/extensions | 11, 14, 21 | explicit stem/whole-name/extension cases |
| R11 recursive selection/filters | 01, 15, 21 | all dimensions, coverage, rebuilt approval |
| R12 mappings/paste/export/override | 15, 21 | bounds, ambiguous paths, spreadsheet/lossless separation |
| R13 presets/edit undo | 16, 21 | revisions, round-trip, failed save, editor history |
| R14 companions | 06–09, 18, 21 | suffixes/owners/pairs/group failure/no hidden selection |
| R15 folders/copy/move/layouts | 02, 06–09, 19, 21 | final graph, verified publication, inverse ownership |
| R16 attributes/timestamps | 02, 04, 09, 20, 21 | explicit supported fields/defaults/restoration |
| R17 preview/history/recovery/undo | 03–10, 15, 21, 23 | all-row validation, crash matrix, stale responses, UX |
| R18 native/Explorer/keyboard | 10, 21–23 | native path selection, opt-in shell entry, focus/drop |

| Blueprint acceptance (spec section 11) | Tasks/evidence |
| --- | --- |
| 1 registration/reopen/map/history | 24, 29, 31 |
| 2 identity, drive-letter/rebind/lookalike | 25, 31 |
| 3 offline cache/reconnection/no false deletion | 26, 29, 31 |
| 4 qualified external changes/first baseline | 26, 31 |
| 5 incomplete coverage/cancel preservation | 01, 26, 31 |
| 6 unstable identity/truthful relocation | 25, 26, 31 |
| 7 marker clone/marker-only installation | 25, 30, 31 |
| 8 replay/duplicate attribution/storage isolation | 04, 05, 27, 31 |
| 9 real templates/fresh Rename/pattern examples | 16, 28, 29, 31 |
| 10 read-only marker/migrations/portability/pruning/paths/performance/accessibility | 24–26, 29–31 |

Non-matrix safety requirements are owned explicitly: native-path and exact transport (01/03/10); no-clobber/grants (02/06/07); graph/folder identity (06/19); durable local journal and recovery (04/07/08/19/20); inverse-state verification (09/19/20); cross-process exclusion/invalidation (05/10/27); metadata helper isolation (17); independent protected roots (25); observational truth/coverage (26); durable exactly-once projection (27); trusted local binding versus portable data (25/30); complete Windows evidence and benchmark limits (23/31/32).

## 8. Execution ledger

Execution status: implementation is in progress on `feat/rename-blueprint` in `.worktrees/rename-blueprint`. Tasks 01–04 are implemented and reviewed with portable evidence; Task 02's Windows red/green platform checks remain incomplete. Task 05 is the next eligible implementation task. Windows runtime checks remain pending. Neither the complete Rename release nor Blueprint foundation is complete. The storage assumption accepted with the specs is app-local Blueprint data plus opt-in portable identity markers; no new preference question is required before following it.

| Date | Task / commit | Evidence / next action |
| --- | --- | --- |
| 2026-10-17 | Plan authored; Context7 and repository checked | Start Task 01 in an isolated worktree after reviewing the plan and selecting execution method. |
| 2026-10-17 | Execution setup; base `711b422` | Cloned `0langa/VidLibOrganizer`; isolated worktree `.worktrees/rename-blueprint`, branch `feat/rename-blueprint`; all three specs read; 36 portable baseline tests and UI syntax passed. Rust 1.99.1 installed. Task 01 is first incomplete. Windows checks pending; continue portable work. |
| 2026-10-17 | Task 01: `d734f55`, fixes `dfc7e4e`, `aff67d5` | Test-first native inventory, exact codecs, no-follow relative-handle traversal, per-binding evidence and coverage. 27 inventory +36 existing portable tests pass; Linux and Windows-target Clippy and fmt pass. Independent review and two scoped fix re-reviews completed. Windows runtime pending. Deferred Minor: overlap diagnostic paths need rebasing; final branch review must triage. Next eligible: Task 02. |
| 2026-10-17 | Task 02: `7328356`, `8fe6590`, fix `f051627` | Test-first no-replace adapters, native per-parent facts and shared name validation. 88 portable tests pass; 18 platform tests passed on tmpfs and overlayfs; Linux/Windows-target Clippy and fmt pass. Independent review plus scoped fix re-review clean. Windows production mutations fail closed; native NTFS/exFAT/SMB, locking/case/reparse/metadata/flush qualification pending. Deferred Minor: Windows staging writer-sharing lifecycle (Task 19/final review). Next eligible: Task 03. |
| 2026-10-17 | Task 03: `07f9a50` | Test-first strict recipes, typed template/frozen inputs, backend-owned execution models and session-scoped PlanStore with revoked references/nonces. 18 contracts and 106 total portable tests pass; Clippy, fmt and Windows-target compile pass. Independent review approved. Deferred Minor: duplicated plan/provenance grants consistency at publication, for final review. Future rule evaluation, Task 06 graph and Task 10 invalidation wiring remain open. Next eligible: Task 04. |
| 2026-10-17 | Task 04: `16c5def`, fix `16fdb4b`; evidence `3f589ec`, `39f166c` | Real-file WAL/FULL journal, exact native compiled steps, atomic receipts/outbox, pending states and checked migrations. 126 portable tests passed before review; all 25 covering journal tests pass after the performance fix, with scoped Clippy/fmt. Indexed hot-path work scales with batch size; v1→v2 migration preserves existing evidence. Independent review and scoped fix review clean. Task 03 action-model omission corrected. Task 08 owns audited non-application recovery; Task 19 owns separately durable staging creation/streaming phases. Windows runtime pending. Next eligible: Task 05. |

During execution append task commits, commands/results, pending Windows capability rows and the next eligible incomplete task here. Keep this file canonical. Scope changes require an explicit spec/plan amendment, not an implementation agent silently dropping a required capability or expanding Blueprint into a mature hero feature.


### Pending platform checks

- [ ] Windows Task 01 runtime: native UTF-16/unpaired surrogates, relative-handle/reparse traversal, physical identity, Unicode case policy and filesystem-specific timestamps. Cross-target checks passed; runtime remains pending.
- [ ] Desktop baseline tests: workspace-local GTK/WebKit dependencies compile; baseline `generate_context!` fails because `src-tauri/icons/icon.png` is missing. Task 05 desktop integration will add the supporting asset and rerun tests.

- [ ] Windows Task 02 red/green qualification: NTFS file/folder/case-only and late-target collision, locked files, per-parent case-sensitive/insensitive siblings, reparse ancestry, metadata setters/flush; exFAT/removable and SMB. Native fixtures are written/compiled, runtime pending; production mutations remain gated. Linux tmpfs/overlayfs evidence is recorded in `docs/verification/filesystem-capabilities.md`; other Linux mutation filesystems remain unsupported until qualified.

- [ ] Windows Task 04 journal runtime: app-local WAL/FULL reopen, commit/Busy failures, checked migrations and receipt/outbox atomicity. GNU-target bundled-SQLite compile passed for the initial implementation; actual Windows runtime remains pending.
