### Task 23: Complete Rename release verification

**Files:** Create `.github/workflows/check.yml`, `tools/benchmark-library.ps1`, `docs/verification/rename.md`; extend Task 08 crash fixtures and UI regression suites. Modify README.MD/development instructions only for actually completed behavior.

**Interfaces:** No new feature interface. This task proves R01–R18 and the safety contracts, validates packaged helpers, and records the independent Rename completion gate.

- [ ] **Step 1 — Define expected evidence:** Add a verification matrix covering all R IDs, real Windows NTFS/exFAT/share outcomes, every journal boundary and inverse step, concurrent instances, stale-page conflicts, invalid/native paths, helper failure, disk/journal failure, companion compensation and protected markers. Each row names an automated test or an actual native smoke procedure and its expected outcome; missing evidence stays pending.
- [ ] **Step 2 — Run targeted fault suites:** All new Rust test binaries, real-process crash injection and existing duplicate tests; negative fixtures must demonstrate refusal/preservation, not merely a generic error.
- [ ] **Step 3 — Implement verification infrastructure:** Linux portable Rust tests excluding the Tauri desktop dependency where unavailable; Windows workspace tests/Clippy/format/build plus browser development tests. Pin toolchain/dependency lock inputs and do not skip failures with unconditional success. Install only development browser/native build dependencies. Add a reproducible 100,000-entry metadata fixture generator/benchmark, not a huge committed library.
- [ ] **Step 4 — Verify release gate:** `cargo test --locked --workspace`, `cargo clippy --locked --workspace --all-targets -- -D warnings`, `cargo fmt --all -- --check`, `npm ci`, `npx playwright test`, JS module checks and `cargo build --locked --release -p vidlib-tauri` on supported environments. Record reference Windows hardware, <=1-second cached first-page target, <=200 rows per page, <=10 progress updates/s, native dialogs/Explorer and no network dependency. If a required capability/test is pending, do not mark Rename complete or ship a partial matrix as complete.
- [ ] **Step 5 — Commit:** `test: verify complete Rename behavior and recovery` with measured evidence. Rename may release at this gate independently of Tasks 24–31.

