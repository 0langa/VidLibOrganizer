### Task 19: Folder layouts and verified copy/cross-volume moves

**Files:** Create `crates/vidlib-rename/src/destination.rs`, `crates/vidlib-fileops/src/copy.rs`, `crates/vidlib-fileops/tests/copy_move.rs`; extend graph/rename/recovery/undo and destination recipe controls.

**Interfaces:** `resolve_destinations(evaluated, policy: &DestinationPolicy, grants) -> Result<EvaluatedBatch, RenameError>`; extend execute/reconcile/plan_undo for CreateDirectory/StageCopy/PublishCopy/RemoveSource and owned cleanup. DestinationPolicy is InPlace, CopyTo, or MoveTo with explicit root grant and PreserveHierarchy/typed relative folder template.

- [ ] **Step 1 — Red:** Add `folder_layout_preview_matches_all_descendants`, `cross_volume_source_removed_only_after_verified_publish`, `copy_digest_and_metadata_verified`, `publication_then_remove_failure_preserves_fact`, `disk_full_cleans_only_owned_staging`, `copy_undo_checks_full_digest`, and `created_directory_undo_requires_empty`.
  ```rust
  assert_eq!(source_delete_calls_before_verified_publication, 0);
  assert_eq!(published.sha256, expected_sha256);
  assert!(source.exists()); // injected remove failure
  assert_eq!(receipt.phase, CompletedPhase::CopyPublished);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test copy_move`; extend the real-process crash matrix from Task 08.
- [ ] **Step 3 — Implement:** Same-volume graph rename when supported; otherwise explicit bounded 1 MiB staged copying, source streaming SHA-256, independent reread destination digest, freshness recheck, metadata/data flush, no-replace publication and only then checked source removal for Move. Journal every phase and owned directory. Cross-volume folder operations expand into dependency groups with descendant paths; never flatten unintentionally or recreate special entries. Resume/restore and Copy undo use the recorded phase/identity/digest; no invented suffixes or deletion of unknown staging files.
- [ ] **Step 4 — Verify green:** Copy/move/undo/recovery fixtures, a real second volume where available, publication-race/permissions/space faults, and cancellation between safe group barriers. Record unsupported volume semantics rather than substituting an unverified fallback.
- [ ] **Step 5 — Commit:** `feat: add verified destination layouts and copy move workflows`.

