# Task 12 review

## Spec compliance

✅ The inspected implementation complies with Task 12's code requirements. No missing, extra, or misunderstood implementation requirement found in `b338eda..8ca48e17f1acb00bf7779a52ff2e39d1f1c03fd7`.

⚠️ The required real native adapter run on Windows CI remains pending. GNU Windows target compilation, linked test executables, and static-import inspection do not establish actual Windows execution or MSVC packaged-release behavior. The controller must keep the Windows verification/release gates closed until that evidence exists; this review does not mark Step 4 fully complete.

## Strengths and verified implementation checks

- `crates/vidlib-rename/src/regex.rs:31`, `:108`, `:169`: the explicit limits are 16,384 pattern bytes, 1,000,000 matches, depth 1,000, and heap 8,192 KiB. The Rust byte check and native maximum-pattern setter both enforce the pattern cap; the match/depth/heap values are passed directly to the respective native setters and every setter status is checked.
- `crates/vidlib-rename/src/regex.rs:124`, `:186`: compilation enables UTF/UCP and forbids `\C`; substitution explicitly disables JIT, and no JIT compilation occurs. Case and first/all modes are explicit. These are native interpreter resource limits, not a total wall-time or output-memory limit.
- `crates/vidlib-rename/src/regex.rs:43`, `:161`, `:202`: native owners are non-null RAII wrappers with matching destructors; early failures clean up preceding allocations. Compiled code outlives local match data/context. Input, replacement, and output have separate allocations and explicit byte lengths; no raw native pointers escape. Unsafe call sites document their invariants.
- `crates/vidlib-rename/src/regex.rs:202`, `:219`, `:227`: overflow sizing includes the native terminating NUL, retry allocation is checked, negative returns do not expose partial output, and successful output passes UTF-8 validation. Focused inspection of the bundled native substitution implementation confirms its returned-length contract and global empty-match handling.
- `crates/vidlib-rename/src/regex.rs:239`: replacement validation checks maximal numeric references, braced numeric/named references, literal `$$`, unknown captures, malformed references, and duplicate names before rows run. Backslashes remain literal because extended substitution is not enabled. Native substitution supplies valid unmatched captures as empty text and chooses the first participating duplicate name. The focused native parser check confirms these conventions agree with the adapter's accepted grammar.
- `crates/vidlib-rename/src/recipe.rs:237`, `crates/vidlib-rename/src/evaluate.rs:21`, `crates/vidlib-rename/src/regex.rs:321`: enabled rules compile once before the row loop into a map keyed by validated unique IDs; disabled rules are skipped. The unit test counts successful native compile calls across multiple rows and two enabled rules. Import validation and evaluation are separate operations, consistent with the stated contract.
- `crates/vidlib-rename/src/text.rs:225`, `crates/vidlib-rename/src/evaluate.rs:91`: regex uses the existing current-input selector/reassembly path. The helper retains component validation and explicit extension behavior; the refactor preserves existing text-operation semantics.
- `crates/vidlib-rename/src/regex.rs:71`, `crates/vidlib-rename/src/evaluate.rs:123`, `:138`: native limit/failure codes become structured categories and rule/entry-associated row issues. Failed rows retain original native source/target paths and display names, while prior explanations survive. Adapter-native numeric codes are structured at the adapter boundary and retained in the row diagnostic text.
- `crates/vidlib-rename/tests/regex.rs:19`, `:58`, `:94`, `:199`, `:224`, `:260`, `:290`, `:305`, `:315`, `:334`: tests exercise real PCRE2 behavior for lookarounds/backreferences, Unicode, literal and optional captures, first/all/case modes, empty-match progression, all three native exhaustion modes, exact pattern boundary, disabled/repeated rules, current segments, restoration, empty-selection validation, native failures, duplicate names, buffer growth, and invalid generated components. The exhaustion fixture's parent timeout is clearly only a hung-test detector.
- `.cargo/config.toml:3`, `crates/vidlib-rename/Cargo.toml:15`: the narrow forced static setting matches the pinned dependency's build logic: it bypasses system-library discovery and builds bundled PCRE2. This supports offline release runtime without a user PCRE2 DLL or script runtime. Lockfile changes remain scoped to the dependency addition.

## Issues

### Critical

None.

### Important

None in the inspected implementation.

### Minor

None.

## Cannot verify from this diff

- Actual Windows CI/native execution and the broader Windows release qualification remain pending, as described above. No platform gate is opened by this review.
- The report states 86 distinct scoped tests and 345 distinct workspace tests passed, with the subprocess's repeated fixture excluded from distinct counts. Those execution results were not independently rerun or audited from raw logs here; the test code was reviewed. Reported compile/link/import checks likewise remain reported evidence, not independently reproduced evidence.
- Broader Rename/Blueprint requirements outside this intermediate rule-pipeline task, including execution journals, mutation/recovery behavior, metadata helpers, and complete release readiness, are not established by this patch.

## Review scope and focused checks

Read the supplied contract, task brief, implementation report, official task-reviewer prompt, and full packaged diff. The tool truncated the middle of the first diff display, so only the missing model/recipe/regex section was recovered; no fresh git diff or whole changed-file reread was performed.

Focused checks outside displayed hunk context addressed concrete interfaces: evaluator row initialization/finalization for blocked-row restoration; the shared helper's cut-off final component validation; unique rule-ID validation for safe compiled-map lookup; bundled PCRE2 substitution parsing/output-length semantics for FFI and replacement correctness; and its build script for the forced-static dependency contract. Targeted symbol searches supplied file:line evidence. No tests were rerun, no subagents dispatched, and no checkout/index/branch state changed. This report is the sole write.

## Assessment

**Task quality: Approved.** The adapter is small, owns native resources clearly, checks native failures explicitly, and shares the established text pipeline without duplicating transformation logic. **Implementation approval does not complete the pending Windows-runtime verification requirement.**

Finding counts: **0 Critical / 0 Important / 0 Minor**.
