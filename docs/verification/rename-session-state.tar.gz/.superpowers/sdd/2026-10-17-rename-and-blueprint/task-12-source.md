### Task 12: Bounded PCRE2 rule pipeline

**Files:** Create `crates/vidlib-rename/src/regex.rs`, `crates/vidlib-rename/tests/regex.rs`; update recipe/evaluate/Cargo.lock. Use a small safe wrapper over pcre2-sys to expose every approved limit explicitly.

**Interfaces:** `CompiledRegexRule::compile(rule: &RegexRule) -> Result<Self, RenameError>`; `apply(&self, input: &str) -> Result<String, RuleIssue>`. It integrates the existing segment/explanation pipeline and does not add a competing regex dialect for filters.

- [ ] **Step 1 — Red:** Add `lookarounds_pattern_backrefs_and_capture_replacement`, `literal_dollar_and_unmatched_optional_capture`, `first_all_and_case_modes`, `disabled_and_repeated_rules`, and `resource_limits_are_real` in a subprocess fixture.
  ```rust
  assert_eq!(actual, "Show - S02E03");
  assert_eq!(limits.match_limit, 1_000_000);
  assert_eq!(limits.heap_limit_kib, 8192); // PCRE2 uses KiB, not bytes
  assert_eq!(exhausted.code, RuleIssueCode::RegexLimit);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test regex`; the exhaustion fixture has a harness timeout solely to detect a hung test, not a promised regex timeout.
- [ ] **Step 3 — Implement:** UTF/UCP, no JIT, 16 KiB pattern cap, match/depth/heap configuration, named/numbered replacement validation and literal escaping. Compile once per enabled rule; use RAII for native allocations and document each unsafe FFI invariant in this one adapter. Limits/failures are structured row/rule issues, not silent nonmatches.
- [ ] **Step 4 — Verify green:** Regex tests plus text/graph regressions; inspect the effective binding calls for all limits and run the real native adapter on Windows CI.
- [ ] **Step 5 — Commit:** `feat: add resource-bounded PCRE2 renaming rules`.

