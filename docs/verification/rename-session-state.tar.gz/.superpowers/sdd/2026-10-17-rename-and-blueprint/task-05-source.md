### Task 05: App-wide and cross-process coordination

**Files:** Create `crates/vidlib-fileops/src/coordinator.rs`, `crates/vidlib-fileops/tests/coordinator.rs`, `src-tauri/src/app_state.rs`; modify fileops src/lib.rs, `src-tauri/src/jobs.rs`, `src-tauri/src/main.rs`, manifests/Cargo.lock.

**Interfaces:** Produces Coordinator/Lease and recovery gate from 4.3. Extend desktop state with Arc-managed plan/job registries and app-data paths, while retaining libraries.json preferences. Use fs4's OS shared/exclusive lock adapter, owned by RAII guards; each lease owns a separately opened lock-file handle and is not Clone, so one reader's Drop cannot release another reader's lock.

- [ ] **Step 1 — Red:** Add `readers_exclude_writer`, `writer_excludes_second_process`, `panic_releases_lease`, `startup_pending_journal_blocks_writes`, `other_process_epoch_revokes_old_plan`, and desktop tests that duplicate scans/actions use the same coordinator. A spawned fixture process must actually contend on the same lock file.
  ```rust
  assert_eq!(writer_attempt.unwrap_err().code, ErrorCode::Busy);
  assert_eq!(new_write.unwrap_err().code, ErrorCode::RecoveryRequired);
  assert!(coordinator.try_acquire(LeaseKind::Recovery).is_ok());
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test coordinator`; run desktop job tests where Tauri dependencies exist.
- [ ] **Step 3 — Implement:** Short process-local locks plus shared read/exclusive write OS lock file; check pending journals while holding the relevant lock. Integrate existing duplicate scan/action entry points and close-window handling. Cache browsing is allowed; new physical scans wait/refuse while a write/recovery is active. Return typed busy status and release all guards on error/panic.
- [ ] **Step 4 — Verify green:** Coordinator subprocess tests and existing job tests. Verify two installed app processes cannot mutate concurrently, not just two threads of one Jobs struct.
- [ ] **Step 5 — Commit:** `feat: coordinate collection reads writes and recovery`.

