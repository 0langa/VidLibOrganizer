# Task 10: Usable Rename vertical slice and bounded IPC

## Carried-tree and individual-file namespace orchestration handoff

Read the final Task06/07 reports for the shared planner/preflight/capture interfaces. Prepare namespace facts for original parents of all carried inventory descendants of selected directory moves, including unselected entries; the pure graph deliberately blocks unavailable facts instead of guessing path limits. Preserve individual-file selection: capture its authorized original source to observe sibling occupancy, rather than submitting an out-of-grant new sibling candidate or expanding sibling source authority. Keep all requested native facts Rust-owned through preview and execution.

## Recovery and partial-history handoff

Read the final Task08/09 reports. Recovery uses a consumed reviewed nonce, matching exclusive lease/store/current evidence, and v6 durable Restore context. Once Restore is chosen durably, Resume cannot switch its direction; present backend-derived available choices/continuation state. Unknown legacy interruption remains read-only unresolved and must not be cleared from an empty pending-operation list. Automatic safe partial-group compensation can leave Failed/Cancelled operations with earlier completed work; show factual outcomes/history/Undo availability rather than equating the batch label with no effects. Keep all recovery/undo targets backend-owned and use opaque references.


**Files:** Create `src-tauri/src/lib.rs`, `src-tauri/src/selection.rs`, `src-tauri/src/commands/mod.rs`, `src-tauri/src/commands/rename.rs`, `src-tauri/tests/command_contracts.rs`, `ui/jobs.js`, `ui/exact.js`, `ui/rename/main.js`, `ui/rename/preview.js`, `ui/rename/history.js`, `tests/ui/rename-basic.spec.mjs`, `tests/ui/fixtures/desktop-bridge.js`, `tests/ui/fixtures/command-contracts.json`, `tools/serve-ui.mjs`, `package.json`, `package-lock.json`, `playwright.config.mjs`; modify app_state/main/jobs, ui/index.html/main.js/api.js/styles.css/dom.js.

**Interfaces:** Implements the core commands and JS interfaces in 4.4 for Keep/FixedStem and current executable plans. Native selection returns grant/item IDs plus display strings; plans/history stay backend-paged. Existing library/finder flows keep their command signatures.

- [ ] **Step 1 — Red:** Add command tests `stale_nonce_cannot_apply`, `old_session_plan_is_invalid`, `page_never_returns_native_paths`; browser tests `rename_basic_preview_confirm_cancel`, `preview_response_after_edit_is_ignored`, `browser_preview_cannot_apply`, `exact_bytes_above_js_safe_integer`, and keyboard/dialog focus behavior.
  ```js
  await expect(page.getByTestId('rename-apply')).toBeDisabled();
  await expect(page.getByTestId('exact-bytes')).toContainText('9,007,199,254,740,993');
  expect(bridge.appliedTargets).toEqual([]);
  ```
- [ ] **Step 2 — Verify red:** `npx playwright test tests/ui/rename-basic.spec.mjs`; desktop command tests with `cargo test -p vidlib-tauri commands::rename` where native dependencies exist.
- [ ] **Step 3 — Implement:** Move desktop setup/command modules into a testable library with `pub fn run()` and keep main.rs as the small binary entry point; expose the narrow owned handler/adapter interfaces required by integration tests. Add Rename navigation/table/minimal rule editor exposing only implemented controls, confirmation summary, status polling, cancel/history/recovery, structured error formatting, generation-aware response acceptance and listener teardown. Use textContent/document fragments and BigInt formatting; no HTML string interpolation or JS rename engine. Scope mocked bridge to tests outside packaged UI; browser sample mode remains read-only. Add Playwright dev scripts and a localhost-only Node static server with correct module MIME types, without a build/bundler/runtime dependency.
- [ ] **Step 4 — Verify green:** Same tests, JS syntax checks, existing finder sample interaction tests, desktop owned-state serialization tests. UI renders at most one 200-row page and cannot enable a stale plan through out-of-order job completion.
- [ ] **Step 5 — Commit:** `feat: add Rename preview execution and recovery interface`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.1 Native paths, IDs, observations

Task 01 owns opaque UUID newtypes in `vidlib_inventory::ids`: `InventoryId`, `RootId`, `EntryId`, `GrantId`, `SessionId`, `JobId`, `PlanId`, `GroupId`, `StepId`, `OperationId`, `EventId`, `PresetId`, `CollectionId`, `AttemptId`, `AttachmentId`. IDs are not permissions. Revisions are Rust `u64`; schema versions are small `u32`.

`NativePathRecord { platform: WindowsUtf16Le | UnixBytes, bytes: Vec<u8> }` round-trips exact OS strings. Persist path keys as bytes, with a separate display string; only root-relative validated records enter portable inventories. Never use display strings or physical file IDs as unique path keys. Unsupported/unroundtrippable rename names remain visible issues. All new JSON u64/i128 counts/times/revisions are validated decimal strings; UUIDs are strings. SQLite stores exact quantities as decimal text, with fixed-width big-endian numeric sort keys where numeric indexing is required. Do not cast them to SQLite REAL or JS Number.

`FileStamp` contains optional physical identity, size for regular files, native-precision created/modified/accessed epoch-nanoseconds (`Option<i128>`), and Windows attribute bits. `PhysicalId` includes platform, volume identity, and file identity. `EntrySnapshot` contains EntryId, RootId, exact relative path, Rust-owned absolute PathBuf, display_name/display_path, kind, FileStamp, observation time, and issue state. File hard-link aliases remain separate entries. `RootBinding` contains RootId, backend-owned source grant, PathBuf, evidence, and capability facts; a binding records evidence absence separately from mismatch.

`Inventory { id, generation, roots, entries, coverage, window, issues }` is immutable. `ScopeCoverage` records exact directory, **listed child names even if stat fails**, `children_complete`, `subtree_complete`, outcome, filter fingerprint, observation interval, and issues. `JobControl` owns cancellation (`Arc<AtomicBool>`) and a bounded progress sink; `Progress { phase, done, total, current_entry }` is throttled to 10/s.

Public inventory interface: `scan(request: &InventoryRequest, control: &JobControl) -> Result<Inventory, InventoryError>`. Request grants come from backend native selection/validated manual paths; inventory sources can be roots or explicit files. Child traversal never follows a link/reparse point.

Task 01 also defines read-only `DirectoryFacts` and `NamespaceSnapshot` in inventory/model.rs: exact observed parent paths/entries, per-parent case/name/length facts, filesystem capabilities, source grants, protected-root/marker policy, persisted namespace/policy epoch and capture interval. `PlatformFs::capture_namespace(grants: &GrantSet, candidates: &[PathBuf])` in Task 02 populates these data types. Their definition never imports Rename/fileops. A test adapter can supply this same data to the pure planner.


### 4.4 Tauri/JavaScript and Blueprint contracts

Task 10 exposes owned command request structs and `Result<_, CommandError { code, message, phase, item_id, operation_id, retryable }>`; serialize using camelCase consistently. Commands clone Arc-managed handles under short locks, release guards, then start blocking workers. Job types carry owned results; query responses page at 200 rows. Never keep a std MutexGuard or rusqlite Connection borrow across await.

Core commands: `select_sources(PickerKind) -> SelectionDto`, `start_inventory(InventoryRequestDto) -> JobId`, `start_rename_preview(RenameRequestDto) -> JobId`, `job_status(JobId) -> JobStatusDto`, `cancel_job(JobId)`, `rename_page(PlanRef, PageQuery) -> Page<PlanRowDto>`, `confirm_rename(PlanRef) -> ConfirmationDto`, `apply_rename(PlanRef, confirmation_nonce) -> JobId`, `operation_history(PageQuery) -> Page<OperationDto>`, `recovery_preview(OperationId)`, `start_recovery(RecoveryRef, choice, nonce)`, `start_undo(OperationId) -> JobId`. Nonces bind the current session/revision/summary and are revoked on edits. Queries do not reauthorize native paths.

All **new** commands use one owned argument named `request` (wrap multi-field cases in the corresponding request DTO) plus managed state; JS invokes them with `{ request: dto }`. Existing commands retain their prior argument shape. Task 10 adds `src-tauri/tests/command_contracts.rs` and `tests/ui/fixtures/command-contracts.json` to verify camelCase/tag/decimal-string serialization against the same golden payloads used by browser mocks. PageQuery contains cursor, limit capped at 200, display sort/filter, and expected data revision; it never changes recipe numbering order.

Common JS interfaces: `watchJob(jobId, {signal, onProgress}) -> Promise<JobResult>` cleans up timers on finish/navigation/error; `createRecipeEditor({recipe, onChange}) -> {getRecipe(), setRecipe(recipe), destroy()}` never computes filenames; `formatExactBytes(decimalString)` uses BigInt and string-safe formatting. `call()` in `ui/api.js` remains compatible with existing commands while new errors are formatted centrally.

Blueprint Task 24 owns `BlueprintStore::open(path: &Path) -> Result<Self, BlueprintError>`, collection/RootBinding revision records, and paged queries. Task 25 owns `recognize(evidence: &RecognitionInput) -> RecognitionDecision` (`Known`, `CandidateNeedsConfirmation`, `IdentityConflict`, `MarkerOnlyNoLocalData`, `Unknown`), `register`, and `rebind` with expected binding revision. Task 26 owns `begin_refresh(collection_id, request) -> AttemptId`, `stage_inventory(attempt, inventory)`, and `promote_refresh(attempt) -> RefreshReport`; promotion commits baseline scopes and observed events together.

Task 27 owns `project_events(events: &[OperationEventV1]) -> ProjectionReceipt` with EventId uniqueness and transactional cursor updates. Task 28 owns `attach_template(collection, scope, preset_id, revision, recipe_snapshot) -> AttachmentId` and `summarize_patterns(selection, baseline_revision) -> PatternSummary`. Task 30 owns `export_bundle`, `validate_import`, `import_inactive`, `prune_history`, and `remove_collection`; none grants filesystem access or accepts executable journals.

Blueprint queries return `Page<MapEntryDto>`, `CollectionSummaryDto`, `Page<ChangeDto>` with observation interval/origin/confidence and separate last-attempt/last-complete times. Its commands mirror the store operations through owned DTOs, not SQL rows. Sending cached items to Rename resolves an explicit fresh native selection and scans again; stale EntryIds are never reused.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.


## Desktop baseline build prerequisite

Workspace-local GTK/WebKit native SDK is ready: source /workspace/.tools/desktop-env.sh; use CARGO_TARGET_DIR=/workspace/.tools/desktop-target for shared warmed desktop compilation. Baseline desktop tests fail only at tauri::generate_context! because src-tauri/icons/icon.png is missing (only icon.ico is tracked). When you integrate desktop code, add a faithful PNG encoding of the existing icon as a narrow build prerequisite, run desktop tests and include it with your integration commit; do not redesign the icon. This does not establish Windows runtime evidence.

## Task03 integration carry-forward

Task06 resolved the earlier deferred grant-snapshot consistency finding: PlanStore::publish now rejects divergent duplicated grants as well as frozen inputs. Preserve that single authority snapshot. Task06 also tests deterministic graph/DTO construction from identical frozen inputs (apart from the supplied PlanRef). Task10 owns actual fresh process sessions and invalidation on inventory/recipe/selection changes; pure PlanStore alone does not establish that wiring.

## Browser environment

/usr/bin/chromium is installed: Chromium 154.0.8037.57 on Debian13; Node v24.19.0 and npm11.9.0. Use actual browser execution for the owning Playwright tests; a normal configurable executablePath may select this binary if the managed browser cannot be downloaded. No browser pass is established by this version probe. Keep test/runtime tooling outside packaged ui.

Browser infrastructure probe now PASSED through Playwright using executablePath=/usr/lib/chromium/chromium and a real localhost HTTP server: returned Chromium154.0.8037.57, title VidLib probe, main text Browser works. Data/about:blank CLI probes timed out; data: navigation is blocked by existing managed policy, while localhost HTTP is allowed. Do not alter browser policies. Use HTTP fixtures/server for actual UI tests; this infrastructure smoke does not count as product UI test evidence. Temporary probe dependency is outside repo at /workspace/.tools/browser-probe; owning Task10 must commit its own package/lockfile.

## Task05 coordinator/registry handoff

After review clears, read task-05-report.md for Coordinator/Lease/Epochs/PlanRegistry APIs and schema v3. Lease is Send for worker handoff, !Sync and not Clone; Journal remains thread-owned !Send/!Sync. Hold the appropriate lease through all physical work and durable finalization. CoordinationStatus distinguishes pending_journal from interrupted_legacy_write; an empty Journal::pending() does not erase legacy uncertainty. Epoch values are backend u64 data without Serialize; any new IPC must use exact decimal strings. PlanRegistry validates coordinator ownership and namespace/policy epochs under a lease; consume needs ordinary Write. Task10 still owns inventory/recipe/selection invalidation. Native installedWindows/runtime remains pending.

Task05 added three Node tests in tests/ui/api.test.mjs for structured invoke errors. Preserve this coverage when adding package.json/test runners and include it in appropriate API/CI validation; it stays outside packaged ui. The error adapter preserves code/phase/IDs and readable .message while leaving successful status payloads unchanged.

## Current baseline clarification

Task05 already committed the faithful icon.png prerequisite and unblocked desktop tests. Preserve it; the earlier baseline-prerequisite paragraph is historical context, not a request to recreate the icon. Read the final Task09 report for historical lineage/visibility APIs once dispatched. A missing history-visibility row must not block independent recovery-evidence reads.

## Task09 final interface handoff (await independent review)

Read task-09-report.md. Undo is vidlib_fileops::undo::plan_undo with inverse_of carried through RenamePlan/ExecutionPlan/DTO and live Journal::begin canonical lineage validation. OperationRecord has inverse_of, history_visible and active_inverses; pending/unresolved or fully compensated originals do not offer Undo, but terminal Failed/Cancelled records may retain completed original groups. Journal::history uses stable high-water/keyset HistoryCursor and at most200 lightweight HistoryItems, exact decimal bounds/counts. Journal::remove_history hides completed history/revokes new Undo while retaining recovery/outbox/lineage; pending removal returns RecoveryRequired. Missing visibility must still allow recovery evidence reads. Capture fresh historically transformed grants, current epochs and full affected directory namespace in Rust; incomplete historical nested listings block directory Undo rather than authorizing from only a new scan. No second mutation engine or display-derived native target is allowed. Schema v7 is checked and preserves v1–v6 state.
