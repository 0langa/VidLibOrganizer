### Task 14: Typed templates and lazy frozen hash/random inputs

**Files:** Create `crates/vidlib-rename/src/template.rs`, `crates/vidlib-rename/src/hashes.rs`, `crates/vidlib-rename/tests/templates_hashes.rs`; extend metadata field model/evaluate. Add explicit hash/UUID/random dependencies without changing the old engine's MD5 interface.

**Interfaces:** `render_template(parts: &[TemplatePart], context: &TemplateContext) -> Result<String, RuleIssue>`; `freeze_inputs(request: &InputRequirements, inventory: &Inventory, control: &JobControl) -> Result<FrozenInputs, RenameError>`. File I/O is a separate input-preparation stage, not inside pure evaluation; source freshness is checked before/after content reads.

- [ ] **Step 1 — Red:** Add `all_template_field_families`, `missing_required_optional_and_fallback`, `original_and_current_stem_differ`, `hashes_match_independent_full_file_vectors`, `text_recipe_reads_no_contents`, `generated_tokens_survive_repeated_preview`, and `hash_cancel_and_stale_source`.
  ```rust
  assert_eq!(optional_result, "Movie (2020)"); // no dangling resolution brackets
  assert_eq!(abc_sha256, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  assert_eq!(content_read_count_for_text_only, 0);
  assert_eq!(first.uuid_tokens, second.uuid_tokens);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test templates_hashes`.
- [ ] **Step 3 — Implement:** Template AST fields/formatters, fallback/optional behavior, exact numeric/date formatting; prepare each requested full-file CRC32/MD5/SHA-1/SHA-256/SHA-512 digest once using a bounded 1 MiB buffer and chunk cancellation. Store clock/random results in FrozenInputs. Verify all five algorithms against fixed independent known vectors, not another call to the production hash function.
- [ ] **Step 4 — Verify green:** Template/hash tests plus date contracts; compare files differing only beyond the first buffer and assert a required missing metadata property blocks the row.
- [ ] **Step 5 — Commit:** `feat: render typed templates with frozen lazy inputs`.

