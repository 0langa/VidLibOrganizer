# Task implementer contract

Work only in `/workspace/VidLibOrganizer/.worktrees/rename-blueprint`, on the existing isolated branch. The supplied task brief is the requirements source and contains the exact constraints, shared interfaces and ownership. Read it first; do not read the whole canonical plan or restart the approved design. Raise real ambiguities with the controller and keep unrelated scope untouched.

Follow the official implementer template at `/workspace/scratch/superpowers-source/skills/subagent-driven-development/implementer-prompt.md`, plus `/workspace/scratch/superpowers-source/skills/test-driven-development/SKILL.md` and its `writing-good-tests.md` reference. Never spawn helpers, implementers, reviewers or other subagents. The controller supplies independent review after your report.

Implement the task's test-first sequence. Record meaningful named assertion failures before the corresponding implementation; distinguish missing-interface compilation failures and vacuous stub successes from intended behavioral reds. Use real temporary data/files/databases where appropriate. Iterate with focused covering tests. Run the applicable broader suite once before completion; repeat only after changes or failures justify it. Keep output free of unexplained warnings. Do not add tests that merely mirror implementation or test trivial reversible edits.

Keep dependency direction and backend-owned native paths intact. Preserve existing duplicate-finder behavior. Add only dependencies owned by this task and commit the lockfile. Preserve distinct pending platform checks; cross-compilation never establishes Windows runtime behavior.

Rust command-scoped environment:

```sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target CARGO_INCREMENTAL=0 CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

The shared target above is for Linux checks, including core-only packages, to avoid duplicate derived binaries. For Windows-target checks set CARGO_TARGET_DIR=/workspace/VidLibOrganizer/.worktrees/rename-blueprint/target (separate from Linux), source `/workspace/.tools/windows-check-env.sh` in a fresh shell and specify the target explicitly. Do not carry the Linux shared CARGO_TARGET_DIR into Windows cross-builds. For Linux desktop tests/builds, source `/workspace/.tools/desktop-env.sh` and use `CARGO_TARGET_DIR=/workspace/.tools/desktop-target`. Do not carry a Windows cross-compiler environment into Linux builds. Consult the brief/controller for the current desktop baseline and task-specific checks.

Self-review the final diff for missing requirements, unsafe edge cases, unrelated edits, dependency direction and focused module responsibilities. Run the task's required verification, appropriate scoped Clippy, formatting and `git diff --check`. Commit task-owned code and required manifest/lockfile changes. Do not edit the canonical checklist, push, merge, publish, or change branch/worktree state.

Write the complete report at the supplied task report path. The .superpowers/sdd workspace is ignored process state: never force-add its reports, briefs, packages or ledger to git. Keep the required report there for handoff; any justified tracked verification copy belongs under docs/verification, outside this cleanup workspace. Include public interfaces, implementation scope, named red/green evidence (expected/actual and commands), final checks with outcomes and sufficient output or precise raw log paths, self-review, commit hashes, and pending checks/limitations. For fixes, append covering test files, exact command and output to the same report before returning. Return a short status (`DONE`, `DONE_WITH_CONCERNS`, `NEEDS_CONTEXT`, or `BLOCKED`), commit hashes, one-line tests, concerns, and report path. Never replace the on-disk report with a long chat response.


Managed cloud environment: obtain current environment_status at resumed/new managed work where that tool is available. Cloud skills are currently unavailable after a catalog refresh; use cloud-runtime-handoff.md in this workspace for the already-read runtime requirements, rather than stalling on an unavailable package. If cloud-environment-runtime becomes available again, read it normally. Before network fetches, follow that handoff networking guidance (or the available skill reference) and read the selected executor network-policy.json; preserve inherited proxy/CA and inspect only credential readiness metadata, never values. Do not reuse old readiness after environment replacement. The controller handles child scheduling recovery; report a concrete blocked tool rather than restarting task/design.

Build disk note: Task14 exhausted the 32 GiB derived-build volume; preserve CARGO_INCREMENTAL=0 for this work. If ENOSPC recurs, stop/wait active builds before clearing only derived stale outputs/caches; preserve source, tools, lockfiles and verification evidence. Record infrastructure interruptions separately and rerun interrupted/failed checks only.

Linux browser-check note: use `env -u NO_COLOR npm test` (or the applicable focused Playwright command) to avoid the inherited NO_COLOR/FORCE_COLOR conflict warning; keep product behavior unchanged. Record any actual test/browser warnings rather than silently filtering them.

Rootless SDK update after Task15 cross-check ended: controller added missing /workspace/.tools/mingw-sysroot/usr/bin/x86_64-w64-mingw32-gcc symlink to already pinned gcc-posix. Minimal windres input including windows.h compiled successfully (exit0,188-byte object). No repository/product change. Earlier Task14/15 desktop cross-check runs remain honestly blocked; a later full desktop cross-check can now be attempted for changed Windows code. This preflight is not desktop compilation or Windows runtime proof.
