# Task 13: deterministic numbering and explicit dates

Status: DONE. Base `1359202` (Task12 approved canonical update).
Commit: `a249c4a` — `feat: add stable numbering and explicit date formatting`.
Worktree `/workspace/VidLibOrganizer/.worktrees/rename-blueprint`, existing branch `feat/rename-blueprint` retained. Sole implementer; no helpers, canonical edits, pushes, merges, or branch/worktree changes. This report and raw logs are ignored process state and were not force-added.

## Scope and public interfaces

New modules `crates/vidlib-rename/src/numbers.rs` and `dates.rs`, integration tests `tests/numbers_dates.rs`; narrow owning changes in lib/model/recipe/evaluate/text and owning Cargo manifest/lockfile.

- `NumberingOrder = Vec<EntryId>` retains the existing recipe/frozen vector representation.
- `NumberAssignments = BTreeMap<EntryId, String>` associates formatted values by backend entry ID.
- `assign_numbers(entries: &[EntrySnapshot], order: &NumberingOrder, rule: &NumberRule) -> Result<NumberAssignments, RenameError>` validates explicit primary order and assigns counters without observing display ordering.
- `NumberRule { start: i128, step: i128, repeat_each: u64, padding: u64, radix: Radix, reset_by_folder: bool, at: InsertPosition, prefix: String, suffix: String }`.
- `format_number(value: i128, radix: Radix, padding: u64) -> Result<String, RuleIssue>` and `pad_existing_numbers(input: &str, padding: u64, scope: MatchScope) -> Result<String, RuleIssue>`.
- `format_date(value: &DateValue, rule: &DateRule, env: &FrozenEnvironment) -> Result<String, RuleIssue>`.
- Typed `DateValue::{Instant { ns }, Local { value: NaiveDateTime, timezone }, Date { value: NaiveDate }, Text { value }, Missing}`. Date-only and civil datetime values serialize as ISO strings, never JS numeric timestamps.
- `DateRule { input_format, output_format, timezone, assume_timezone, ambiguity, nonexistent }`; `DateOperation::{Insert { source, at, prefix, suffix, rule }, Reformat { rule }}`.
- `FrozenEnvironment { now_ns, timezone, ambiguity, nonexistent }` plus `FrozenEnvironment::freeze(...)` validates an explicitly captured instant/zone. The standalone formatter uses this frozen environment's selected DST policies; evaluation constructs it from the frozen inputs and the recipe's selected policies. The output zone is the rule's explicit zone, falling back to the frozen environment zone.
- `resolve_local_timezone() -> Result<FrozenTimezone, RenameError>` is the sole explicit host-zone resolver. It resolves through iana-time-zone, confirms against bundled chrono-tz, and returns a zone for input preparation to retain. The evaluator never calls it, reads a clock, or consults host-local timezone state.
- New tagged `RuleParameters::{Number { rule }, PadNumbers { padding, scope }, Date { operation }}` reject unknown fields/tags through the existing recipe schema.
- `FrozenFieldValue::LocalTimestamp { value: chrono::NaiveDateTime, timezone: Option<FrozenTimezone> }` carries actual typed civil recording times without an invented zone.
- `RuleIssueCode` and `RenameErrorCode` gain `DateNeedsFormat`, `DateTimezoneUnknown`, `DateAmbiguous`, `DateNonexistent`, `DateMissing`, `DateInvalid` through the existing error interface. Existing regex native diagnostics remain intact.

## Precise semantics

Counter ordinal starts at zero; the checked expression is `start + (ordinal / repeat_each) * step`. Both multiplication and addition are checked i128 operations. `repeat_each == 0` is InvalidRecipe, arithmetic overflow is ArithmeticOverflow, nonpositive alphabetic values are InvalidRuleInput. Decimal and hex accept signs, including i128::MIN; zero padding applies only to magnitude after the minus sign. Alphabetic upper/lower is spreadsheet style (1=A/a, 26=Z/z, 27=AA/aa), with no zero digit or numeric zero padding. Padding is bounded at 4096.

Only entries explicitly present in the supplied frozen primary vector consume ordinals. The inventory vector may be reordered without changing assignments; the original vector itself resolves all assignment ties. Duplicate inventory IDs, duplicate primary IDs, and absent numbering IDs are rejected. Per-folder counters use the original native `absolute_path.parent()`, retaining independent counters for interleaved source folders. Unchanged/blocked primaries still occupy their frozen ordinal until explicit exclusion creates a new recipe/vector. Nonprimary assets never consume numbers through assign_numbers; the evaluator's existing rejection of companion configurations remains until their owning later task supplies propagation. No partial companion support is advertised.

Counter prefix/suffix and position operate within the selected current segment, using existing Unicode grapheme insertion semantics. Independently padding existing numbers finds ASCII decimal runs, pads without integer parsing, preserves existing leading zeros/signs/non-ASCII digits/text, and supports First/All. It cannot overflow from a long existing digit run.

Date formats use the already documented pinned subset `%Y %m %d %H %M %S %f %z %:z %%`. Locale names/composites/arbitrary modifiers are rejected. Format classification uses chrono's parsed items, so literal `%%H` and `%%z` cannot accidentally demand time/offset fields. Without an input format, only complete RFC3339 offset timestamps are self-describing; other text produces DateNeedsFormat. Explicit formats parse either offset-aware datetime, civil datetime, or date-only values. Malformed/mismatched dates yield DateInvalid. A date-only value cannot supply an invented time/offset. Leap seconds are rejected because epoch nanoseconds cannot represent them without changing their meaning. Negative epoch nanoseconds use Euclidean division, preserving fractional seconds exactly.

UTC, confirmed bundled IANA zones, and fixed offsets within ±86399 seconds are supported. A known source zone wins over an assumption. Output zone is not an implicit input-zone assumption. Unknown civil/recording timezone produces DateTimezoneUnknown unless the rule explicitly selects `assume_timezone`. Existing `Timestamp { ns, timezone: None }` retains unknown status; if an assumption is selected, its epoch-relative civil components are localized in that zone. New metadata producers should use LocalTimestamp for civil time. Known-zone Timestamp values are absolute instants and are converted normally.

DST ambiguity policy is Reject/Earliest/Latest, choosing the earlier/later actual instant. Nonexistence policy is Reject/NextValid/PreviousValid. Next/Previous search explicitly for the nearest valid wall-clock second in that direction, preserving the input subsecond fraction, bounded to 48 hours (also covering IANA skipped-day transitions). No gap/overlap is silently resolved. Berlin fixtures pin 2026-10-25 02:30 to UTC 00:30/01:30 and 2026-03-29 02:30 to rejection or explicit UTC 01:00:00/00:59:59 boundary choices.

Created, Modified and Accessed read their separate immutable inventory stamps. Recorded only reads the explicit frozen recording field (rule-specific first, then shared); it never substitutes filesystem dates. Now uses the existing frozen `now_ns` exactly. Absent requested values produce DateMissing and block the row.

All newly introduced numeric fields use canonical decimal strings: start/step/repeat/padding/insertion indices/instant nanoseconds/environment now. FixedOffset seconds now uses the same exact protocol through a bounded i32 adapter; numeric offsets are rejected on import. Existing bounded text-rule selector/position fields retain their established schema. `deny_unknown_fields` and existing canonical decimal adapters reject JS numeric values, signs/leading zeroes and overflow as applicable.

All name edits route through the existing `text::apply_segment`, `NameParts`, and component validation, against each rule's current input. A failed rule blocks its row, leaves the original target/display name, and retains prior successful explanations. Number assignment is prepared once per enabled rule before rows; Task12 enabled regex compilation remains once per rule before rows, with its compile-count unit test passing. No JS rename engine, speculative UI controls, filesystem mutations, or unrelated dependencies were added.

## Test-first evidence

All raw logs below are in this report's ignored directory. Commands run in this worktree with:

```
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

1. `cargo test -p vidlib-rename --test numbers_dates` → exit 101, six named failures, `task-13-red-schema.log`. Real serde assertions showed unknown number/date/pad rule tags. Compilation succeeded; these were not missing-interface compiler errors.
2. After schema-only declarations, same command → exit 101, six failures with real UnsupportedRule evaluation results, `task-13-red-evaluation.log`. Added broader cases before implementation; same command → exit 101, ten failures, `task-13-red-behaviors.log`. Named behaviors:
   - `natural_display_sort_does_not_change_number_order` expected `10-01.mkv`, `2-02.mkv` despite inventory reorder.
   - `counter_repeat_step_reset_and_formats` expected `01,01,03,03`.
   - `pad_existing_number_in_segment` expected `S002E010.MKV`.
   - `ambiguous_date_requires_format` expected DateNeedsFormat.
   - `explicit_date_reformat` expected `2026-10-17.MKV` from `%d-%m-%Y`.
   - `missing_recording_timezone_stays_unknown` expected DateTimezoneUnknown.
   - `dst_ambiguity_is_explicit` expected Berlin overlap/gap rejection or explicit UTC results.
   - `counter_alphabetic_signed_padding_and_source_parent_resets` expected Y/Z/AA, negative signed magnitude padding, and interleaved source resets.
   - `counters_reject_invalid_repeat_and_checked_overflow` expected exact error categories.
   - `explicit_dates_restore_original_target_and_prior_explanations` expected blocked original name with retained prefix explanation.
3. Implemented arithmetic/formatting/date adapter/shared evaluator path. Same command → exit 0, all ten passed, `task-13-green-initial.log`.
4. Added exact-JSON and source/zone/segment qualification. `cargo test --locked -p vidlib-rename --test numbers_dates` → exit 101, 12 passed/2 failed, `task-13-red-exact-json.log`. `exact_numeric_json_and_bounded_configuration` found new insertion positions incorrectly required JS numbers; `date_fixed_iana_utc_and_recorded_assumption` found exact-string fixed offsets rejected by legacy i32 serde. Added canonical adapters for new positions and fixed offsets; same command → exit 0, 14 passed, `task-13-green-exact-json.log`.
5. Added standalone assignment and typed civil recording coverage. Same locked command → exit 101, 16 passed/2 failed, `task-13-red-boundaries.log`. `assignment_rejects_duplicate_inventory_and_skips_nonprimary_entries` received Ok assignments for duplicate inventory IDs; `typed_recording_local_time_uses_explicit_zone_and_policy` received unknown LocalTimestamp variant. Added duplicate validation and typed civil timestamps. Focused scoped command below → exit 0, 104 distinct tests at this stage, `task-13-green-focused.log`.
6. Self-review regression tests added before fixes. Same locked numbers_dates command → exit 101, 18 passed/2 failed, `task-13-red-date-loss.log`. `date_format_literals_are_not_mistaken_for_time_or_offset_fields` got DateInvalid/insufficient time fields for literal `%%H`; `date_parsing_preserves_explicit_offsets_and_rejects_lossy_leap_seconds` got successful `2017-01-01_00-00-00` from `2016-12-31T23:59:60Z`. Fixed parsed-format classification and rejected unrepresentable leap seconds; final scoped command → green, `task-13-green-final-focused.log`.

Additional qualification tests cover i128::MIN formatting, lowercase spreadsheet representation, negative 1ns timestamps, chrono range errors, invalid format/zone, source-specific missing dates, repeated frozen now, UTC/fixed/IANA conversions, explicit assumptions, current selected ranges, extension preservation, grapheme insertion positions, zero positions blocking/restoration, exact JSON rejection and First padding preserving large/zero-padded/non-ASCII text. These green qualification assertions are not misrepresented as independent earlier reds.

## Final verification

All checks ran after the final production fix and before commit. No unexplained warnings/errors remain.

- `cargo test --locked -p vidlib-rename --lib --test numbers_dates --test regex --test text --test contracts --test graph` → exit 0; **106 distinct tests**: 1 compile-count unit + 20 numbers_dates + 13 regex + 14 text + 18 contracts + 40 graph. Log `task-13-green-final-focused.log`. The regex child repeats its one resource fixture; raw result-line sum is 107 and is not counted twice.
- Fresh shell `source /workspace/.tools/desktop-env.sh`, then `CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace` → exit 0; **365 distinct tests**, zero failures/ignored/warnings, `task-13-workspace.log`. The result-line sum is 366 due to the same isolated resource child. Includes existing duplicate/engine, fileops, inventory, rename and desktop suites. Full workspace run performed once after final source changes.
- `cargo clippy --locked -p vidlib-rename --all-targets -- -D warnings` → exit 0, `task-13-clippy.log`.
- `cargo fmt --all --check` → exit 0, `task-13-fmt.log` (empty output).
- `git diff --check` → exit 0, `task-13-diff-check.log` (empty output).
- Fresh shell `source /workspace/.tools/windows-check-env.sh`, then `cargo test --locked -p vidlib-rename --target x86_64-pc-windows-gnu --no-run` → exit 0, all six executables linked (unit/contracts/graph/numbers_dates/regex/text), `task-13-windows-link.log`. None executed on Windows.
- `/workspace/.tools/mingw-sysroot/usr/bin/x86_64-w64-mingw32-objdump -p target/x86_64-pc-windows-gnu/debug/deps/numbers_dates-6fa67bac867f41ff.exe` → exit 0, `task-13-windows-imports.log`; imports are Windows OS DLLs, including COM/WinRT OS APIs used by the explicit local-zone resolver. No additional chrono/tz/script runtime DLL.
- Final `git diff --cached --check` passed before commit. Postcommit `git status --short` is empty.

## Dependency and self-review notes

Only task-owned direct dependencies were added to vidlib-rename: chrono 0.4 (default features off, std/serde enabled), chrono-tz 0.10, iana-time-zone 0.1. Existing lock already held chrono 0.4.44 and iana-time-zone 0.1.65; new packages are chrono-tz 0.10.4 and its phf/phf_shared 0.12.1. Existing phf dependencies acquire version qualification because two versions coexist. Cargo fetch attempted an unrelated cssparser-macros syn edge re-resolution; restored the original syn 2.0.117 edge before all locked verification. No unrelated package versions changed. The compiled IANA database is offline; no network or installed script runtime is required for renaming.

Self-review covered checked intermediates/MIN, padding and alphabetic boundaries, duplicate/absent order IDs, companion exclusion/source-parent reset, exact serde types and bounded imports, explicit zone validation and absent-zone behavior, leap/negative timestamps, parsed literal formats, distinct date sources, frozen now/policy, DST gap bounds, current-input segments/extensions/component errors, target restoration/explanations, regex compile-once and native static configuration, dependency direction and changed-file scope. Found and fixed duplicate inventory acceptance, typed civil timestamp integration, escaped directives and lossy leap conversion with recorded reds. Existing native regex code/static configuration is unchanged. No unresolved implementation correctness concern identified; independent controller review remains required.

Managed-cloud status and networking references/policy were read before fetch; current status observed connected/running/enforced unrestricted HTTP with no configured credentials. Preserved inherited proxy/CA. A final-review exec transport disconnect recovered immediately on retry; rechecked current environment_status, same environment/spec, and resumed existing files/logs without restart or repeated suites.

Actual Windows execution/CI, MSVC packaged release, OS local-zone runtime behavior, NTFS/exFAT/network-share behavior, and hardware/performance checks remain pending. Cross-linking/import inspection does not establish them. No release gate is opened: Rename is still an intermediate backend slice; future template/metadata/companion/UI integration stays with its owning tasks, and Blueprint remains separately incomplete.
