# Task 27: Idempotent operation projection and duplicate-action bridge


**Files:** Create `crates/vidlib-blueprint/src/operations.rs`, `crates/vidlib-blueprint/tests/operation_projection.rs`, `crates/vidlib-fileops/src/duplicate_events.rs`, `crates/vidlib-fileops/tests/duplicate_events.rs`; extend old fileops helpers narrowly, journal/outbox and Tauri coordinator delivery.

**Interfaces:** Implements project_events/ProjectionReceipt; an EventId unique insert and projection cursor commit in blueprint.sqlite3 precede outbox acknowledgement. Add `apply_duplicate_actions_with_journal(result, paths, action, destination, lease, journal) -> ActionReport`, preserving the existing outward report/keeper/hash behavior. Internal receipts carry actual destinations and completed phases.

- [ ] **Step 1 — Red:** Add `event_replay_and_crash_before_ack_project_once`, `refresh_matches_app_event_without_duplicate`, `intervening_external_change_is_preserved`, `projection_failure_never_repeats_mutation`, `duplicate_move_records_actual_destination`, `duplicate_delete_keeps_existing_guards`, and `pruning_never_removes_unacknowledged_event_identity`.
  ```rust
  assert_eq!(store.changes_for_operation(op)?.len(), expected_fact_count);
  assert_eq!(filesystem_mutation_calls, 1);
  assert_eq!(receipt.actual_destination, real_destination);
  assert_eq!(retained_keeper_bytes, b"fixture");
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test operation_projection`; `cargo test -p vidlib-fileops --test duplicate_events --test actions`.
- [ ] **Step 3 — Implement:** Commit receipt/event projections and consumption cursor together, then ack the source outbox; replay by EventId after restart. Record a local root-activation event cursor/registration epoch so delayed events from a removed or earlier binding cannot resurrect its history. Exact known updates invalidate freshness and correlate with later observations without suppressing genuinely different external changes. Add pre-intent/post-receipt hooks around legacy duplicate mutations to capture actual destination/final phase durably; preserve current duplicate safety and avoid changing its collision policy as an unrelated refactor. Permanent duplicate deletion remains non-undoable. Unknown/unregistered roots do not auto-register; acknowledge irrelevant events explicitly without inventing collection history.
- [ ] **Step 4 — Verify green:** Replay before/after each DB commit/ack, Blueprint disk-full/corruption, multi-root event fan-out and existing 36 portable tests plus Windows-specific duplicate tests. A successful source operation remains successful even while Blueprint is unavailable.
- [ ] **Step 5 — Commit:** `feat: project durable file-operation facts into Blueprint`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


### 4.3 Execution, journal, events, and coordination

Task 04 owns Journal, StepReceipt, event/state persistence and `Journal::open(path: &Path) -> Result<Journal, OpError>`, `begin(&mut self, plan: &ExecutionPlan) -> Result<OperationId, OpError>`, `intent(&mut self, op, step: &ExecutionStep) -> Result<(), OpError>`, `complete(&mut self, op, receipt: &StepReceipt) -> Result<(), OpError>`, `pending(&self) -> Result<Vec<PendingOperation>, OpError>`, `events_after(cursor, limit) -> Result<EventPage, OpError>`, and `ack_events(&mut self, ids: &[EventId]) -> Result<(), OpError>`. ExecutionPlan/ExecutionStep are imported from Rename's pure model, not redefined. A connection is opened/used on its owning blocking thread; read queries use separate connections. Set/verify WAL, FULL, foreign_keys=ON, busy_timeout=5000 ms; migrations/intent/receipt transactions use BEGIN IMMEDIATE and explicit commit. No SQLite transaction spans filesystem I/O.

Own schema: `schema_migrations`, `operations`, `steps`, `receipts`, `operation_events`, `outbox_ack`, `history_visibility`; Task 25 adds protected-root policy tables. Each step stores full native path codec, expected prestate, object/temporary ownership, group/sequence, and observed poststate; plan/recipe inputs are stored for inspection but recovery uses the compiled steps. State machine: Prepared -> Running -> Completed / Cancelled / Failed / RecoveryRequired; steps Planned -> IntentDurable -> Applied -> CompletionDurable, or Compensated/Unresolved. Applied is the observed in-memory action state until its receipt transaction commits; a restart without that receipt follows reconciliation, not a fabricated durable flag. SQLite commit failure stops the next filesystem step.

`ExecutionStep` variants cover RenameEntry, CreateDirectory, StageCopy, PublishCopy, RemoveSource, SetMetadata, RemoveOwnedCopy, and RemoveOwnedEmptyDirectory, with exact expected states. `StepReceipt` records actual paths/identity, digest when applicable, metadata, completed phase, and durability result. Store intent before action and receipt after action; reconcile the action/receipt gap by identity, not blind retries. One dependency group is the compensation unit; completed prior groups remain completed.

Rename-cycle temporary names are logical reservations recorded in the graph/journal; the first no-replace move materializes the path atomically. Do not create an empty placeholder and then overwrite it. Copy staging uses create-new ownership with a recorded native identity, and publication still uses no-replace semantics.

`OperationEventV1` contains stable EventId, OperationId, GroupId, StepId, kind, completed phase, native before/after paths, before/after FileStamp, digest if available, observed time, `origin: App`, and journal sequence/provenance. Emit facts for each completed phase, including a verified published copy whose later source removal fails. Events and receipts commit together. Imported reports never become executable journals.

Task 05 owns `Coordinator::open(app_data: &Path) -> Result<Coordinator, OpError>` and `try_acquire(kind: LeaseKind) -> Result<Lease, OpError>` with RAII Read/Write/Recovery leases. Use Tauri's `app.path().app_local_data_dir()` for the two databases and lock file, validate local storage, and retain the existing app_config_dir libraries.json location. Use a per-app-data OS advisory lock file (shared readers, exclusive writer), plus process-local job registry and startup pending-journal gate. A recovery lease is exclusive but may enter RecoveryRequired state. No destructive job bypasses it, including legacy duplicate actions. A second instance cannot write to this app data concurrently. Denied acquisition returns Busy/RecoveryRequired, not a blocking UI wait.

The operation store also owns a monotonic namespace/policy epoch. Read/capture it under a read lease, store it with the plan, and compare again inside the write lease before preflight. Increment it after any app path mutation or protected-root policy update, including partial success, before releasing the lease. Read queries/registries use it to revoke stale results across app instances. An intent/receipt failure leaves the recovery gate active rather than authorizing a stale plan. Blueprint root registration cannot retroactively permit an older plan to rename a newly protected root.

Task 07 owns `execute(plan: &RenamePlan, lease: &Lease, journal: &mut Journal, fs: &mut dyn Filesystem, control: &JobControl) -> Result<OperationReport, OpError>`. The real Windows and Linux adapters and fault-injection test adapter implement `Filesystem`: capture/verify state, no-replace rename/publish, owned directory/staging creation, verified content I/O, metadata changes, and flush results. `OpError` has stable code, phase, operation/step/item IDs when known, message, and retryability; UI receives a serializable DTO, not a panic/debug dump.

Task 08 owns `reconcile(op: &PendingOperation, fs: &mut dyn Filesystem) -> Result<RecoveryPreview, OpError>` and `apply_recovery(preview, choice: Resume | Restore, lease, journal, fs, control) -> Result<OperationReport, OpError>`. Task 09 owns `plan_undo(completed: &OperationRecord, namespace: &NamespaceSnapshot, version: PlanRef) -> Result<RenamePlan, OpError>`; inverse operations use the same executor/journal/confirmation flow.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.


## Protected-root integration distinction

Normal contents of saved/registered library roots remain usable by Rename. Protect the root entry itself, active markers, and any selected ancestor move that would carry a protected root; do not exclude every descendant of a Blueprint root. Inventory ProtectedPolicy.roots currently denotes excluded subtrees (for app-local/private/staging protection). Do not feed Blueprint root guards into that subtree-exclusion list without distinguishing exact root-entry/ancestor protection from private subtree exclusion. Keep registered-library rename workflows covered by integration tests.

## Task04 compiled-step handoff

Task04 corrected the initial Task03 action model to the eight section4.3 variants with action-specific native fields. Read task-04-report.md for EntryPrestate/ExpectedIdentity/OwnedEntryPrestate, private persistence and exact Journal APIs; do not reintroduce flattened dummy source fields or duplicate ExecutionStep in fileops. References resolve to committed poststates of earlier steps in the same group or declared dependencies; owned compensation stays in its dependency group. Task09 must validate historical receipt/identity/digest ownership for undo through the same journal/executor and may extend the typed inverse data as its plan specifies; current-operation receipt references alone do not establish historical undo authority.

## Task05 legacy-write gate handoff

Task05 may add a durable interrupted-write/epoch marker in operations.sqlite3 around legacy duplicate actions before Task27 supplies per-effect journals. Read task-05-report.md for the finalized API/state. This marker is a conservative unresolved gate, not per-item completion evidence. Do not clear it on open, infer actual destinations/completed facts from it, or pretend it is a compiled recoverable operation. Task08 must expose any unknown legacy interruption as read-only unresolved inspection, retain its evidence and allow only genuinely verified resolution. Task27 must route legacy destructive jobs through its planned pre-intent/post-receipt bridge, preserve actual outcomes/destinations and replace transitional marker-only coverage for new actions. Unknown historical ownership remains unresolved; no guessed deletion, replay or fabricated completion.

## Task05 coordinator/registry handoff

After review clears, read task-05-report.md for Coordinator/Lease/Epochs/PlanRegistry APIs and schema v3. Lease is Send for worker handoff, !Sync and not Clone; Journal remains thread-owned !Send/!Sync. Hold the appropriate lease through all physical work and durable finalization. CoordinationStatus distinguishes pending_journal from interrupted_legacy_write; an empty Journal::pending() does not erase legacy uncertainty. Epoch values are backend u64 data without Serialize; any new IPC must use exact decimal strings. PlanRegistry validates coordinator ownership and namespace/policy epochs under a lease; consume needs ordinary Write. Task10 still owns inventory/recipe/selection invalidation. Native installedWindows/runtime remains pending.

Task05 review also retains the global native-path/ID contract for legacy IPC. Current duplicate command still accepts its legacy path-string selection. In the bridge, adapt backend-owned scan entries to opaque item IDs for UI actions and resolve selected IDs to exact native paths in Rust, preserving duplicate behavior/keeper/hash/report fixtures. Any necessary narrow Tauri/UI adapter edits are authorized by this integration requirement; do not turn display strings into execution authority or replace the engine scan. Preserve unknown legacy-marker evidence; new bridged writes must have genuine per-effect journal/receipt provenance rather than infer completion from an empty pending list.
