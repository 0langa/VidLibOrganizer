# Rename phase combined fix round

This is a controller-prepared contract. The complete final findings and controller rulings must be appended before dispatch; provisional reviewer checkpoints are not the work order.

User scope: complete reviewed Rename through Task23, then pause BEFORE Blueprint24. Do not rush, start Blueprint, push/merge/publish/release, create the final bundle, delete process state or change the canonical checklist. Native Windows qualification remains PENDING and production gates CLOSED.

Worktree: /workspace/VidLibOrganizer/.worktrees/rename-blueprint. Branch: feat/rename-blueprint. Fix BASE: f7595687788376343c1c8067e6b03167dde0b200. The source is clean and all builders stopped. One implementer owns this entire fix round; no helpers, reviewer dispatch or parallel product writers.

Read the official Superpowers implementer/TDD instructions, local implementer-contract.md, final rename-phase-review.md, and the controller's complete findings/rulings below. The approved Rename/library-tools specs remain authoritative; the full32-task canonical plan is retained, with today's boundary before24. Read relevant final prior task reports/source only for the interfaces you change. Preserve all current rulings and native grant/receipt/metadata authority.

Address all Critical/Important findings together and give every deferred item an explicit result/evidence or remaining concern. Do not silently discard findings or invent broader frameworks/refactors. Raise a concrete ambiguity or new compatibility/resource policy to root while continuing independent fixes; root records rulings, without a user design restart.

Use meaningful bounded behavioral reds, then focused greens and appropriate final affected checks. Distinguish fixture/compiler failures from behavioral reds; avoid OOM or unbounded stress. Preserve no-clobber, exact Rust-owned paths/quantities, whole-selection validation, revision/epoch/recovery ownership, immutable original and factual prestate/receipt lineage, and no filesystem I/O inside SQLite transactions. Progress/inspection must never become mutation authority or fabricate completion.

Existing evidence at BASE:633parent Rust tests/4Node57browser/4Python, workspaceClippy/fmt19JS/diff, Linuxrelease and GNUWindowsalltarget checking,8helperresources/NSISsourceharness pass. This is a baseline, not post-fix evidence. Native runtime/install/storage/reference performance stays pending. Existing100kselected recipe-cap refusal, naturaldebug latency, large-inverse costs and aggregate-memory limits are explicit; report exactly what the fixes change or leave unqualified.

Environment: source /workspace/.tools/desktop-env.sh for Linux, CARGO_TARGET_DIR=/workspace/.tools/desktop-target, CARGO_INCREMENTAL=0. Fresh separate shell source /workspace/.tools/windows-check-env.sh for x86_64-pc-windows-gnu and worktree target directory. Use --no-fail-fast (not unsupported --keep-going). env -u NO_COLOR for needed UI checks. Disk last2.5GiB free; coordinate stopped-safe derived cleanup with root before large builds. Preserve active artifacts, source/tools/lock/evidence. Read current managed network policy before public dev-tool fetches; preserve proxy/CA and never print credentials.

Commit completed source/tests/docs and append a complete report at rename-phase-fix-report.md in this process directory: each finding's disposition, exact red/green and final commands/output, commit IDs, residuals and native pending checks. Update tracked verification/handoff for changed evidence and every current ruling/reason/cost/order. Do not stage ignored process artifacts. Root owns canonical status, full fix-range package, ONE scoped re-review, residual adjudication, final tracked handoff and verified backup after all commits. No second broad fix round is authorized by this contract.

## Complete findings and controller rulings

Pending final review report.
