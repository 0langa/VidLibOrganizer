# Task07 — journaled native in-place rename executor

Status: DONE_WITH_CONCERNS. Implementation and available checks complete; actual Windows runtime qualification remains pending and its mutation gate stays closed.

Review base: `9cba34a7f65a290eca87483e18193c9a4efdcf8a`.

Read task-07-brief.md first, implementer-contract.md, the official SDD implementer prompt, TDD skill/writing-good-tests reference, and relevant Task04/05/06 handoffs. Worked only in the prescribed worktree/branch; no subagents, canonical-plan edits, pushes or merges. The controller supplies independent review.

## Delivered interfaces

`vidlib_fileops::execute` (also `rename::execute`):

```rust
pub fn execute(
    plan: &RenamePlan,
    lease: &Lease,
    journal: &mut Journal,
    fs: &mut dyn Filesystem,
    control: &vidlib_inventory::JobControl,
) -> Result<OperationReport, OpError>
```

`OperationReport` is backend-only and contains `operation_id: Option<OperationId>`, `state: OperationState`, `completed_groups: Vec<GroupId>`, `receipts: Vec<StepReceipt>`, and `failure: Option<OpError>`. Started operations have `Some(operation_id)`. Whole-selection validation/preflight rejection returns `Err` before beginning a journal operation. Filesystem execution failures return a factual partial report after durable finalization; journal/epoch/finalization failures return `Err` with operation/step context when available. Their committed receipts/events and unresolved steps remain queryable by operation ID. No new executable serde import or IPC path-taking API was added.

`Filesystem::rename_reserved(&RenameReservation) -> Result<MutationOutcome, OpError>` defaults to Unsupported for adapters that have not implemented reservations. `PlatformFs` implements it using the existing native no-replace move. `RenameReservation` has crate-private construction and fields, no Clone/Deserialize, and read-only operation ID, step ID, source and target accessors for adapters. The executor mints it only after the exact compiled intent commits, binding exact paths, expected native identity, and which endpoint is a reservation. A reserved source additionally requires its own completed earlier temporary step's receipt and EntryId. The platform seam remains independent of Rename recipe/step types.

`ProtectedPolicy::allows_owned_staging(&Path)` is the approved narrow repair for the existing native owned-copy staging primitives. It shares the pure policy checks with `allows_rename_reservation`, but refuses the dedicated rename-reservation prefix. Neither predicate is operation authority. Ordinary `excludes` still protects the canonical staging namespace. Create-new and ownership checks stay at the native seam.

The only coordinator/journal accessor additions are crate-private database-path accessors used to match the ordinary Write lease and journal. Existing public coordinator, journal, duplicate and event interfaces remain compatible.

## Execution and authority

- Requires an ordinary Write lease for this exact journal store, no pending/legacy recovery gate, and matching namespace/policy epochs before preflight.
- Checks duplicated approved PlanRef, inventory ID/generation, recipe revision, grants and frozen inputs. Blocked/review-needed plans and all non-RenameEntry actions fail closed before any effect. Copy, metadata, undo and recovery effects are unavailable here.
- Validates compiled source/EntryId ownership against native inventory/rows/grants and follows compiled entry locations through directory moves. Receipt references retain the exact output native units. Final locations must reach the reviewed row targets; runtime target/suffix generation is absent.
- Recaptures expected original parent facts using native representatives. A one-file grant uses the selected file as its parent-capture representative, permitting its planned absent sibling target without granting any sibling source. Unselected carried descendants' original parents already in the reviewed namespace are recaptured too, using inventory/namespace entries; no limits or contents are fabricated.
- Calls the reviewed pure `validate::preflight` on the fresh complete namespace before beginning the journal. Per-step checks revalidate source material freshness and source/target parent identities; moved directory-parent locations follow successful compiled effects. Existing native primitives hold and revalidate their parent/source handles and apply native no-replace semantics.
- Flushes each immutable intent before native effect, then commits its observed receipt/event before another effect. No SQLite transaction spans filesystem I/O. All native filesystem errors stop the operation and conservatively retain an unresolved action gap; no retry/suffix/compensation is attempted.
- Filesystem durability failure still records the observed rename/event, then stops with RecoveryRequired and full error IDs. Receipt failure leaves IntentDurable evidence, never a fabricated receipt/event.
- Cancellation is checked only before dependency groups. A cancellation raised during a cycle finishes that complete group before stopping. Completed prior groups remain reported; failed partial cycles retain their completed temporary receipt and unresolved later step for Task08.
- Namespace epoch advances conservatively after any attempted native effect while the operation is still pending and the Write lease is retained. Only then is terminal state finalized. Failure of epoch advancement or finalization leaves the recovery gate active. Panic/crash also leaves pending journal evidence. Cancellation before effects does not advance the epoch.

## Persisted expected namespace

Checked schema v4 migration preserves v1/v2/v3 SQL/checksums and adds `operations.inspection_version`, default 1 for old records and 2 for new records. Upgrade is under the existing BEGIN IMMEDIATE/explicit commit workflow; failure rolls back schema/version changes and preserves evidence. Schema checks verify migration checksums and the new column without decoding large inspection snapshots in effect/coordination hot paths.

New `inspection.expected_namespace` stores the complete read-only expected snapshot: all directory/entry facts and stamps, grants, case/name/length/capability policy, protected/guarded roots, observation windows and epochs. The private codec supplements every public-serde-omitted native path with `NativePathRecord`; stamps, limits and epochs retain exact decimal quantities. Tests reopen the real database and round-trip invalid UTF-8 native units, u64::MAX and i128::MIN, including grant/policy/entry/parent paths. Old inspection records retain absence of the namespace; migration never invents observations. Persisted inspection is not restart mutation authority. Task08 must reconcile compiled effects against fresh observations.

## Controller-approved integration corrections

1. **Exact cycle receipt native units (Task06 producer):** A real swap progressed through two moves then Journal correctly rejected step 3 because `target.join(empty_suffix)` had appended a trailing slash to the compiled FromReceipt source. Rust Path equality in prior pure tests hid the native byte mismatch. The controller explicitly authorized a narrow producer fix plus pure exact-unit regression. Exact moved roots now use `target.clone()`; only nonempty descendant suffixes are joined. Journal native-record equality remains unchanged. No graph refactor or authority relaxation.
2. **Existing owned-staging regression:** The first broad run failed three existing fileops boundary tests. Task06 made canonical staging exclusion unconditional, while `permit_staging` still tried to remove the configured canonical prefix before calling `excludes`, so existing create-new owned-copy staging always failed. The controller authorized repairing this exact regression. Both internal staging eligibility predicates now share the pure marker/root/custom-prefix policy; ordinary owned staging additionally refuses the rename-reservation namespace. Native ordinary rename remains protected. Tests exercise create-new success and refusal for marker, guarded root, protected root, custom prefix and unowned cycle paths, including attempted publication/cleanup. This does not enable copy execution in Rename or change any Windows gate.

## Test-first evidence

All ordinary Cargo commands below use:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

Raw logs are at the exact paths below. The initial tiny interface scaffold intentionally returned an empty Completed report, allowing behavioral assertions to fail instead of claiming compilation errors as reds. It was replaced by the executor. Tests that passed when first added are supporting coverage, not claimed intended reds.

1. Required first red:
   `cargo test -p vidlib-fileops --test rename`
   `/workspace/scratch/task07-red.log`: **0 passed, 5 intended failures**:
   - `executes_exact_reviewed_plan`: `reviewed target must be materialized`.
   - `late_stale_item_changes_nothing_in_preflight`: `late stale item must reject whole selection`.
   - `no_runtime_collision_suffix`: failure code `None`, expected `Some(DestinationExists)`.
   - `all_graph_steps_have_prior_durable_intent`: actual executed IDs `[]`, expected the two exact compiled StepIds.
   - `failed_group_stops_following_groups`: actual calls 0, expected 2.
   Same command after first implementation: `/workspace/scratch/task07-green1.log`: **5 passed, 0 failed**.

2. Reservation/persistence red, same command:
   `/workspace/scratch/task07-reservations-red.log`: **8 passed, 2 intended failures**. Native swap reports RecoveryRequired/ProtectedEntry at its compiled temp; `expected_namespace_is_persisted_with_native_paths` cannot find expected namespace after reopening.
   After reservation/persistence implementation `/workspace/scratch/task07-reservations-green.log` is deliberately retained as an **intermediate failed run**, not green evidence: **9 passed, 1 failed**. Swap now exposes the exact native receipt-path mismatch described above.

3. Grant ownership red, same command:
   `/workspace/scratch/task07-grants-red.log`: **11 passed, 2 failed**. New `individual_file_grant_never_authorizes_unrelated_sibling_source` fails because tampered compiled paths still act on the sibling; native swap is the already-identified producer mismatch. Added source/row/grant/receipt lineage validation and the approved producer correction. `/workspace/scratch/task07-grants-green.log`: **13 passed, 0 failed**. One-file success and carried-tree success were supporting native coverage.

4. Exact-unit producer red:
   `cargo test -p vidlib-rename --test graph cycle_receipt_paths`
   `/workspace/scratch/task07-native-units-red.log`: **0 passed, 1 failed**, `cycle_receipt_paths_preserve_exact_native_units_without_trailing_separator`. Actual native bytes end in `..., 48, 47]`; creator target ends in `..., 48]`. After fix, the full focused graph suite passes (below).

5. Journal fault-context red, same rename test command:
   `/workspace/scratch/task07-faults-red.log`: **18 passed, 2 intended failures**. `journal_intent_failure_prevents_effect_and_retains_gate` and `receipt_failure_preserves_action_gap_and_stops_next_group` show finalization masking the original failed journal StepId. Original journal errors are now preserved, while epoch advancement still runs for attempted native effects. `/workspace/scratch/task07-faults-green.log`: **20 passed, 0 failed**.

6. Focused compilation/execution regression check:
   `cargo test --locked -p vidlib-fileops --test rename -p vidlib-rename --test graph`
   `/workspace/scratch/task07-focused.log`: **24 Rename executor tests + 40 graph tests passed**. Includes successful/rolled-back v3 migration, epoch failure and finalization failure. Subsequent cycle coverage: `cargo test --locked -p vidlib-fileops --test rename`, `/workspace/scratch/task07-cycles.log`: **27 passed**, including cancellation inside a cycle, failed cycle evidence and the real directory-ancestor/escaping-child stamp shape.

7. Owned-staging red:
   `cargo test --locked -p vidlib-fileops --test platform staging_`
   `/workspace/scratch/task07-owned-staging-red.log`: **2 passed, 3 failed**. New `internal_owned_staging_keeps_ordinary_namespace_protection` fails its create-new success assertion with ProtectedEntry; existing `create_new_staging_publish_and_owned_cleanup` and `staging_refresh_rejects_a_path_replaced_while_content_handle_is_open` also fail. The new refusal regression passed initially and is not counted as red.
   After the approved policy correction:
   `cargo test --locked -p vidlib-fileops --test platform --test rename`
   `/workspace/scratch/task07-owned-staging-green.log`: **20 platform + 27 executor tests passed**, no warnings.

8. Final self-review error context:
   `cargo test --locked -p vidlib-fileops --test rename durability_failure`
   `/workspace/scratch/task07-error-context-red.log`: **0 passed, 1 intended failure**; expected operation ID was Some, durability error carried None. Added operation/step/item IDs at that known failure point.
   `cargo test --locked -p vidlib-fileops --test rename`
   `/workspace/scratch/task07-final-rename.log`: **27 passed, 0 failed**, no warnings.

Fault tests use real temporary media files and SQLite databases. The fault adapter delegates effects to PlatformFs and observes committed intents through separate journal connections. SQLite triggers inject deterministic intent, receipt, migration, epoch and finalization transaction failures; they are test-only fixtures, not production failure controls. These are transaction-write failures, not a claim to simulate an OS power loss. Existing private Journal commit-failure tests also run in the full suite.

## Broader and final verification

Linux desktop command in a fresh shell:

```sh
source /workspace/.tools/desktop-env.sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace
```

Initial run `/workspace/scratch/task07-workspace.log`: failed fileops lib run, **13 passed, 3 failed**, all due to the existing owned-staging regression:

- `platform::boundary_regressions::owned_removal_of_one_hard_link_preserves_other_alias`
- `platform::boundary_regressions::owned_removal_rebinding_at_unlink_requires_recovery_for_files_and_directories`
- `platform::boundary_regressions::owned_removal_recreated_name_after_unlink_requires_recovery`

After the approved correction, full rerun `/workspace/scratch/task07-workspace-final.log`: **230 passed, 0 failed**, all doc tests successful, no warnings. Counts include 27 executor tests, 40 graph tests, 20 platform tests, 19 journal tests, 13 coordinator tests and 15 desktop tests. Windows-only binaries running zero tests on Linux are not Windows runtime evidence.

Final cross-compilation (fresh shell):

```sh
source /workspace/.tools/windows-check-env.sh
cargo check --locked -p vidlib-inventory -p vidlib-rename -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu
```

`/workspace/scratch/task07-windows-final.log`: **passed**, `Finished dev profile`, no warnings. It includes the owned-staging and graph fixes; the subsequent final change only populates known durability-error IDs and is separately compiled/tested on Linux. No actual Windows sharing-violation/timestamp/native mutation test was executed. No runtime qualification is inferred.

Scoped final checks:

- `cargo clippy --locked -p vidlib-fileops -p vidlib-inventory -p vidlib-rename --all-targets -- -D warnings`: **passed**, `/workspace/scratch/task07-final-clippy.log`, after the final error-ID change.
- `cargo fmt --all -- --check`: **passed**, no output, `/workspace/scratch/task07-final-fmt.log`.
- `git diff --check`: **passed**; staged check is recorded with the commit below.

The full workspace run is not repeated after the small final error-ID correction; its focused executor regression/full executor binary and scoped Clippy pass on final code. No dependency changes or Cargo.lock changes.

## Self-review and remaining boundaries

Reviewed the final executor, native authorization seam, migration/private codec, pure policy/graph corrections, and test fixtures. The executor is a focused 370-line module; the longer integration fixture/test file keeps fault controls out of production. Existing journal/platform modules were already large; edits there remain narrow. No duplicate-action or engine rewrite, desktop wiring change, copy implementation, new recovery action or new UI was added.

Source IDs/native paths and grant authority stay bound across carries and temporary moves. Whole-selection validation occurs before mutation. Receipt/epoch/finalization gaps keep durable evidence and the recovery gate. Cancellation and failures do not claim partial dependency groups completed. Normal staging protection, marker/root/custom policy, native identity checks, no-replace behavior and Windows mutation gating remain enforced. The two real producer/consumer regressions found during this task are fixed with controller authorization and evidence above.

Pending: actual Windows runtime sharing violations, timestamp preservation, case-temp/native file-ID/handle behavior and installed-app qualification; gates stay closed. Windows writer-sharing lifecycle behavior remains the previously deferred later-owner item, unchanged here. Task08 owns recovery/compensation and crash reconciliation; Task09 undo, Task10 live process/session/selection/recipe invalidation and UI orchestration, and later tasks copy/metadata execution. Current plans/inspection are backend data, not report-import mutation authority. Performance qualification at large inventory scale is not claimed; source/location validation and whole-selection capture comparisons have straightforward scans. No unresolved correctness finding is known from the available checks; independent review remains required.

## Commit

`3c4e9d228b30c32dbaf7adfad9ef083947a054a1` — `feat: execute reviewed rename plans with durable receipts`.

All 12 task-owned source/test files are committed, including the two controller-approved integration corrections. `git diff --check` and `git diff --cached --check` passed before committing. Working tree is clean after the code commit. This report remains at the prescribed ignored `.superpowers/sdd/2026-10-17-rename-and-blueprint/task-07-report.md`, consistent with previous task reports.

Final committed-code Windows cross-check: the same documented SDK/all-target command passed again after the error-ID correction and commit; `/workspace/scratch/task07-windows-committed.log` reports `Finished dev profile`, no warnings. Thus committed code has final cross-compilation evidence; actual Windows runtime remains pending.

## Review round 1/5 — I1: bind reviewed parent identity to mutation handles

Review: `/workspace/scratch/task07-review.md`. Fix base: `3c4e9d228b30c32dbaf7adfad9ef083947a054a1`.

Resolved Important I1. Previously the executor checked the reviewed source/target parent IDs by inspection, then the adapter acquired fresh handles without receiving those expected IDs. Replacing a parent between those operations could therefore pass the adapter's current-path binding checks. This was a missing authority comparison, distinct from external mutations after a final native check.

### Changes and public seam

- Added backend-only `platform::RenameRequest<'a> { source: &'a Path, target: &'a Path, expected: &'a FileStamp, source_parent: &'a PhysicalId, target_parent: &'a PhysicalId }` and `Filesystem::rename_reviewed(&RenameRequest<'_>) -> Result<MutationOutcome, OpError>`. The default returns Unsupported, with no fallback to an unbound operation.
- The executor now retains the reviewed parent IDs found through its existing rebased parent-location map and carries them into every ordinary `rename_reviewed` request. The existing `RenameReservation` token also carries both expected physical parent IDs, so reserved source/target operations use the same check.
- `PlatformFs::move_entry` compares both expected physical IDs against the exact source/target parent handles it acquired and will pass into `native::rename`. A mismatch returns StaleState before the rename. Both ordinary reviewed and reserved branches supply these IDs to the shared native helper.
- Existing immediate source identity/material checks, held-handle/path pre/post binding checks, capability checks and no-replace behavior remain in place. Compatibility `rename_no_replace` and existing copy publication remain available to existing callers, but reviewed execution never calls or silently falls back to them.
- The native seam uses only inventory physical identity/stamp/path data and existing operation IDs. No Rename recipe or execution-step type was introduced into it. No Windows gate, sharing lifecycle, schema, compensation or recovery behavior changed.

### Deterministic regression evidence

The test-only fault adapter replaces a directory **after the executor's inspections and committed intent, immediately before native handle acquisition**. For the source-parent and same-parent reservation cases, it moves the original source object back under the replacement directory at the same path, preserving source identity/freshness so those checks cannot mask the missing parent comparison. It preserves an original-directory sentinel, creates a distinct replacement-directory sentinel, and keeps a following independent effect in the plan.

All three regressions assert StaleState at the first native action; the same source bytes remain at the source path; the intended target is absent; both original/replacement directory contents and identities are preserved; no completion receipts/events exist; the first intent remains Unresolved; and the following effect is not attempted. The reserved case also preserves the peer file in the original directory. Existing successful cycle/ancestor tests continue exercising IDs carried across planned directory rebases.

Exact command (documented Cargo environment):

```sh
cargo test --locked -p vidlib-fileops --test rename native_handle
```

RED: `/workspace/scratch/task07-review1-parents-red.log`, **0 passed, 3 intended failures, 27 filtered**:

- `target_parent_replaced_after_executor_inspection_is_rejected_by_native_handles`: actual failure `None`, expected `Some(StaleState)`; the old adapter accepts the replacement destination and completes.
- `source_parent_replaced_with_same_source_object_is_rejected_by_native_handles`: actual failure `None`, expected `Some(StaleState)`; source freshness alone does not reject its replaced parent.
- `reserved_rename_rejects_parent_replaced_before_native_handle_acquisition`: `the same source object must remain unmoved`; the first old reserved operation had already moved it before a later executor check noticed the parent.

GREEN: same command after the fix, `/workspace/scratch/task07-review1-parents-green.log`:

```text
running 3 tests
test source_parent_replaced_with_same_source_object_is_rejected_by_native_handles ... ok
test target_parent_replaced_after_executor_inspection_is_rejected_by_native_handles ... ok
test reserved_rename_rejects_parent_replaced_before_native_handle_acquisition ... ok
test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 27 filtered out
```

### Focused final checks

```sh
cargo test --locked -p vidlib-fileops --test rename --test platform --lib
```

`/workspace/scratch/task07-review1-focused.log`, **66 passed, 0 failed**, no warnings:

```text
test result: ok. 16 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
test result: ok. 20 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
test result: ok. 30 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
```

- `cargo clippy --locked -p vidlib-fileops --all-targets -- -D warnings`: passed, `/workspace/scratch/task07-review1-clippy.log`, `Finished dev profile`, no warnings.
- Fresh shell: `source /workspace/.tools/windows-check-env.sh`, then `cargo check --locked -p vidlib-inventory -p vidlib-rename -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu`: passed, `/workspace/scratch/task07-review1-windows.log`, `Finished dev profile`, no warnings.
- `cargo fmt --all -- --check`: passed with no output, `/workspace/scratch/task07-review1-fmt.log`. Final readability cleanup only shortens qualified type names with imports and clarifies that paths rebase while identities remain the same.
- `git diff --check`: passed. No broad workspace rerun, as directed; the earlier 230-pass run remains separate evidence.

Self-review: both expected IDs are mandatory in the typed reviewed request and reserved token; both native handles are checked; source and target replacement branches are separately exercised; default adapters fail closed; ordinary and reserved paths retain their protection and durable-intent checks. The unchanged immediate pre/post checks still detect current binding changes. This closes I1 but does **not** claim isolation from an external writer changing namespace after the final native check. Actual Windows runtime and OS power-loss durability remain unverified; Windows mutation gates remain closed. Task08 continues to own true process-crash reconciliation and compensation. Only the executor, platform seam and executor integration tests changed in this fix.

Review fix commit: `20ee7cfb57760794027d2aaf86fe665bf3aafc17` — `fix: bind reviewed rename parents to native handles`. Staged diff check passed; working tree is clean after the three-file code/test commit. Final Clippy after the import/readability cleanup passed without warnings (`/workspace/scratch/task07-review1-clippy-final.log`). I1 is resolved and ready for independent re-review; runtime/power-loss limitations above remain pending.
