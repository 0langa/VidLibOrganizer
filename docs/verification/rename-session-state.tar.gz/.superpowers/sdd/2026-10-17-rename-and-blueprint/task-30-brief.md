# Task 30: Portable records, retention, and local repair


**Files:** Create `crates/vidlib-blueprint/src/portability.rs`, `crates/vidlib-blueprint/src/retention.rs`, `crates/vidlib-blueprint/tests/portability_retention.rs`; extend commands and Blueprint settings/history UI with `tests/ui/blueprint-records.spec.mjs`.

**Interfaces:** Implements 4.4 export/import/prune/remove functions and structured import-review DTOs. Export v1 contains IDs, relative native paths/observations/coverage, change records and template snapshots; no OS grants, writer locks, native absolute bindings or executable operation journals. SQLite backup/export uses a consistent read snapshot/backup API.

- [ ] **Step 1 — Red:** Add `export_while_refreshing_is_consistent`, `import_rejects_escape_unknown_envelope_and_limits`, `import_never_activates_root`, `copy_import_remaps_ids_and_references`, `prune_keeps_each_root_baseline_and_dedup_tombstones`, `remove_collection_does_not_remove_marker_or_media`, and `repair_preserves_original_db`.
  ```rust
  assert!(imported.active_root_grants.is_empty());
  assert_eq!(oversize.code, BlueprintErrorCode::ImportLimit);
  assert!(store.last_complete_scope(root_a)?.is_some());
  assert!(store.last_complete_scope(root_b)?.is_some());
  assert!(media_file.exists() && marker.exists());
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test portability_retention`; `npx playwright test tests/ui/blueprint-records.spec.mjs`.
- [ ] **Step 3 — Implement:** Bounded streaming imports (256 MiB/1,000,000 entries), strict envelope/path/reference validation, inactive candidates, explicit replace/import-as-copy review and complete ID/reference remapping. Unknown embedded recipes remain opaque inactive within a recognized envelope. Age-based pruning preserves mixed-age root/scope baselines and non-content dedup EventId tombstones needed to prevent delayed replay from resurrecting pruned history. Do not prune pending source outbox/recovery records. User-triggered local record removal and separate marker removal are distinct actions. Offer consistent backup/export and preserve corrupt/original DB before explicit repair/reset.
- [ ] **Step 4 — Verify green:** Export/import during refresh, concurrent event delivery/pruning, interrupted export, known-ID collision, invalid path codecs/limits, removal/re-registration and all baseline scopes. A deleted collection stays deleted when late events arrive; markers and media are unchanged unless their separate explicit action is confirmed.
- [ ] **Step 5 — Commit:** `feat: manage portable Blueprint records and retention`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.1 Native paths, IDs, observations

Task 01 owns opaque UUID newtypes in `vidlib_inventory::ids`: `InventoryId`, `RootId`, `EntryId`, `GrantId`, `SessionId`, `JobId`, `PlanId`, `GroupId`, `StepId`, `OperationId`, `EventId`, `PresetId`, `CollectionId`, `AttemptId`, `AttachmentId`. IDs are not permissions. Revisions are Rust `u64`; schema versions are small `u32`.

`NativePathRecord { platform: WindowsUtf16Le | UnixBytes, bytes: Vec<u8> }` round-trips exact OS strings. Persist path keys as bytes, with a separate display string; only root-relative validated records enter portable inventories. Never use display strings or physical file IDs as unique path keys. Unsupported/unroundtrippable rename names remain visible issues. All new JSON u64/i128 counts/times/revisions are validated decimal strings; UUIDs are strings. SQLite stores exact quantities as decimal text, with fixed-width big-endian numeric sort keys where numeric indexing is required. Do not cast them to SQLite REAL or JS Number.

`FileStamp` contains optional physical identity, size for regular files, native-precision created/modified/accessed epoch-nanoseconds (`Option<i128>`), and Windows attribute bits. `PhysicalId` includes platform, volume identity, and file identity. `EntrySnapshot` contains EntryId, RootId, exact relative path, Rust-owned absolute PathBuf, display_name/display_path, kind, FileStamp, observation time, and issue state. File hard-link aliases remain separate entries. `RootBinding` contains RootId, backend-owned source grant, PathBuf, evidence, and capability facts; a binding records evidence absence separately from mismatch.

`Inventory { id, generation, roots, entries, coverage, window, issues }` is immutable. `ScopeCoverage` records exact directory, **listed child names even if stat fails**, `children_complete`, `subtree_complete`, outcome, filter fingerprint, observation interval, and issues. `JobControl` owns cancellation (`Arc<AtomicBool>`) and a bounded progress sink; `Progress { phase, done, total, current_entry }` is throttled to 10/s.

Public inventory interface: `scan(request: &InventoryRequest, control: &JobControl) -> Result<Inventory, InventoryError>`. Request grants come from backend native selection/validated manual paths; inventory sources can be roots or explicit files. Child traversal never follows a link/reparse point.

Task 01 also defines read-only `DirectoryFacts` and `NamespaceSnapshot` in inventory/model.rs: exact observed parent paths/entries, per-parent case/name/length facts, filesystem capabilities, source grants, protected-root/marker policy, persisted namespace/policy epoch and capture interval. `PlatformFs::capture_namespace(grants: &GrantSet, candidates: &[PathBuf])` in Task 02 populates these data types. Their definition never imports Rename/fileops. A test adapter can supply this same data to the pure planner.


### 4.4 Tauri/JavaScript and Blueprint contracts

Task 10 exposes owned command request structs and `Result<_, CommandError { code, message, phase, item_id, operation_id, retryable }>`; serialize using camelCase consistently. Commands clone Arc-managed handles under short locks, release guards, then start blocking workers. Job types carry owned results; query responses page at 200 rows. Never keep a std MutexGuard or rusqlite Connection borrow across await.

Core commands: `select_sources(PickerKind) -> SelectionDto`, `start_inventory(InventoryRequestDto) -> JobId`, `start_rename_preview(RenameRequestDto) -> JobId`, `job_status(JobId) -> JobStatusDto`, `cancel_job(JobId)`, `rename_page(PlanRef, PageQuery) -> Page<PlanRowDto>`, `confirm_rename(PlanRef) -> ConfirmationDto`, `apply_rename(PlanRef, confirmation_nonce) -> JobId`, `operation_history(PageQuery) -> Page<OperationDto>`, `recovery_preview(OperationId)`, `start_recovery(RecoveryRef, choice, nonce)`, `start_undo(OperationId) -> JobId`. Nonces bind the current session/revision/summary and are revoked on edits. Queries do not reauthorize native paths.

All **new** commands use one owned argument named `request` (wrap multi-field cases in the corresponding request DTO) plus managed state; JS invokes them with `{ request: dto }`. Existing commands retain their prior argument shape. Task 10 adds `src-tauri/tests/command_contracts.rs` and `tests/ui/fixtures/command-contracts.json` to verify camelCase/tag/decimal-string serialization against the same golden payloads used by browser mocks. PageQuery contains cursor, limit capped at 200, display sort/filter, and expected data revision; it never changes recipe numbering order.

Common JS interfaces: `watchJob(jobId, {signal, onProgress}) -> Promise<JobResult>` cleans up timers on finish/navigation/error; `createRecipeEditor({recipe, onChange}) -> {getRecipe(), setRecipe(recipe), destroy()}` never computes filenames; `formatExactBytes(decimalString)` uses BigInt and string-safe formatting. `call()` in `ui/api.js` remains compatible with existing commands while new errors are formatted centrally.

Blueprint Task 24 owns `BlueprintStore::open(path: &Path) -> Result<Self, BlueprintError>`, collection/RootBinding revision records, and paged queries. Task 25 owns `recognize(evidence: &RecognitionInput) -> RecognitionDecision` (`Known`, `CandidateNeedsConfirmation`, `IdentityConflict`, `MarkerOnlyNoLocalData`, `Unknown`), `register`, and `rebind` with expected binding revision. Task 26 owns `begin_refresh(collection_id, request) -> AttemptId`, `stage_inventory(attempt, inventory)`, and `promote_refresh(attempt) -> RefreshReport`; promotion commits baseline scopes and observed events together.

Task 27 owns `project_events(events: &[OperationEventV1]) -> ProjectionReceipt` with EventId uniqueness and transactional cursor updates. Task 28 owns `attach_template(collection, scope, preset_id, revision, recipe_snapshot) -> AttachmentId` and `summarize_patterns(selection, baseline_revision) -> PatternSummary`. Task 30 owns `export_bundle`, `validate_import`, `import_inactive`, `prune_history`, and `remove_collection`; none grants filesystem access or accepts executable journals.

Blueprint queries return `Page<MapEntryDto>`, `CollectionSummaryDto`, `Page<ChangeDto>` with observation interval/origin/confidence and separate last-attempt/last-complete times. Its commands mirror the store operations through owned DTOs, not SQL rows. Sending cached items to Rename resolves an explicit fresh native selection and scans again; stale EntryIds are never reused.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.

