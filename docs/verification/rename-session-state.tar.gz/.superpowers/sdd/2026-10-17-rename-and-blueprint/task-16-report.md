# Task 16 — immutable presets and shared recipe editor

Status: DONE. Base `9b41f2d`; worktree `/workspace/VidLibOrganizer/.worktrees/rename-blueprint`, existing `feat/rename-blueprint`. Commit `4d0cb80` recorded below. No helpers/subagents, canonical checklist edits, forced SDD tracking, branch changes, push, merge or publication.

Read the supplied task brief/implementer contract first, official implementer template, Superpowers TDD and writing-good-tests, Task11 semantics and Task15 handoff. Cloud runtime skill became available; status reported current running/connected environment, enforced unrestricted policy and no configured secrets/outbound identities. No dependency fetch or network-policy change was required.

## Public interfaces and scope

### Portable core

`crates/vidlib-rename/src/presets.rs` exports `RECIPE_BYTE_LIMIT` (1 MiB), UUID `PresetId`, `PresetRevision { id, revision, recipe: RecipeV1 }`, and `PresetStore::{default, load(id, Option<revision>), save_revision(Option<id>, recipe), from_snapshot(snapshot), import(bytes), export(&recipe)}`.

Preset revisions use exact decimal strings and are independent of the embedded recipe revision. Saving validates before publication and clones immutable snapshots; earlier revisions remain available and returned snapshots cannot mutate stored records. Unknown IDs/revision overflow fail. Import/export use existing strict RecipeV1 parsing and validation, preserve ordered/inactive rules, Text/Between, selection_filter and numbering_scope, and reject unknown tags/versions. The 1 MiB/100-rule errors map to `ImportLimit` at the preset boundary; existing core error codes and portable snake_case schema remain unchanged. Export preserves data, not source JSON whitespace/key order. No code or native path authority is exported.

### Durable desktop adapter

`src-tauri/src/rename_preferences.rs` stores only app-owned data beneath the coordinator's app-local directory, `rename-presets/`. Callers cannot supply a path. `{presetId}-{revision}.json` records are immutable/no-clobber; `{presetId}.current.json` is the only replaceable record and contains a complete snapshot.

Exclusive create-new temporary files are fully written, flushed and sync_all'ed before publication. Unix uses tempfile persistence plus parent-directory sync; Windows uses SetFileAttributesW(FILE_ATTRIBUTE_NORMAL), then same-directory MoveFileExW with WRITE_THROUGH and REPLACE_EXISTING only for the app-owned current record. Archives publish/flush first. Ordinary prepublication failures preserve previous active bytes; temporary files clean up on failure. Links/reparse records, corrupted data and identity mismatches fail closed. A same-content orphan can complete publication; a different valid orphan stays immutable and a later revision is allocated.

Atomic current replacement is the commit point. Under the controller's Task16 clarification, failure of the following directory flush returns distinct `presetCommitUncertain` and an explicit reload-before-retry message, retaining the old immutable archive. It does not falsely promise rollback. A fault-injected final directory flush test uses real files and verifies the new current record plus old archive and no temporary leaks.

Arc-managed app-state locking serializes saves within the running app; `expectedRevision` rejects stale saves. Commands clone AppState handles and perform parse/I/O/locking in spawn_blocking. No mutex or database borrow crosses await. Every new command uses one owned strict camelCase `request`:

- `save_rename_preset({ presetId, expectedRevision, recipeJson }) -> { presetId, revision, recipeJson }`.
- `load_rename_preset({ presetId, revision })`: null selects current; exact decimal revision selects an immutable archive.
- `list_rename_presets({ cursor }) -> { items: [{ presetId, revision }], nextCursor }`, maximum 200 items.
- `import_rename_recipe({ recipeJson })` and `export_rename_recipe({ recipeJson }) -> { recipeJson }`, both through the bounded Rust codec.

The controller approved `recipeJson` as an explicit opaque portable-document string: command envelopes remain camelCase, while RecipeV1 stays snake_case. Shared Rust/browser literal fixtures include revision `9007199254740993`, directories scope and inactive Text/Between configuration. Negatives reject snake_case envelope keys, unexpected path fields, objects where a document string is required and numeric preset revisions.

### Editor and usable preview

`createRecipeEditor({ recipe, onChange }) -> { element, getRecipe(), setRecipe(recipe), destroy() }` is the single shared lifecycle. Reads/callbacks return deep detached snapshots; setRecipe attaches a replacement and resets edit history; destroy aborts listeners and removes owned DOM/history. `createEditHistory` provides bounded 100-edit undo/redo and redo-branch truncation, with no filesystem calls. Every edit/Undo/Redo triggers the existing invalidation callback. Reorder, repeat with fresh IDs, disable, remove and add preserve unedited/inactive rule data.

Typed controls cover Keep/FixedStem, Text fixed/keep, Stem/Extension/WholeName, grapheme ranges, Delimited and flat-pair Between with occurrence/inclusion. Other configured rule families remain visible/editable as tagged JSON data and round-trip unchanged; complete family-specific controls remain Task21 work after Tasks17–20. Incomplete advanced JSON immediately invalidates preview and blocks extraction/save/preview from silently using the previous valid recipe. JavaScript never evaluates filenames.

Rename adds preset create/revision save/load/list paging, bounded file import, validated download export and visible attached revision status. Load/import reset edit history and invalidate current plans. A visible note explains that preview binds to currently checked items in selection order, retaining exclusions that must match the current inventory. No stale exclusion is silently cleared. Saving creates a new preset revision, preserving the attached/older snapshot.

`RenameRequestDto` adds serde-default `recipeJson: Option<String>` and `rebindSelection: bool`; legacy Keep/FixedStem/Template forms remain compatible. Full ordered recipes reach the existing Rust frozen-input/evaluate/namespace/graph pipeline. Bytes are bounded before dispatch; parsing/schema/regex validation runs on the worker. Existing revision/generation publication checks, scope/frozen-input provenance and plan/nonce invalidation stay intact. Explicit rebind replaces saved selection/order with current selected IDs; without it, mismatched selection fails. Unknown current IDs and retained unknown exclusion IDs fail. Legacy and document selection filters cannot both be supplied. Existing native inventory/grants remain sole authority.

The real saved-recipe test produces `two.mp4` from the second enabled rule, retains a disabled third, and proves an edit revokes the prior confirmation. Browser tests verify all ordered rules reach the request and Undo edit never invokes filesystem Undo.

## Files/dependencies

Created core presets module/tests, desktop rename_preferences module, UI recipe fields/history modules and recipe-editor browser tests. Extended core exports, desktop AppState/registration/preview, shared editor/Rename UI/scoped CSS, command-contract tests/shared JSON fixture. Existing DTO constructor migrations add default optional fields only.

Promoted existing tempfile 3 to desktop runtime, added cfg(windows) windows-sys 0.61 with Win32_Storage_FileSystem, and declared uuid serde explicitly in the owning core crate. Cargo.lock changes only one desktop dependency edge to already-locked windows-sys 0.61.2. No engine, inventory, fileops, journal, Blueprint schema or duplicate-finder product changes.

## TDD and focused evidence

Raw logs: `.superpowers/sdd/2026-10-17-rename-and-blueprint/task16-logs/`. Linux cargo prefix throughout:

```sh
. /workspace/.tools/desktop-env.sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target CARGO_INCREMENTAL=0 cargo ...
```

The sourced environment supplies contract CARGO_HOME/RUSTUP_HOME/PATH. Browser commands use `env -u NO_COLOR`.

1. `cargo test -p vidlib-rename --test presets`: `red-presets.log`, 0/3. `import_limits_and_rule_count` expected ImportLimit, received RecipeTooLarge. `recipe_round_trip_and_version_rejection` and `failed_save_preserves_previous` failed the required baseline save against compiling API scaffolds (`InvalidRecipe: not implemented`); these are missing-behavior scaffold failures, not missing-interface compiler errors or proof of a later filesystem fault. `green-presets.log`: 3/3. `green-presets-final.log`, same command with `--locked`: 4/4, including exact 1 MiB/+1 and 100/101 boundaries, exact recipe revision, older immutable revisions and unknown tags/versions.
2. `env -u NO_COLOR npx playwright test tests/ui/recipe-editor.spec.mjs`: `red-editor.log`, 0/3. Full RecipeV1 roundtrip instead returned `{ rule: '', fixedStem: 'undefined' }`; Undo edit was absent; snapshot/Between test could not access dropped rules. `green-editor-first.log`, 2/3, exposed a real multi-control stale-closure bug: occurrence reverted to 2 rather than staying 3 after toggling delimiter inclusion. Corrected selector edits to preserve current fields.
3. `cargo test -p vidlib-tauri --lib rename_preferences`: `red-persistence.log`, required save/restart test failed the scaffold's baseline save. Link rejection passed vacuously against that scaffold and is NOT counted as red evidence. Initial unused-import scaffold warnings disappeared with implementation. `green-persistence.log`: 2/2; `green-persistence-faults.log`: 4/4, covering real OS permission-denied create-new, obstructed next-record directory, active bytes/temporary cleanup, process-state reopen, archive loading, stale expected revision and malformed/oversize/version rejection.
4. `cargo test -p vidlib-tauri --test command_contracts saved_ordered_recipe`: `red-ordered-preview.log`, 0/1, real parsed request rejected rebindSelection as unknown. `green-ordered-preview.log`, 1/1, actual saved ordered Rust preview and revocation. `... recipe_` commands: `green-preview-boundaries.log` and final locked `green-preview-final.log`, 2/2, including byte/version/tag bounds, explicit rebind, unknown current IDs/retained exclusions. Final parse/validation is on the worker.
5. Expanded browser command: `red-ui-integration.log`, 3 passed/2 failed, preview omitted explicit binding/full document and Save new preset did not exist. `green-ui-integration.log`, 5/5 after integration.
6. `env -u NO_COLOR npx playwright test tests/ui/recipe-editor.spec.mjs -g unfinished`: `red-unfinished-draft.log`, 0/1, getRecipe returned the old valid recipe after unfinished JSON editing instead of refusing it. Fixed immediate invalidation and blocked extraction; `green-editor-final.log`, 6/6.
7. `cargo test -p vidlib-tauri --lib publication`: `red-publication-faults.log`, 0/2. `post_publication_flush_fault_is_uncertain_and_reload_observes_new_revision` expected an error but got Ok because the new flush seam was not yet honored. `orphan_revision_after_interrupted_publication_does_not_block_future_edits` expected a later valid revision but got a conflicting immutable revision error. After implementation, `cargo test -p vidlib-tauri --lib rename_preferences --locked`: `green-publication-faults.log`, 6/6; real current revision 2 and archived revision 1 remain after injected flush failure, while a differing orphan revision 2 stays unchanged and new editing publishes revision 3.

One existing DTO constructor using shorthand `revision` was initially missed; a focused build reported missing new fields, corrected before green. This was not an intended red. No test expectation was weakened. A report-writing tool call containing an unrelated forced temporary cleanup was rejected before execution; report writing was reissued separately, with no product action blocked.

## Broader/final verification

- `cargo test --workspace --locked`: `workspace.log`, **431 distinct Rust tests passed**, zero failed/ignored/warnings. Harness sum is 432 because `resource_limits_are_real` runs inside its isolated regex child too. Includes four core preset, six adapter and two new preview cases plus previous finder/fileops/recovery/selection contracts.
- `env -u NO_COLOR npm test`: `ui-all.log`, **4 Node +22 Chromium passed**, no warnings, including existing finder interaction, stale preview/confirmation races, recovery and paging.
- After broad verification, added one literal wire test/shared fixture and nine lines of layout CSS. A final narrow self-review change moved fallible response preparation before current-record publication (see below). `cargo test -p vidlib-tauri --test command_contracts preset_document_wire --locked`: `green-wire-golden.log`, 1/1 new case. Therefore **432 distinct current Rust tests have passing evidence** (full 431-test run plus one added focused test), not a claimed second full run.
- `env -u NO_COLOR npx playwright test tests/ui/recipe-editor.spec.mjs`: `green-editor-styled.log`, 6/6 after shared-fixture/layout edits. `editor-layout.png`: inspected Chromium Text/Between/preset UI at 1280px, with no document-width overflow. This is not Windows WebView2 evidence.
- `cargo clippy -p vidlib-rename -p vidlib-tauri --all-targets --locked -- -D warnings`: `clippy.log`, passed without warnings; final serialization-order cleanup rechecked in clippy-final.log.
- `cargo fmt --all --check`: `format.log`, passed/no output. `git diff --check`: `diff-check.log`, passed/no output. `node --check` for ui/recipe/editor.js, fields.js, history.js and ui/rename/main.js: all passed/no output (tool transcript).
- Fresh Windows shell: `. /workspace/.tools/windows-check-env.sh`; `CARGO_TARGET_DIR=/workspace/VidLibOrganizer/.worktrees/rename-blueprint/target CARGO_INCREMENTAL=0 cargo check -p vidlib-tauri --all-targets --target x86_64-pc-windows-gnu --locked --offline`: `windows-desktop.log`, **passed**, exit0, 51.51s, no warnings. Includes the Windows write-through branch and all then-current desktop targets. The final shared-golden test was added later and compiled/passed on Linux. A later platform-independent change only moved response serialization before publication; the Windows write-through implementation is unchanged. This is cross-check evidence, not Windows runtime/durability proof.

Final self-review moved response serialization/validation before atomic current publication, ensuring the explicitly classified flush uncertainty is the only fallible postcommit step. `cargo test -p vidlib-tauri --lib rename_preferences --locked` — `green-final-serialization-order.log`: all 6/6, including precommit preservation, injected postcommit fault, archives/restart and orphan recovery. This focused rerun covers the change; the broader counts remain tied to the earlier actual run.

No ENOSPC or build cleanup occurred. Shared Linux/isolated Windows targets and CARGO_INCREMENTAL=0 were preserved.

## Self-review and limitations

Reviewed diff/new modules for immutable attachment/history, inactive-rule preservation, exact quantities, bounded imports, native authority, current revision checks, atomic app-owned publication, orphan/failure cleanup and dependency direction. Fixed selector closure, unfinished JSON draft and orphan publication issues before completion. Media executor/journal/no-overwrite behavior is unchanged. No JS transformation engine exists.

Normal precommit preservation and postcommit uncertainty follow the controller's explicit ruling. Preset saves serialize within AppState; immutable no-clobber archives/atomic replacement are the durable primitives. Archives are retained, without speculative pruning/deletion/migration scheduling.

Task21 still owns complete family controls and journeys after metadata/companions/destination work. Blueprint must embed this same editor and explicitly prepare fresh inventory selection. Unsupported later native configurations still fail through Rust; no completion claim is made for them.

Native Windows execution/WebView2/power-loss/filesystem-fault behavior, NTFS/exFAT/removable/network scenarios remain pending. Cross-check success resolves the previous SDK compilation blocker only. This task is not the finished Rename release or Blueprint foundation.

## Commit

`4d0cb80` — `feat: add versioned presets and shared recipe editing`. All 18 task-owned code/test/manifest/lock files committed. Final `git status --short` is clean. Ignored report/logs/screenshot remain in SDD process state and were not force-added. Final scoped Clippy passed in `clippy-final.log`; format/diff checks passed.

## Fix round 1 — I1 cross-instance publication / I2 unfinished draft preservation

Read `/workspace/scratch/task16-review.md` in full (0 Critical, 2 Important, 0 Minor). Fix base `4d0cb80`. Both findings are corrected together. This section supersedes the original report's process-local-only serialization and draft-rendering descriptions. No canonical edits, helpers/subagents, branch changes, push or publication; Ruling 6 postcommit semantics remain unchanged.

### I1 changes and self-review

`rename_preferences.rs` now opens an independent OS advisory lock handle for the private app-local `rename-presets.lock` on every save. `fs4::FileExt::try_lock_exclusive` is held across the current record read, expectedRevision comparison, archive allocation/apparent-orphan recovery, response preparation, current publication and directory flush. It is not a late unlocked recheck. A competing instance receives retryable `presetBusy`; after the first writer commits/releases the lock, an outdated expectedRevision still fails and cannot allocate/publish another revision.

The permanent lock file is not deleted/replaced, and its existence/content/PID is never treated as lock authority. Closing the independently opened handle releases the kernel lock on success/error/unwind. Link/reparse/nonregular lock records are rejected. No caller path is added; the lock is a sibling of the protected app-owned preset directory. This lock coordinates preset data only and neither replaces nor bypasses media coordinator/journal authority.

`save_with_publication` is a private factoring of the same save pipeline, with the existing publication operation supplied as a closure. It permits deterministic control of the publication boundary in tests without introducing public fault flags or changing the production write/sync path. The interleaving test creates two independent AppStates, pauses A after immutable archive 2 but before current publication, attempts B, then resumes A. Before the fix, B published current 3 and A regressed current to 2; after the fix B is Busy, A commits 2, a stale expected-1 retry fails, and an explicit expected-2 save publishes 3. Additional real-file tests show an old lock-file marker grants nothing, a prepublication failure releases the OS lock for another instance, and a symlink cannot redirect lock authority.

Added only a direct desktop dependency edge to already-locked `fs4` 0.13.1 (`default-features=false`, `sync`), matching the existing fileops locking library. Cargo.lock adds only `fs4` to vidlib-tauri dependencies; no package versions changed. Windows cross-check passes; native Windows lock behavior remains runtime-pending.

### I2 changes and self-review

`editor.js` now stores unfinished text in a Map keyed by stable rule ID. `fields.js` restores that exact text and invalidity on rerender. Add, reorder, segment changes and another rule's type change preserve the draft and keep getRecipe/save/preview blocked. Undo/Redo and replacing the same rule's type cannot hide an unresolved draft. Explicit removal of that rule, explicit setRecipe replacement, or destruction clear its draft as part of the chosen lifecycle action; ordinary rerender does not.

Self-review found and reproduced a related case: a valid advanced JSON edit changed its last valid type to Keep, then subsequent unfinished text was hidden by a structural render because the old typed-control branch had no textarea. A retained draft now always renders the advanced textarea regardless of the last valid parameter type. Correcting the draft restores extraction and normal edit history. Existing edit callbacks/revision revocation remain intact, and no filename evaluation was added.

Browser coverage exercises visible draft retention after Add/reorder/other-rule type edits, disabled history during unresolved drafts, same-rule type replacement protection, and correction. An integrated Rename test first obtains an applicable preview, enters invalid text, observes Apply revoked, performs structural edits, and verifies Preview/Save both report the invalid draft without issuing new preview/save commands. Correcting the retained text permits a fresh preview.

### Exact red evidence

Raw logs are in `.superpowers/sdd/2026-10-17-rename-and-blueprint/task16-logs/fix1/`. Linux Rust commands use:

```sh
. /workspace/.tools/desktop-env.sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target CARGO_INCREMENTAL=0 cargo ...
```

1. `cargo test -p vidlib-tauri --lib independent_instances --locked` — `red-interleaving.log`, exit101, 0 passed/1 failed. Exact named failure:
   `independent_instances_cannot_publish_stale_or_regressing_heads: B published revision Some("3") while A was paused; A then replaced current with 2`.
   The publication closure only gates the existing real-file pipeline; no sleeps/racy stress scheduling or expected fake storage result is used. Channels reserve the precise interleaving.
2. `env -u NO_COLOR npx playwright test tests/ui/recipe-editor.spec.mjs -g unfinished` — `red-draft.log`, exit1, 0 passed/1 failed. `unfinished_advanced_rule_edit_cannot_preview_previous_valid_recipe` expected `{broken` after Add, but received the original valid Template JSON. This is the exact reported loss of pending text.
3. `env -u NO_COLOR npx playwright test tests/ui/recipe-editor.spec.mjs -g advanced_type` — `red-draft-type.log`, exit1, 0 passed/1 failed. `unfinished_draft_remains_visible_after_advanced_type_was_edited` expected the `{broken` textarea after Add, but the element no longer existed because the last valid type had become Keep. Fixed before final green.

### Green checks and outputs

All following commands exited0 with no warnings. No full-workspace repeat was run; original broad-run counts remain historical evidence at their recorded revisions.

- `cargo test -p vidlib-tauri --lib rename_preferences --offline` — `green-persistence.log`: 7 passed/0 failed, including initial corrected deterministic interleaving.
- `cargo test -p vidlib-tauri --lib rename_preferences --locked` — `green-persistence-final.log`: **9 passed/0 failed/21 filtered**. Named passing tests: independent_instances_cannot_publish_stale_or_regressing_heads; stale_lock_file_grants_nothing_and_failed_writer_releases_kernel_lock; preset_lock_link_cannot_redirect_lock_authority; failed_save_preserves_previous; create_new_permission_failure_keeps_active_bytes_and_cleans_temporary_files; malformed_oversized_and_conflicting_documents_never_replace_active; preset_storage_rejects_links_and_preserves_unrelated_file; orphan_revision_after_interrupted_publication_does_not_block_future_edits; post_publication_flush_fault_is_uncertain_and_reload_observes_new_revision.
- `cargo test -p vidlib-tauri --test command_contracts recipe --locked` — `green-preview-contracts.log`: **2 passed/0 failed/24 filtered**, saved_ordered_recipe_preview_rebinds_explicitly_and_revokes_after_edit and recipe_document_boundaries_and_retained_exclusions_fail_closed.
- `env -u NO_COLOR npx playwright test tests/ui/recipe-editor.spec.mjs -g unfinished` — `green-draft.log`: 1 passed.
- `env -u NO_COLOR npx playwright test tests/ui/recipe-editor.spec.mjs` — initial `green-editor.log`: 7 passed. Final `green-editor-final.log`: **8 passed**, including the final advanced-type regression, actual preview/save blocking, roundtrip/order/inactive data, detached snapshots and edit history.
- `env -u NO_COLOR npx playwright test tests/ui/rename-basic.spec.mjs` — `green-ui-regression.log`: **16 passed**, including finder behavior, current-input revocation, races, paging and recovery. This run preceded the last retained-draft-only branch adjustment; the final 8-test editor run covers that adjustment and its integrated Rename flow.
- `cargo clippy -p vidlib-tauri --all-targets --locked -- -D warnings` — `clippy.log`: passed, 3.72s, no warnings.
- `cargo fmt --all --check` — `format.log`: passed/no output. `git diff --check` — `diff-check.log`: passed/no output. `node --check ui/recipe/editor.js` and `node --check ui/recipe/fields.js`: passed/no output in tool transcript.
- Fresh Windows shell `. /workspace/.tools/windows-check-env.sh`; `CARGO_TARGET_DIR=/workspace/VidLibOrganizer/.worktrees/rename-blueprint/target CARGO_INCREMENTAL=0 cargo check -p vidlib-tauri --all-targets --target x86_64-pc-windows-gnu --locked --offline` — `windows-desktop.log`: passed, 3.71s, no warnings. Includes the new fs4 dependency and lock path. Native Windows runtime/power-loss/WebView2 qualification remains pending; cross-compilation is not runtime proof.

Changed only Cargo.lock, src-tauri/Cargo.toml, src-tauri/src/rename_preferences.rs, ui/recipe/editor.js, ui/recipe/fields.js and tests/ui/recipe-editor.spec.mjs. Self-review checked lock scope/release, immutable archive behavior, retry/stale revision handling, app-owned path boundaries, error/uncertain-commit semantics, draft IDs across reorder, visible resolution and normal invalidation. No new concerns found beyond the previously recorded native platform checks.

Fix commit: `7b5e124` — `fix: serialize preset publication and preserve unfinished drafts`. Final tracked worktree is clean; ignored report/logs were not force-added.
