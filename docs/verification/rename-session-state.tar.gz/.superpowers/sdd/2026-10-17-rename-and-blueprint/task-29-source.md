### Task 29: Blueprint map, history, and desktop workflows

**Files:** Create `src-tauri/src/commands/blueprint.rs`, `ui/blueprint/main.js`, `ui/blueprint/map.js`, `ui/blueprint/changes.js`, `ui/blueprint/templates.js`, `ui/blueprint/patterns.js`, `tests/ui/blueprint.spec.mjs`; extend desktop app state, navigation/index/styles and shared jobs/editor.

**Interfaces:** Exposes Blueprint store/query commands via 4.4 owned DTOs; map_children/search/history are cursor-paged at 200 rows and stable baseline revision. Register/rebind/marker changes require explicit selected-root grants. `open_in_rename` creates fresh source selection and inventory; never reuses cached EntryIds.

- [ ] **Step 1 — Red:** Add browser scenarios `known_collection_load_then_refresh`, `offline_cached_map_is_labelled`, `identity_conflict_needs_choice`, `partial_refresh_shows_coverage`, `template_uses_shared_editor`, `pattern_filters_examples_only`, `cached_selection_requests_fresh_rename`, and keyboard/tree/dialog focus tests.
  ```js
  await expect(page.getByTestId('blueprint-label')).toContainText('Experimental');
  await expect(page.getByTestId('map-freshness')).toContainText('Recorded');
  expect(bridge.createdMarkerCount).toBe(0);
  expect(bridge.renameRequests[0].reuseCachedEntryIds).toBe(false);
  ```
- [ ] **Step 2 — Verify red:** `npx playwright test tests/ui/blueprint.spec.mjs`; `cargo test -p vidlib-tauri commands::blueprint` on supported desktop build environments.
- [ ] **Step 3 — Implement:** Functional Map/Changes/Templates/Patterns sections, registration/inspect-without-saving, cached-first view, automatic reachable refresh on open plus manual Refresh, truthful availability and dual observation times, explicit identity decisions, attachment editing and example selection. Central coordinator delays physical refresh during mutations while allowing cached browsing. Prevent stale query/job responses after navigation; render all path/metadata data as text.
- [ ] **Step 4 — Verify green:** Browser and desktop adapter tests, page limits, empty/arbitrary layout examples, offline reconnect, template selection conflicts, screen-reader state/keyboard navigation and existing app regression journeys. No unimplemented hero controls are presented as working.
- [ ] **Step 5 — Commit:** `feat: add the Blueprint collection workspace`.

