### Task 27: Idempotent operation projection and duplicate-action bridge

**Files:** Create `crates/vidlib-blueprint/src/operations.rs`, `crates/vidlib-blueprint/tests/operation_projection.rs`, `crates/vidlib-fileops/src/duplicate_events.rs`, `crates/vidlib-fileops/tests/duplicate_events.rs`; extend old fileops helpers narrowly, journal/outbox and Tauri coordinator delivery.

**Interfaces:** Implements project_events/ProjectionReceipt; an EventId unique insert and projection cursor commit in blueprint.sqlite3 precede outbox acknowledgement. Add `apply_duplicate_actions_with_journal(result, paths, action, destination, lease, journal) -> ActionReport`, preserving the existing outward report/keeper/hash behavior. Internal receipts carry actual destinations and completed phases.

- [ ] **Step 1 — Red:** Add `event_replay_and_crash_before_ack_project_once`, `refresh_matches_app_event_without_duplicate`, `intervening_external_change_is_preserved`, `projection_failure_never_repeats_mutation`, `duplicate_move_records_actual_destination`, `duplicate_delete_keeps_existing_guards`, and `pruning_never_removes_unacknowledged_event_identity`.
  ```rust
  assert_eq!(store.changes_for_operation(op)?.len(), expected_fact_count);
  assert_eq!(filesystem_mutation_calls, 1);
  assert_eq!(receipt.actual_destination, real_destination);
  assert_eq!(retained_keeper_bytes, b"fixture");
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test operation_projection`; `cargo test -p vidlib-fileops --test duplicate_events --test actions`.
- [ ] **Step 3 — Implement:** Commit receipt/event projections and consumption cursor together, then ack the source outbox; replay by EventId after restart. Record a local root-activation event cursor/registration epoch so delayed events from a removed or earlier binding cannot resurrect its history. Exact known updates invalidate freshness and correlate with later observations without suppressing genuinely different external changes. Add pre-intent/post-receipt hooks around legacy duplicate mutations to capture actual destination/final phase durably; preserve current duplicate safety and avoid changing its collision policy as an unrelated refactor. Permanent duplicate deletion remains non-undoable. Unknown/unregistered roots do not auto-register; acknowledge irrelevant events explicitly without inventing collection history.
- [ ] **Step 4 — Verify green:** Replay before/after each DB commit/ack, Blueprint disk-full/corruption, multi-root event fan-out and existing 36 portable tests plus Windows-specific duplicate tests. A successful source operation remains successful even while Blueprint is unavailable.
- [ ] **Step 5 — Commit:** `feat: project durable file-operation facts into Blueprint`.

