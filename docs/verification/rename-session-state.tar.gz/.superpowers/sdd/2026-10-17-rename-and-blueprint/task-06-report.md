# Task06 — pure final-path validation and deterministic rename graphs

Status: DONE_WITH_CONCERNS. Implementation and available validation complete; Windows runtime remains pending. Base: `7f7d2d2a1e874183114ebcf2a5dd382c1e6e934d`. Commit: `fa5051e70534e3b31ec6c340400c427a988941c6` — `feat: plan collision-safe hierarchical renames`.

Read the Task06 brief first, implementer contract, official implementer prompt/TDD skill/writing-good-tests reference and Task04/Task05 handoffs. No whole-plan reread, design restart, helper agents, executor implementation, native mutation gate change, canonical checklist edit, push or merge.

## Interfaces and behavior

- `vidlib_rename::plan(&Inventory, &EvaluatedBatch, &NamespaceSnapshot, PlanRef) -> Result<RenamePlan, RenameError>` in `graph.rs`. Native data only; no fileops import or filesystem IO. The complete selected row set is required. Inventory/generation, recipe revision, frozen numbering and grants must agree. Sources must match observed entry IDs, native paths and stamps. Duplicate IDs or overlapping source paths cannot become execution authority.
- `EvaluatedBatch.recipe: RecipeV1` retains the exact recipe for inspection provenance. Evaluation now permits directory candidates (a directory's full basename is its stem) and passes collision-suffix policy to planning. Unsupported rule/companion/destination/metadata evaluators remain fail-closed in their existing owning modules. The graph does not silently ignore requested metadata effects.
- `ExecutionPlan.expected_namespace: NamespaceSnapshot` retains the captured native namespace, original directory identities, name policies/capabilities, complete child entries, grants, protected policy and namespace/policy epochs. No serde execution-authority import or UI projection was added.
- `validate::preflight(&ExecutionPlan, &NamespaceSnapshot) -> Result<(), RenameError>` is a pure comparison against a fresh capture supplied by the later executor. It rejects changed entries (including a target created after preview with unchanged app epochs), directory identity, name limits, case/name policy, capabilities, grants, protected policy or epochs. Parent/entry/grant-ID listing order and observation windows are irrelevant to comparison. Native paths and names participate directly; display aliases never authorize anything.
- `PlanRow.carried_descendants` and `PlanRowDto.carried_descendants` expose carried inventory descendant counts; JSON uses an exact decimal string. Existing `PlanCounts` is the summary/count contract, including `counts.blocked`; no duplicate `summary.blocked_count` type was introduced.
- `PlanStore::confirm` refuses the entire plan if any row is Blocked/NeedsReview or any issue remains, including conflicts after row 200. `publish` now rejects divergent duplicated grant snapshots as it already rejected divergent frozen inputs.

Path resolution binds each row's target parent to its **original observed directory identity before spelling changes**. It follows selected directory ancestry, resolves final paths globally, preserves case-sensitive siblings and hard-link aliases as separate paths, and checks collision policy under the actual target parent's observed facts. This avoids inverting an ambiguous final path during directory swaps or suffix collisions. Directory suffixes are frozen in preview, update affected descendants irrespective of selection order, preserve unrelated existing destination identities, and trigger final path-length revalidation.

Directory moves require affirmative complete subtree coverage. Moving protected root entries or ancestors carrying a protected root is blocked. Normal contents of guarded registered library roots remain usable. Excluded/private subtrees and marker/staging exclusions retain their separate policy. Selected directory roots themselves are protected; individual selected **file** grants retain their supported in-place sibling output without granting sibling source authority. Cross-volume or unknown-volume targets fail closed pending Task19. Missing target parent observations fail closed; directory creation/copy/metadata executors are not fabricated here.

Graph compilation derives directed occupancy dependencies, connects hierarchy/association members, computes strongly connected components iteratively, and emits deterministically ordered dependency groups. Simple chains vacate their tail first. Swaps, larger cycles and case-only renames use deterministic native temporary reservations recorded in `RenameEntry { temporary: true }` steps. Names are checked against captured entries and final targets; no placeholder, random value or runtime temporary is created. Every creating/moving action requires an absent target.

A single current-location model updates selected entries, namespace occupancy and parent-directory locations after ancestor moves. Target readiness checks the intended parent identity, not merely whether some directory currently has that spelling. Shallow ancestors are parked before descendants, preserving Task04's requirement that a `FromReceipt` source path exactly equals its producing step's output. Compiled IDs/order and DTO bytes are deterministic for independently constructed plans with identical frozen inputs; supplied PlanRef is the only DTO difference.

## Approved shared-data/producer changes

The controller approved these narrow corrections, also appended to the task brief:

- `DirectoryFacts.stamp: FileStamp` supplies observed parent identity/volume. `capture_namespace` adds exactly one producer assignment, `facts.stamp = before.stamp.clone()`, using its already obtained directory observation. No native capability or mutation gate changed. A focused existing platform fixture compares this identity against an independent inventory observation.
- `ProtectedPolicy.guarded_roots` is exact root-entry/ancestor protection. Existing `protected_roots` remains excluded-subtree protection. `guards_move` shares conservative native comparison with inventory policy rather than conflating those meanings.
- `DirectoryFacts.names_equal` and `validate_path` are pure helpers alongside the existing `validate_name`. They use native units, per-parent case policy, component/full-path lengths, and Windows name/device-prefix checks. Preserved normalization with sensitive names retains exact spelling; insensitive Windows comparisons use the existing ordinal native-unit helper. Unknown normalization/case and non-ASCII insensitive POSIX comparisons fail closed rather than inventing filesystem Unicode semantics. Windows native runtime qualification remains disabled.
- Equality derives for grants and namespace facts support exact backend snapshot comparison. No dependency or Cargo.lock changes were necessary.
- Mechanical `expected_namespace: Default::default()` additions keep the existing manually constructed journal, PlanStore contract and desktop PlanRegistry test fixtures compiling. These fixture-only adaptations do not claim to be executable planner output.

## Task07/Task10 handoff

Task07 must capture/recheck the expected namespace under the matching Coordinator Write lease, verify the existing namespace/policy epoch authority, then enforce fresh source identity and absent target at **every native effect**, including reserved temporary names. A successful pure preflight does not close an external target-created-after-preflight race. Keep the lease through durable finalization/epoch advancement and use the existing no-replace mutation seam and journal. No executor, journal write or lease acquisition occurs in Rename.

For durable inspection, Task07 must preserve `expected_namespace` alongside existing provenance, including lossless native parent/entry paths and names, directory/entry stamps, case/normalization/name limits, grants, guarded and excluded roots, marker/staging policy and exact epochs. The existing private journal inspection serializer was not extended in this task: its execution steps remain persisted by Task04, but it does not yet serialize this new expected-namespace field. This is an explicit handoff, not a claim of new persistence/recovery functionality. Post-restart recovery still relies on journaled compiled effects and fresh evidence, never this preview snapshot.

Namespace capture must include original source/target directory identities needed by the candidates, including original parents that will move. Target parents created by later destination/copy features need their owning compiler's additional contracts. Task10 owns session creation and invalidation on inventory/recipe/selection changes; PlanRegistry's coordinator/epoch validation and exact backend epoch types remain unchanged.

## Named red/green evidence

Portable command environment:

```sh
export CARGO_HOME=/workspace/.tools/cargo
export RUSTUP_HOME=/workspace/.tools/rustup
export PATH=/workspace/.tools/cargo/bin:$PATH
```

All graph tests use synthetic read-only Inventory/NamespaceSnapshot fixtures. They create no media files or source directories. Their independent interpreter applies exact compiled path moves, rejects occupied targets/stale sources, and verifies resulting entry locations. Only the narrow native capture producer regression uses the existing real temporary platform fixture.

1. `cargo test -p vidlib-rename --test graph`: `/workspace/scratch/task06-red.log` records **7 intended behavioral failures, 0 passes** against minimal empty-graph scaffolding. `swap_and_three_cycle_plan_without_overwrite` expected 3 steps and got 0; `case_only_rename_uses_reserved_temp` expected 2 and got 0; `parent_and_child_keep_one_location_model` retained `/media/old/new.mkv` instead of `/media/new/new.mkv`; `target_parent_case_policy_controls_collisions` had no compiled steps; `root_and_marker_protected`, `outside_destination_and_ancestor_cycle_blocked` and `hidden_page_conflict_blocks_entire_approval` expected blocked count 1 and got 0. These were assertion failures, not missing-interface compile failures. `/workspace/scratch/task06-green1.log`: **7 passed** after core implementation. An unused import warning in that early run was removed before final checks.
2. Same graph command, `/workspace/scratch/task06-edges-red.log`: **16 passed, 1 failed**. `directory_collision_suffix_rebases_all_descendants` expected an executable suffixed directory with a child listed first; observed blocked count 2. Other edges added in that batch were regression coverage and are not claimed independent reds.
3. Same graph command, `/workspace/scratch/task06-preflight-red.log`: **16 passed, 5 failed**. In addition to the suffix failure, `target_created_after_preview_fails_pure_preflight` and `changed_namespace_identity_policy_and_epochs_revoke_preflight` incorrectly returned success; `missing_subtree_coverage_blocks_directory_move` returned blocked count 0 instead of 1; `overlapping_source_paths_are_rejected` incorrectly returned a plan. `/workspace/scratch/task06-edges-green.log`: **21 passed** after corrections.
4. Same graph command, `/workspace/scratch/task06-hierarchy-red.log`: **23 passed, 3 failed**. `directory_swap_and_child_rename_use_receipts_and_current_locations` ended with `/media/a/new` rather than `/media/b/new` because an existing spelling was mistaken for the final parent identity. `suffix_must_revalidate_descendant_path_lengths` accepted an overlong descendant after suffixing. `unsupported_compiled_effects_fail_closed` silently accepted requested metadata. `/workspace/scratch/task06-hierarchy-green.log`: **26 passed** after identity-bound parent readiness, final validation and explicit unsupported-effect rejection.
5. `cargo test -p vidlib-rename --test graph descendant_first`: `/workspace/scratch/task06-receipt-red.log` records **1 intended failure** in `descendant_first_selection_keeps_receipt_paths_resolvable`. A child's temporary step produced `/media/old/.vidlib-rename-…-0`, but its later receipt reference used `/media/OLD/.vidlib-rename-…-0` after the ancestor moved. This violates Task04's exact receipt-path contract even though the physical identity was carried. Selecting the shallowest eligible cycle member before descendants fixes the order. `/workspace/scratch/task06-receipt-green.log`: **1 passed**.
6. `cargo test -p vidlib-rename --test graph directory_suffix_preserves`: `/workspace/scratch/task06-parent-identity-red.log` records **1 intended failure** in `directory_suffix_preserves_unrelated_destination_identity`: blocked count 1 instead of 0 because inverse final-path lookup confused an existing destination directory with a moved directory colliding at its name. Original target-parent identity bindings and scoped descendant suffix rebasing fix the ambiguity. Full scoped graph run `/workspace/scratch/task06-parent-identity-green.log`: **28 passed**, no warnings.
7. `cargo test -p vidlib-fileops --test platform directory_case_policy_is_per_parent`: `/workspace/scratch/task06-capture-red.log` records **1 failure** with the new producer assignment omitted: parent physical identity was None instead of the independent observed identity. This is a producer-omission regression, not a claim that the test preceded the first assignment draft. `/workspace/scratch/task06-capture-green.log`: **1 passed, 17 filtered** with the assignment restored.

Additional graph coverage: independent DTO/step determinism despite namespace entry order; complete-selection and duplicated-grant validation; target-parent sensitive/insensitive collisions; selected root/marker and nested guarded-root ancestry; permitted contents of guarded roots; excluded descendants and exact carried counts; hard-link paths; individual-file grant source scope; invalid Unix native Unicode display aliases; absent versus mismatched directory volume; component/full-path lengths; acyclic dependency groups; case-only reservations; directory swaps; and Windows-only ADS, DOS devices, trailing names, UNC/extended long paths and device namespace prefixes. Windows-only assertions were compiled, not executed here. The final Windows-only review tightened allowed prefixes to ordinary/verbatim disk and UNC forms, rejecting GLOBALROOT/generic verbatim device targets as well as DeviceNS; only the Windows compile check was rerun for that cfg-only refinement.

## Final checks

One full workspace test run:

```sh
source /workspace/.tools/desktop-env.sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace
```

`/workspace/scratch/task06-workspace-final.log`: **189 passed, 0 failed**, all doc tests successful, no warnings. This is the 161-test Task05 baseline plus 28 graph tests; includes all 15 desktop tests. Windows-only runtime binaries are not counted as executed Windows evidence. The subsequent cfg(windows)-only device-prefix refinement does not change the Linux code exercised by this run.

Scoped checks:

- `cargo clippy --locked -p vidlib-rename -p vidlib-inventory -p vidlib-fileops --all-targets -- -D warnings`: **passed**, `/workspace/scratch/task06-clippy-final.log`. Earlier Clippy identified one unnecessary unit expression; it was removed before this final run.
- `cargo fmt --all -- --check`: **passed**, no output; `/workspace/scratch/task06-fmt-final.log`.
- Fresh shell, `source /workspace/.tools/windows-check-env.sh`, then `cargo check --locked -p vidlib-inventory -p vidlib-rename -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu`: **passed**, `/workspace/scratch/task06-windows-final.log`; includes final device-prefix refinement and Windows-only tests. No Windows runtime or native gate qualification is inferred.
- `git diff --check`: **passed**. No dependency additions, resolver drift or Cargo.lock edit.

## Self-review and remaining limits

Reviewed final graph/model/validation code, native helper changes, the single producer assignment, mechanical consumers and tests. Corrected directory identity versus spelling confusion in swaps/suffixes and the carried temporary-receipt path bug with named intended reds. Source/target volume comes from observations, never children or path spelling. Case and length policy stays attached to the original target parent even after ancestor moves. No lossy native reconstruction, overwrite, runtime temporary allocation, fileops dependency cycle or media IO was introduced. Exact grants/frozen values are cloned once into matching plan/provenance snapshots.

The graph is a focused 538-line module and validation a focused module; tests are separate. Straightforward whole-selection comparisons remain quadratic in some paths; no large-library performance qualification is claimed in this task. Unknown/normalizing filesystems and non-ASCII insensitive POSIX semantics conservatively block where native comparison authority is unavailable. Cross-volume copy, created destination directories and metadata effect compilation belong to later tasks and are explicitly unavailable here.

Actual Windows runtime (including UNC/shares, case-sensitive NTFS directories, unpaired UTF16 and installed application behavior), native mutation qualification, post-preview mutation race enforcement, durable expected-namespace inspection persistence and restart recovery remain their respective later owners. These are distinct pending checks, not assertions established by cross-compilation.

## Final focused freshness correction (after the full workspace run)

The controller required alignment with `PlatformFs::check_stamp` before committing: access-time-only changes caused by observation/content reads must not revoke unchanged authority. Both directory and entry preflight comparisons had this issue, as did the initial inventory-to-namespace source freshness check. All three now use the same pure material comparison contract: expected physical identity must be present and equal; size and modification time must match; a supplied creation time must remain available/equal; Windows attributes must match. Access time is inspection data. If creation time was initially absent, newly available creation time is allowed. Complete stamps remain unchanged in the plan/expected namespace; only local comparison copies are normalized after material validation. Other native paths, entries, ancestry, name/policy facts and epochs still compare exactly.

Added four focused graph regressions. `/workspace/scratch/task06-freshness-red.log` records **29 passed, 3 intended failures** under `cargo test -p vidlib-rename --test graph`: `preflight_ignores_only_directory_and_entry_access_time` and `newly_available_creation_time_does_not_revoke_preflight` incorrectly rejected identical authority; `preview_source_access_time_drift_remains_usable` reported blocked count 1 rather than 0. `material_stamp_changes_still_revoke_preflight` was additional regression coverage, not an intended red: it exercises changed identity, size, mtime, missing supplied creation time and attributes for both directories and entries.

Final-after-change evidence, distinct from the earlier 189-test workspace run:

- `cargo test --locked -p vidlib-rename --test graph`: **32 passed, 0 failed**, no warnings; `/workspace/scratch/task06-freshness-green.log`.
- `cargo test --locked -p vidlib-fileops --test platform directory_case_policy_is_per_parent`: **1 passed, 17 filtered**, no warnings; `/workspace/scratch/task06-producer-final-after-freshness.log`.
- `cargo clippy --locked -p vidlib-rename -p vidlib-inventory -p vidlib-fileops --all-targets -- -D warnings`: **passed**, `/workspace/scratch/task06-clippy-after-freshness.log`.
- `cargo fmt --all -- --check` and `git diff --check`: **passed**, formatting log `/workspace/scratch/task06-fmt-after-freshness.log`.
- Final Windows all-target compile of inventory/rename/fileops, using the same SDK command: **passed**, recorded in `/workspace/scratch/task06-windows-after-freshness.log`.

No full workspace rerun was performed after this focused change, as explicitly instructed by the controller. The earlier full workspace run remains 189 passes; the final graph count is now 32. Directory access-time invalidation is corrected, not a deferred concern.


## Commit and review focus

Task-owned code and mechanical consumer adaptations are committed in `fa5051e70534e3b31ec6c340400c427a988941c6`. The report is retained at the requested ignored `.superpowers/sdd` path, consistent with prior task reports. Working tree is clean after the code commit.

One remaining review concern identified while finalizing: the scheduler can emit a ready descendant move out of its directory before a blocked ancestor rename/temporary step. That descendant effect can change the ancestor directory's material stamp even though its identity is preserved. A concrete shape to review is directory `A -> B`, file `B -> A/x` (resolving to `B/x`), and child `A/x -> outside`; the ready escape can precede parking `A`. The later executor's strict material source check may then reject the ancestor's original Observed stamp. No mutation executor exists here, and the current pure interpreter checks occupancy/locations rather than modeled mtime side effects. This is raised explicitly for independent review rather than claimed covered; no extra scope or broad test run was added after the controller's finalization instruction.

## Pre-review correctness fix — ancestor prestates and protected cycle reservations

Fix commit: `838cb034b41d5b907f6780956c578fbf918f1a99` — `fix: preserve ancestor prestates and protect cycle reservations`. This follows `fa5051e70534e3b31ec6c340400c427a988941c6`; the whole-task review base remains `7f7d2d2a1e874183114ebcf2a5dd382c1e6e934d`.

The ancestor material-stamp concern above is **resolved**, not deferred. The controller requested closing it before independent review and identified that cycle reservations must also live under the canonical protected operation namespace.

### Scheduling/prestate correction

A candidate step is eligible only when every selected ancestor directory still pending in its dependency group has completed its final move. This restriction applies to both direct ready moves **and temporary reservations**. A parked ancestor is still pending, so a child cannot mutate its directory contents between the ancestor's temporary receipt and its final receipt-consuming move. The scheduler reserves another eligible dependency blocker when needed, then finalizes the ancestor before releasing descendants. No source identity/material check was weakened, and no execution model extension or runtime IO was needed.

The exact regression shape is `A(directory) -> B`, `B(file) -> A/x` (resolved to `B/x`), `A/x -> outside`. Added `ancestor_finishes_before_descendant_escape_changes_its_material_stamp` plus `descendant_escape_material_prestates_survive_selection_permutations` (three additional selection orders). An independent pure interpreter now tracks exact source/target paths and observed/receipt identity states, updates parent-directory mtime after direct child removal/addition even at a temporary location, requires absent targets, and checks all material prestate fields before consuming every step. It asserts each receipt's exact recorded output path as well as final entry locations. The exact-shape test additionally asserts that the ancestor's final step precedes the child's first effect; merely parking the ancestor is insufficient.

Progress remains bounded: every successful non-temporary step completes a pending row, and each row is parked at most once. A dependency arrangement with neither a ready eligible move nor an unparked eligible reservation returns an `InvalidPath` issue, `no progress: pending ancestor moves cannot finish before descendant namespace writes`. Exhausting the bounded reservation search returns `no legal temporary reservation available`. In either case all execution groups are discarded and changed rows are blocked; authority is never relaxed. The custom-policy regression verifies the latter failure has no compiled groups and that precise issue.

### Final reservation/policy interface for Task07

- Shared `vidlib_inventory::RENAME_TEMP_PREFIX` is **`.vidlib-staging-rename-`**, under existing `STAGING_NAME_PREFIX` **`.vidlib-staging`**.
- Final reserved names are **`.vidlib-staging-rename-<EntryId>-<ordinal>`**. The unpredictable backend EntryId remains frozen in the preview; search ordinals are deterministic. Exact native paths remain recorded in `ExecutionAction::RenameEntry { temporary: true }`.
- `ProtectedPolicy::excludes` always excludes the canonical operation staging namespace, in addition to configured staging prefixes. It is not removed to permit planning. Ordinary inventory/selection and ordinary Rename output therefore reject cycle temps.
- `ProtectedPolicy::allows_rename_reservation(&Path) -> bool` is the narrow internal **path-policy predicate** for a compiled reservation. It requires the dedicated canonical rename prefix, refuses an excluded parent, preserves exact marker protection, refuses guarded/protected root entries or ancestors, and honors additional configured exclusion prefixes. It is not a permission token or a filesystem operation. The graph additionally validates native name/path limits and checks captured occupancy/final targets.
- Task07 must authorize only the exact source/target reserved paths of the compiled step under its operation ownership, write lease, fresh source checks and no-replace native effect. Source temps reached through earlier durable receipts need that same explicit internal operation authorization. This helper does not allow arbitrary UI-supplied paths or relax normal protected-path validation.

The focused policy tests demonstrate that ordinary selection/output to an actual compiled temp is blocked, that the path is excluded from normal inventory policy, that it contains the frozen EntryId, and that internal reservation search skips names protected as the active marker or an exact guarded root. A custom prefix blocking all rename reservations produces a blocked plan with no steps.

### Exact red/green and final checks

All commands use the previously documented Cargo environment. No broad workspace test rerun was performed.

1. `cargo test --locked -p vidlib-rename --test graph material_`: `/workspace/scratch/task06-ancestor-stamp-red.log`, **1 passed, 2 intended failures**. Both newly named scheduling tests report `directory prestate invalidated by an earlier child namespace mutation: /media/A`, actual mtime `Some(10000)` versus expected `None`. The existing material preflight regression passed and is not counted as red evidence.
2. `cargo test --locked -p vidlib-rename --test graph temp`: `/workspace/scratch/task06-temp-policy-red.log`, **2 passed, 2 intended failures**. `cycle_temps_use_protected_operation_staging_and_cannot_be_selected` fails `normal inventory must exclude operation temps`; `internal_temp_reservations_still_honor_marker_root_and_custom_policy` observes the old `.vidlib-rename-…-0` rather than canonical protected reservation `…-2` after skipping guarded names.
3. After implementation, `cargo test --locked -p vidlib-rename --test graph`: `/workspace/scratch/task06-ancestor-and-temp-green.log`, **36 passed, 0 failed**, no warnings.
4. Final focused command `cargo test --locked -p vidlib-rename --test graph --test contracts`: `/workspace/scratch/task06-pre-review-fix-tests.log`, **18 contract tests + 36 graph tests passed, 0 failed**, no warnings. This includes the strengthened failure-issue/no-groups assertion.
5. `cargo test --locked -p vidlib-inventory protected`: `/workspace/scratch/task06-pre-review-fix-policy.log`, **3 protected-policy tests passed, 0 failed** (other test binaries have zero matching tests). Existing selected-subtree, marker/staging listing and case-alias policy behavior is preserved.
6. `cargo clippy --locked -p vidlib-rename -p vidlib-inventory -p vidlib-fileops --all-targets -- -D warnings`: **passed**, `/workspace/scratch/task06-pre-review-fix-clippy.log`.
7. `cargo fmt --all -- --check`, `git diff --check` and staged diff check: **passed**, formatting log `/workspace/scratch/task06-pre-review-fix-fmt.log`.
8. Fresh shell, `source /workspace/.tools/windows-check-env.sh`, then `cargo check --locked -p vidlib-inventory -p vidlib-rename -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu`: **passed**, `/workspace/scratch/task06-pre-review-fix-windows.log`. This compiles the final production correction; the subsequent test-only strengthening adds portable assertions on the blocked plan. Actual Windows runtime remains pending.

Self-review confirmed that pending ancestors include parked directories, both scheduling branches enforce the invariant, reservations retain exact native paths and deterministic ownership, canonical exclusion is preserved for ordinary users, and the internal predicate retains marker/root/custom-policy constraints. No shared execution-action extension, fileops production edit, dependency/lockfile update, native mutation gate change or broad test rerun was added in this fix. The earlier 189-test workspace run remains recorded separately; final focused graph coverage is now 36 tests. No known material-stamp correctness concern remains from the identified shape; independent review is still required by the controller workflow.

## Review round 1/5 — validate unselected carried descendants

Review: `/workspace/scratch/task06-review.md`. Fix base: `838cb034b41d5b907f6780956c578fbf918f1a99`. Fix commit: `a68207e27c3724d65a33eadb8a91b70f8e7082ac` — `fix: validate final paths of carried descendants`.

Resolved the single Important finding: a selected directory could pass its own final-path checks while carrying an unselected descendant beyond that descendant's captured parent path limit. Collision suffixes could create the same unvalidated growth.

The planner now validates carried inventory descendants after all final directory targets and collision suffixes are frozen, before compiling any execution groups. Selected descendants retain their existing row/target-parent validation; every unselected carried entry resolves through its nearest selected directory's frozen final destination. The original carried-path resolver was moved into a shared crate-private `carried_destination` helper used by both collision occupancy and carried-path validation, avoiding divergent transformation rules. No display path is used as authority.

Each carried entry uses `DirectoryFacts` captured at its original native parent, preserving that directory's observed identity and policy across ancestor spelling changes. Missing parent facts, absent parent identity, incomplete/error-bearing observations, unknown name/case policy or unavailable normalization authority block the responsible selected directory with `InvalidNamespace`. The shared `DirectoryFacts::validate_path` checks the final native path against that parent's component/path policy; a violation blocks the selected directory with `InvalidPath`. The issue names the carried EntryId. A blocked plan emits no executable groups. Existing selected-row checks, material prestates, protected policy, execution ownership and fileops interfaces are unchanged.

Files changed:

- `crates/vidlib-rename/src/graph.rs`: run final carried validation after suffixing; use the shared carried-destination resolver for collision occupancy.
- `crates/vidlib-rename/src/validate.rs`: shared carried destination resolution and original-parent-facts validation for unselected inventory descendants.
- `crates/vidlib-rename/tests/graph.rs`: three synthetic read-only regressions. No media fixture writes, executor behavior, shared public model extension or unrelated rewrite.

Exact test-first evidence, using the documented Cargo environment:

1. `cargo test --locked -p vidlib-rename --test graph carried_` — `/workspace/scratch/task06-review1-carried-red.log`: **1 passed, 3 intended failures**. `direct_directory_growth_validates_unselected_carried_child_path` and `directory_suffix_growth_validates_unselected_carried_child_path` each observed blocked count **0** rather than **1** with the child removed from selection. `unavailable_carried_parent_facts_block_responsible_directory` also observed **0** rather than **1** when the child's original parent facts were absent. The existing carried-count/exclusion test passed and is not claimed as new red evidence.
2. Same command after implementation — `/workspace/scratch/task06-review1-carried-green.log`: **4 passed, 0 failed**. Direct growth includes a legal equal-length rename first, then rejects `old -> longer`; suffix growth checks frozen `new-1` and rejects the carried `new-1/child`. Both require the responsible directory row to be blocked with no groups. Missing-facts coverage exercises four unavailable states: absent parent, absent directory identity, incomplete parent listing and unknown name policy. It requires an `InvalidNamespace` issue on the selected directory.

Final focused checks:

```sh
cargo test --locked -p vidlib-rename --test graph --test contracts
```

`/workspace/scratch/task06-review1-final-tests.log`:

```text
test result: ok. 18 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
test result: ok. 39 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
```

No warnings or failures.

- `cargo clippy --locked -p vidlib-rename --all-targets -- -D warnings`: **passed**, `/workspace/scratch/task06-review1-clippy.log` (`Finished dev profile`, no warnings).
- `cargo fmt --all -- --check`: **passed**, no output; `/workspace/scratch/task06-review1-fmt.log`.
- `git diff --check` and staged diff check: **passed**.

Reviewed the focused final diff: path resolution is shared with collision occupancy, facts stay bound to original parents, missing authority fails closed, and validation happens after suffixes but before any compiled groups. No dependency/Cargo update, executor/native-gate change or canonical checklist edit. No broad workspace or additional platform run was performed in this focused review fix; earlier evidence remains separately recorded. Windows runtime, durable expected-namespace inspection, file-grant orchestration and process/session wiring remain explicitly pending later-owner integration items from the review, not new findings implemented here. The Important carried-path validation finding is resolved; ready for re-review.
