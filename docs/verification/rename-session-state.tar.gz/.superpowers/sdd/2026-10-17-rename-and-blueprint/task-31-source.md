### Task 31: Blueprint foundation acceptance and performance

**Files:** Create `docs/verification/blueprint-foundation.md`, `crates/vidlib-blueprint/tests/foundation.rs`, `tests/ui/blueprint-foundation.spec.mjs`; extend the fixture benchmark tool and CI's portable/Windows matrix.

**Interfaces:** No new feature interface. Verifies all ten acceptance scenarios in Blueprint spec section 11 independently of Rename's release gate.

- [ ] **Step 1 — Red:** Add a multi-root disposable library walkthrough: register, baseline, restart, rebind one drive, external edits, failed subtree, app rename + replay, template preview, export/import to a new local store, prune/remove. Assert retained coverage, qualified events and no identity merge throughout.
  ```rust
  assert_eq!(offline_refresh.missing_count, 0);
  assert_eq!(replayed_event_occurrences, 1);
  assert!(!imported_collection.has_active_binding());
  assert_eq!(unexpected_media_mutation_count, 0);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test foundation`; `npx playwright test tests/ui/blueprint-foundation.spec.mjs`. This should expose any missing integration before release claims.
- [ ] **Step 3 — Implement:** Fix only integration gaps against approved scope; add reproducible 100,000-entry cached map/first-page/history benchmark with mixed-age roots and pattern denominators. Record explicit observed schema/algorithm versions and platform details. Do not upgrade this task into convention inference or a semantic media organizer.
- [ ] **Step 4 — Verify green:** Full Blueprint suite, UI accessibility/console checks, real Windows removable/share identity/coverage evidence, cached first page <=1 second target on recorded hardware, 200-row paging and 10/s progress. Mark achieved/failed/pending benchmarks truthfully; a proof-of-concept label does not replace the acceptance loop.
- [ ] **Step 5 — Commit:** `test: verify the Blueprint collection-map foundation`.

