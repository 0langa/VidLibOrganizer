# Task 11 implementation report

Status: DONE. Base `90ff5dbb75594f514acde7ab2401215e2e9f3cb3`.
Commit: `d3beffd1719b419fb382e171eb23e9ee401b6a7a` — `feat: add composable Unicode text and extension rules`.
Worktree: `/workspace/VidLibOrganizer/.worktrees/rename-blueprint`; existing `feat/rename-blueprint` branch retained. No helpers/subagents, canonical checklist edits, push, merge, or publication.

## Scope and public interfaces

Implemented backend R01–R03/R10 in the prescribed `crates/vidlib-rename/src/text.rs`, with table-driven behavioral coverage in `tests/text.rs`, and connected the operations to the existing recipe/evaluate pipeline.

- `apply_text(input: &NameParts, rule: &TextRule) -> Result<NameParts, RuleIssue>`.
- `resolve_segment(current: &str, selector: &SegmentSelector) -> Result<Range<usize>, RuleIssue>`.
- `NameParts { pub stem: String, pub ext: String, /* private separator flag */ }`: `from_filename`, `stem_only`, `filename`, `segment`. Splitting treats the input as component text, never as a platform path. The private flag preserves an unchanged trailing dot; leading-dot files retain their stem semantics. A nonempty extension is rendered with its separator.
- `TextRule { segment, operation }`, `RuleIssue { message }` (also Display/Error), strict tagged `TextOperation`/`InsertPosition` and typed `LiteralReplacement`, `CharacterTranslation`, `MatchScope`, `CropSide`, `CaseMode`, `RomanCase`.
- `RuleParameters::Text { operation }`; all nested configuration types reject unknown fields/tags. Existing Keep/FixedStem serialized forms and validation remain supported.
- `SegmentSelector::Between { target, opening, closing, occurrence, include_delimiters }`, plus `SegmentSelector::target()`; preserved the existing Delimited serialized shape.
- `RenameErrorCode::InvalidRuleInput`: a failed text rule blocks only its row, carries the rule ID and message, preserves the original source target, and does not publish partial transformed targets. Successful preceding rule explanations remain available. The original/current NameParts are separate values; original display/native source fields remain unchanged.

Operations include keep/fix/remove selected text, prefix/suffix/insert, ordered literal replacements with explicit first/all and sensitivity, character removal, inclusive range removal, crop before/after a literal delimiter occurrence, move/copy, reverse, Unicode trim/whitespace collapse, simultaneous character translation, explicit transliteration, and all keep/upper/lower/title/sentence case modes. Extension add/replace use Fixed on the explicit Extension selector, removal uses Remove, and extension casing uses Case. WholeName explicitly permits changes across the separator and re-splits the resulting name. Empty or invalid filename output is an issue; there is no sanitization.

## Precise semantics and controller ruling

All logical positions are one-based extended graphemes; negative values count from the end and endpoints are inclusive. Zero, reversed or out-of-range positions yield RuleIssue. The returned resolver range is checked zero-based, half-open UTF-8 bytes into the already selected current target. Insert Before uses those same valid indices; End is an explicit append option. Move/copy coordinates refer to the selected input before the operation. Moving inside the source range is rejected; an anchor after the source is adjusted after removal. All rules resolve again on their current NameParts and alter only their resolved range.

Controller explicitly ruled: existing Delimited selects text after the Nth literal non-overlapping delimiter through the next same delimiter/end; `include_delimiter` includes the opening delimiter. Between selects the Nth flat non-overlapping opening/closing pair, optionally including both delimiters. This is literal flat pairing, not a nested parser. Empty/missing delimiters, missing pairs, zero/out-of-range occurrences and delimiters splitting graphemes yield structured issues. Existing recipe-level rejection of empty/zero Delimited selectors is retained; Between's row-dependent failures are exposed through evaluate. Crop separately makes before/after and delimiter inclusion explicit.

Replacement entries execute in order; matches within an entry run left-to-right without overlap, at grapheme boundaries. Case-insensitive replacement uses full default Unicode case folding. Character translation is simultaneous scalar translation: inserted replacements are not translated again. Character removal intentionally removes configured scalar characters; range/crop/move/reverse use grapheme boundaries. Trim and CollapseWhitespace are separate explicit operations; collapse preserves the presence of leading/trailing runs by replacing them, rather than implicitly trimming.

Case uses Unicode word boundaries, full mappings, and Unicode sentence boundaries. Title/sentence use full title mappings including sharp-S and digraphs; lowercase preserves contextual Greek sigma and expanded dotted-I mappings. Case exceptions are distinct whole-word case-insensitive matches restored to the configured spelling; folded duplicate/multiword exceptions are rejected. Exceptions take precedence over Roman handling. Roman None is disabled; Keep/Upper/Lower are explicit and recognize canonical ASCII numerals 1–3999, not arbitrary combinations such as IIV. No normalization or transliteration is performed unless the rule requests a relevant transformation. Transliteration is explicit deunicode behavior, not locale inference.

## Dependencies and ownership

Task-owned direct dependencies: `unicode-segmentation` (resolved existing workspace package 1.13.2), `unicode-case-mapping` 1.0.0 (full Unicode title mappings), `caseless` 0.2.2 (full Unicode case folding, used without normalization), and `deunicode` 1.6.2 (explicit transliteration). Caseless adds unicode-normalization/tinyvec transitively, but no normalization API is called. Lockfile committed. An incidental cargo-fetch re-resolution of cssparser-macros' syn dependency was restored before final locked verification; final lock diff contains task additions only.

Changed files: owning crate Cargo.toml, src/lib.rs, model.rs, recipe.rs, evaluate.rs, new text.rs, new tests/text.rs, root Cargo.lock. No UI, desktop adapter, engine, fileops, inventory, or Blueprint code changes.

## TDD evidence

Commands below ran from the worktree. For unqualified cargo commands in this section the exact command-scoped Rust environment was:

```
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

The interfaces were first scaffolded with identity `apply_text` and full-range `resolve_segment`, without transformation implementation. This let the real compiled public APIs produce behavioral assertion failures instead of missing-interface compiler errors. No compile-error red is counted.

1. `cargo test -p vidlib-rename --test text` → exit 101, 0 passed / 6 failed, raw `task-11-red.log`.
   - `text_rule_goldens`: named literal mismatches across the table, e.g. prefix wanted `pre-abc.MKV`, actual `abc.MKV`; ordered replacement wanted `Cb.MKV`, actual `a_a.MKV`; transliteration wanted `Ying Xiang cafe.MKV`, actual `影像 café.MKV`; uppercase wanted `STRASSE.MKV`, actual `Straße.MKV`; title/sentence and paired-delimiter outputs also failed.
   - `segment_resolves_each_current_input`: wanted `A [longer] B [TWO] C.mkv`, actual original input.
   - `unicode_graphemes_are_not_split`: wanted `e\u{301}faC`, actual `Cafe\u{301}`.
   - `case_exceptions_and_roman_are_explicit`: all four explicit Roman settings had incorrect unchanged outputs. Corrected one independently identified expected-value typo before implementation/green: a non-exception `bbcish` title-cases to `Bbcish`, not `BBCish`; this preserves the whole-word requirement.
   - `extension_requires_explicit_mode`: extension add/remove/replace/case and WholeName all produced wrong unchanged names.
   - `invalid_positions_delimiters_and_names_are_row_issues`: identity resolver incorrectly accepted every invalid selector, including zero and i32::MIN.
2. Same command after adding evaluator tests → exit 101, 0 passed / 8 failed, raw `task-11-red-integration.log`. Both `evaluator_composes_text_segments_and_retains_original` and `evaluator_blocks_row_on_rule_issue_with_rule_id` failed with real `UnsupportedRule` from the current evaluator.
3. `cargo test -p vidlib-rename --test text invalid_operations_never_succeed_as_noops` → exit 101, 0 passed / 1 failed. Raw `task-11-red-validation.log`: malformed replacement/crop/translation/exception/move configurations were all incorrectly accepted by the identity scaffold.
4. Implemented rules and evaluator. `cargo test -p vidlib-rename --test text` → exit 0, 9 passed, raw `task-11-green-initial.log`.
5. Self-review regression `whole_name_is_validated_before_splitting_and_noops_preserve_spelling`:
   - `cargo test -p vidlib-rename --test text whole_name_is_validated_before_splitting_and_noops_preserve_spelling` → exit 101. Raw `task-11-red-whole-name.log`: `sub/new.mkv` was improperly accepted because path splitting discarded its parent.
   - After validating WholeName before splitting, same command → exit 101. Raw `task-11-red-trailing-dot.log`: wanted `trail.`, actual `trail` for unchanged extension output. Fixed separator preservation while keeping explicit Remove/Fixed-empty removal.
6. Self-review regression `input_components_are_never_implicitly_sanitized`: `cargo test --locked -p vidlib-rename --test text input_components_are_never_implicitly_sanitized` → exit 101. Raw `task-11-red-input-component.log`: invalid original component `sub/new.mkv` incorrectly succeeded as Keep. Replaced platform-path splitting with literal component splitting, preserving text for validation (including cross-platform drive-like punctuation).

Additional final coverage exercises missing closing/empty paired delimiters, huge occurrences, Unicode literal pairs, negative insertion, current-input Delimited resolution, and preserving the original target after a later rule fails. All assertions use literal hand-derived outputs; evaluator tests scan real temporary files and round-trip the typed recipe JSON.

All raw logs above live beside this report under the ignored SDD directory; no logs/process artifacts were force-added.

## Final verification (after all code changes)

- `cargo test --locked -p vidlib-rename --test text --test contracts --test graph` → exit 0: 13 text + 18 contracts + 40 graph = **71 passed**, 0 failed. Raw `task-11-green-focused.log`.
- `source /workspace/.tools/desktop-env.sh` then `CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace` → exit 0: **330 passed**, 0 failed / ignored, across 26 reported test/doc-test suites; no warnings/errors. Includes engine/finder, fileops, inventory, rename and desktop command/library tests. Run once for the final implementation. Raw `task-11-workspace.log` (finished in 53.63s).
- `cargo clippy --locked -p vidlib-rename --all-targets -- -D warnings` → exit 0, no warnings. Raw `task-11-clippy.log`.
- Fresh shell: `source /workspace/.tools/windows-check-env.sh` then `cargo check --locked -p vidlib-rename --target x86_64-pc-windows-gnu` → exit 0. Raw `task-11-windows-check.log`. This establishes compilation only.
- `cargo fmt --all --check` → exit 0.
- `git diff --check` and staged `git diff --cached --check` → exit 0.
- Self-reviewed the final source/test/manifest diff and task boundaries before committing. Post-commit tracked/untracked status is clean (SDD remains ignored).

## Self-review and limits

Self-review caught and fixed invalid WholeName/component path sanitization and implicit trailing-dot deletion with recorded behavioral reds. Reviewed inclusive and negative positions, empty segments, UTF-8 slicing, extension isolation, move anchor adjustment, replacement ordering, Unicode expansion/context, full-fold exception matching, strict serde variants and failed-row target preservation. No unrelated source or dependency updates retained.

The new text module contains the requested operations and their typed data (689 lines); tests use broad literal tables (919 lines). Both stay in the plan-owned files rather than introducing speculative module structure.

Windows runtime, filesystem behavior, hardware/performance and packaged release evidence remain pending. Cross-compilation does not satisfy those gates. Rename/Blueprint release gates remain closed; this task is a backend slice, not R01–R18 or UI/release completion. Existing unsupported Template/future configuration handling remains fail-closed for later tasks. No new frontend controls or scripting/runtime dependency was introduced. No correctness concerns remain from this implementation's self-review; independent controller review is still required.

## Fix round 1 — Unicode titlecase sentence capitalization (I1)

Review source: `/workspace/scratch/task11-review.md`; fix base `d3beffd1719b419fb382e171eb23e9ee401b6a7a`.
Fix commit: `c32ef3324db6446156249df65f2ba402c111e6e8` — `fix: consume Unicode titlecase letters in sentence casing`.

Addressed Important I1: the sentence capitalization state now recognizes Unicode Cased letters in category Lt through their nonidentity Unicode lowercase mapping, alongside Lowercase/Uppercase properties. U+01C5 `ǅ`, U+01C8 `ǈ`, U+01CB `ǋ`, and U+01F2 `ǲ` correctly consume sentence capitalization. Numeric/uncased words continue to leave capitalization available for the first following cased word. This uses the existing unicode-case-mapping dependency; no dependency/manifests or public interfaces changed.

Covering test file: `crates/vidlib-rename/tests/text.rs`, named `sentence_case_consumes_titlecase_letters_and_preserves_context`. Literal outputs cover all four Lt digraphs, numeric prefixes, sentence reset, contextual Greek final sigma, uncased Han prefixes, sharp-S expansion, exception and Roman precedence, Title mode, and grapheme-selected sentence casing that preserves outside text.

Exact Rust environment for commands below: `CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH`, command-scoped from the task worktree.

RED, before production changes:

```
cargo test --locked -p vidlib-rename --test text sentence_case_consumes_titlecase_letters_and_preserves_context
```

Exit 101; raw log `/workspace/VidLibOrganizer/.worktrees/rename-blueprint/.superpowers/sdd/2026-10-17-rename-and-blueprint/task-11-fix-1-red.log`:

```
running 1 test
test sentence_case_consumes_titlecase_letters_and_preserves_context ... FAILED
assertion `left == right` failed: sentence case for "ǅ hello.mkv"
  left: "ǅ Hello.mkv"
 right: "ǅ hello.mkv"
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 13 filtered out
```

GREEN, after scoped production fix: same exact cargo test command, exit 0. Raw `/workspace/VidLibOrganizer/.worktrees/rename-blueprint/.superpowers/sdd/2026-10-17-rename-and-blueprint/task-11-fix-1-green-regression.log`:

```
running 1 test
test sentence_case_consumes_titlecase_letters_and_preserves_context ... ok
test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 13 filtered out
```

Final covering checks:

- `cargo test --locked -p vidlib-rename --test text --test contracts --test graph` → exit 0, **72 passed**: contracts 18, graph 40, text 14; zero failures/ignored/warnings. Raw `/workspace/VidLibOrganizer/.worktrees/rename-blueprint/.superpowers/sdd/2026-10-17-rename-and-blueprint/task-11-fix-1-green-focused.log`.
- `cargo clippy --locked -p vidlib-rename --all-targets -- -D warnings` → exit 0, finished dev profile in 1.24s, no warnings. Raw `/workspace/VidLibOrganizer/.worktrees/rename-blueprint/.superpowers/sdd/2026-10-17-rename-and-blueprint/task-11-fix-1-clippy.log`.
- `cargo fmt --all --check` → exit 0.
- `git diff --check` and `git diff --cached --check` → exit 0.
- Self-reviewed the two-file fix diff before commit; post-commit status clean. No helpers, canonical edits, push, merge, branch change, or frontend changes.

The broader 330-test workspace suite was not rerun: the controller explicitly requested scoped text/contracts/graph verification for this casing predicate fix absent a new concern. The original full-workspace evidence above remains the preceding integration baseline; it is not claimed as a fresh post-fix workspace run.

Minor dotted-I mapping is deliberately unchanged and remains deferred for final triage, as instructed. This fix changes only sentence-state consumption, not title_first or the lower-then-title mapping path; it does not incidentally repair the codepoint behavior. Windows runtime/hardware checks remain pending, and Rename/Blueprint release gates remain closed.
