# Task08 — process-crash reconciliation and current-group compensation

Status: DONE_WITH_CONCERNS. Base: `b81d868070d5eb992f5e909c28285d2f407e79fd`. Code and available verification are complete for the reviewed journaled rename executor; actual Windows runtime and hardware power-loss qualification remain pending and mutation gates remain closed. Commit is recorded at the end.

## Scope and interfaces

Read Task08 brief/implementer contract, official implementer prompt/TDD/writing-good-tests instructions, final Task07 native-parent seam report, and relevant Task04–06 journal/coordinator/graph handoffs. No whole-plan reread, design restart, subagents, branch/worktree changes, canonical checklist edits, push or merge. Work stayed in the assigned worktree.

Public backend API in `crates/vidlib-fileops/src/recovery.rs`:

```rust
reconcile(&PendingOperation, &mut dyn Filesystem) -> Result<RecoveryPreview, OpError>
RecoveryPreview::review_nonce(&self) -> StepId
RecoveryPreview::review(self, nonce: StepId) -> Result<ReviewedRecovery, OpError>
apply_recovery(ReviewedRecovery, RecoveryChoice, &Lease, &mut Journal,
               &mut dyn Filesystem, &JobControl) -> Result<OperationReport, OpError>
inspect_legacy_interruption(&Lease) -> Result<Option<LegacyInterruption>, OpError>
```

`RecoveryChoice` is Resume/Restore. `RecoveryPreview` exposes deterministic `actions`, exact live `temporary_names` and `unresolved_groups`. Each `RecoveryAction` contains StepId, GroupId, completed phase, exact native before/after paths and one of Planned/NotApplied/Applied/Completed/Compensated/Unresolved. Its authoritative operation snapshot and nonce are private. ReviewedRecovery is non-Clone, non-serializable and consumed by application; the caller cannot reconstruct mutation paths from display strings. A mismatched nonce, different journal, non-Recovery lease, changed durable snapshot, changed classification or unresolved group rejects explicit application. Repeat inspection has stable actions.

`PendingOperation`/`OperationRecord` now also expose `recovery_effects: Vec<RecoveryEffect>`. Each holds its original StepId, separately compiled inverse PendingStep and original reviewed source/target parent PhysicalIds. Original compiled steps and original receipts remain intact; completed inverses are separate facts. Existing journal/read/event APIs continue to work. Public execute still requires an ordinary matching Write lease and rejects startup pending/recovery authority.

Controller-approved organization: orchestration/public review API in `recovery.rs`; private read-only action/namespace evidence in `recovery/evidence.rs`; private durable recovery transitions in `journal/recovery.rs`. No framework or dependency was added. Cargo manifests/lockfile and native Windows gates are unchanged.

## Behavior and authority

- Read-only reconciliation resolves actual intent/action/receipt gaps against native identity, material state, compiled paths, receipt lineage and original parent identities. It never reruns recipes or allocates replacement output names. Unknown/missing drives, conflicting entries, missing historical namespace evidence, unknown identities or unsupported digest verification remain explicitly unresolved.
- Rename Resume executes only the unchanged compiled next step after fresh source/parent verification and target absence. Recovery uses `rename_reviewed`/`rename_reserved`, mandatory expected parent IDs and no-replace semantics through native handle acquisition; there is no compatibility rename fallback.
- Restore compensates only the interrupted dependency group, in reverse durable effect order. Completed earlier groups stay completed. Each inverse has a new compiled step, its own durable intent, receipt and normal outbox event. Original receipts remain factual; only original step state becomes Compensated after a durable inverse completion. Crashes before/after inverse effects reconcile without replaying a completed inverse.
- Safe current-group compensation now runs automatically after ordinary runtime failure or mid-group cancellation. It stops following groups, verifies every inverse, and preserves unknown occupants. Journal-write failures and unconfirmed durability retain the recovery gate. The internal automatic entry point requires the current ordinary Write lease; it does not make public execute accept a Recovery lease.
- Restoring children legitimately changes directory material stamps. A directory inverse first verifies the complete fresh namespace against the original complete listings transformed by durable forward and inverse effects, including identity and material checks for unchanged entries. Unknown children block. The exact stamp observed with that verified listing is reverified before compiling the inverse; a later directory stamp is never substituted as fresh authority. Native source identity and parent IDs remain bound through the syscall seam.
- Legacy interrupted-write markers are exposed as read-only `LegacyInterruption { unresolved: true, explanation }`. No item paths, effects or completion events are fabricated, and no new marker-clear API exists. Explicit recovery refuses mutation while the unknown legacy marker remains.
- Namespace epochs advance while the appropriate exclusive lease remains held, including partial recovery outcomes. Original errors from failed compensation journal writes keep their inverse StepId instead of being masked by later finalization failure.

### Persisted phase family

All eight persisted action types have real evidence reconciliation fixtures. Rename and PublishCopy gaps recognize the same native object at the exact target only when the source location is absent and expected material state matches. PublishCopy additionally requires durable creation/verification lineage and verifies target content against the recorded digest. RemoveSource requires the published target identity and digest; owned cleanup requires its creation identity. Metadata compares expected pre/post fields. Removed objects can produce truthful removal facts; contradictory ownership stays unresolved.

CreateDirectory/StageCopy action gaps with an existing object but no durable creation identity stay unresolved, even if their filename is expected. An absent target (and verified source for staging) can prove non-application. Existing staging names are still reported. These are substantive classifications on real files, not Unsupported placeholders counted as tests.

This task does not implement future StageCopy streaming, stronger create-new ownership recording, copy/metadata phase execution or invented inverse copying. Resume/Restore physical effects remain the current executor's compiled RenameEntry family; already-applied publication/removal/metadata gaps can be durably reconciled and finalized. A planned/non-applied later-owned phase cannot execute through this rename recovery implementation and keeps the operation pending. Task19/20 and later metadata owners must extend phase execution/recovery together. Current recovery digest verification supports the existing `md5` digest label; unknown labels fail closed for the later phase owner to extend.

## Versioned durable protocol

Schema v5 adds `recovery_audit` and `recovery_effects` through checked BEGIN IMMEDIATE migration/explicit commit. v1–v4 SQL/checksums remain unchanged. Old inspection records retain the absence of expected namespace observations.

A freshly proved non-effect commits a `NotApplied` audit containing exact native source/target, prestate, target-absence result and reviewed parent IDs, then resets only that compiled intent to Planned in the same transaction. It emits no effect receipt/event. Inverse retries use the same fresh proof/audit followed by a durable rearm of their existing exact inverse. The audit is not a guessed filesystem completion.

Inverse compilation atomically inserts the inverse into existing steps plus its recovery-effect link and held-parent identities. Normal Journal completion atomically persists its receipt/event. Failed recovery audit or inverse-intent transactions prevent native effects. Recovery links are separated from original steps on inspection reads. No SQLite transaction spans filesystem work.

An original receipt with Unsupported/Failed filesystem flush is never silently finalized: recovery verifies its current poststate, flushes the required directory/file, and commits a `DurabilityVerified` audit. Original receipt durability and its one original event remain unchanged. That durable audit survives a later inverse gap, so recovery does not demand the historical forward pathname after it was durably restored. This is process-crash evidence only, not hardware power-loss qualification.

## Approved Task07 cancellation expectation changes

The controller explicitly adjudicated these as completing the Task08 safe-group requirement, not a broader cancellation redesign:

- Old `cancellation_inside_cycle_finishes_group_before_stopping`: cancellation after the first move continued all 3 forward moves, reported 1 completed group and swapped contents. New `cancellation_inside_cycle_restores_current_group_before_stopping`: 1 forward + 1 inverse, 0 completed groups, original contents; following group untouched.
- Old failed-cycle expectation retained a live temporary and one receipt. When fresh evidence proves the failed move did not occur and the temporary is owned, the new test expects Failed, the original bytes restored, the temporary absent, and both original/inverse receipts retained. Unknown ownership still leaves RecoveryRequired and preserves entries.
- A failed independent group with no effect can now finish Failed after a durable non-application resolution; completed earlier groups remain factual. `cycle_compensation_preserves_a_completed_earlier_group` covers an earlier completed rename plus a later partial cycle and untouched following group.
- Existing `cancellation_waits_for_group_boundary_and_reports_completed_groups` remains unchanged and passes: a fully completed group stays completed.

## Named red/green evidence

Portable commands use this command-scoped environment:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

Raw logs below are absolute, retained under `/workspace/scratch`. Missing-interface compilation and fixture setup errors are distinguished from meaningful assertion reds. Early test scaffolds were replaced by implementation. Supporting tests that passed on first addition are not claimed as independent reds.

1. `cargo test -p vidlib-fileops --test recovery`
   - `/workspace/scratch/task08-interface-red.log`: missing recovery API compilation failure only.
   - `/workspace/scratch/task08-red.log`: 3 intended failures: `crash_before_and_after_each_phase_reconciles` expected 3 classified cycle steps, got 0; `temporary_names_are_reported` expected 1 live temporary, got 0; `unknown_target_prevents_blind_resume` expected 1 unresolved group, got 0. Initial support-fixture unused imports/dead-code warnings were removed.
   - `/workspace/scratch/task08-red2.log`: adds positive Restore red; publication fixture initially used an invalid staging prefix, so its child exited 101 and that case is not counted as behavioral evidence.
   - `/workspace/scratch/task08-red3.log`: corrected real staged-publication fixture. **2 passed, 5 failed**: the prior 3 intended failures plus `restore_reverses_only_current_cycle_group` rejects verified restoration against the scaffold, and `published_phase_without_receipt_is_reconciled_once` expected 1 verified Applied fact, got 0.
   - `compensation_stops_without_deleting_unowned_entries` passed against the initial fail-closed scaffold; it is supporting preservation coverage, not claimed first-red evidence. Its positive Restore counterpart supplied the red.
   - `/workspace/scratch/task08-green-attempt.log`: **7 passed, 0 failed** after initial implementation, including all 6 before/after cycle gaps and the published-copy gap.
2. `cargo test -p vidlib-fileops --test rename compensates`
   - `/workspace/scratch/task08-auto-red.log`: **2 intended failures**. `runtime_failure_compensates_only_current_group` returned RecoveryRequired instead of Failed; `cancellation_compensates_partial_cycle` completed the partial group instead of restoring it.
   - `/workspace/scratch/task08-auto-green.log`: **2 passed** after automatic compensation.
3. `cargo test -p vidlib-fileops --test recovery`
   - `/workspace/scratch/task08-hierarchy-red.log`: **10 passed, 1 failed**. `directory_parent_restores_after_child_namespace_changes` failed StaleState by blindly reusing the parent receipt after child namespace changes.
   - `/workspace/scratch/task08-hierarchy-green.log`: **11 passed** after complete transformed-namespace proof. Includes actual before/after inverse process exits and the lost-drive/reconnect fixture.
4. Same recovery command:
   - `/workspace/scratch/task08-audit-red.log`: **13 passed, 1 failed**. `crashes_during_restore_do_not_repeat_an_inverse` lacked a durable NotApplied audit for an inverse retry.
   - `/workspace/scratch/task08-audit-green.log`: **14 passed** after audited inverse reset/rearm. `recovery_reset_is_audited_without_fake_completion` and `failed_recovery_audit_never_authorizes_a_filesystem_write` use real SQLite triggers and unchanged source bytes/zero events.
5. `cargo test -p vidlib-fileops --test recovery legacy_interruption`
   - `/workspace/scratch/task08-legacy-red.log`: **1 intended failure**: the legacy interruption was not visible as read-only unresolved evidence.
   - Covered green in `/workspace/scratch/task08-focused.log` and final suite.
6. `cargo test -p vidlib-fileops --test recovery every_persisted_phase`
   - `/workspace/scratch/task08-staging-report-red.log`: **1 intended failure**: unknown but existing staging was omitted from exact temporary-name reporting.
   - Final phase fixture passes all 14 before/after cases; `/workspace/scratch/task08-phases.log` also documents earlier substantive phase classification support before the staging-report correction.
7. `cargo test -p vidlib-fileops --test rename compensation_journal_failure`
   - The first broad error-preservation assertion passed (`task08-journal-error-red.log`); not counted as red.
   - `/workspace/scratch/task08-journal-context-red.log`: **1 intended failure** after strengthening the assertion: compensation durability error lost its inverse StepId through subsequent finalization.
   - Green in `/workspace/scratch/task08-focused-final.log` and final suite. Native call count remains 2 (forward + failing forward); no inverse syscall before recovery-intent durability.
8. `cargo test -p vidlib-fileops --test recovery directory_namespace_change`
   - `/workspace/scratch/task08-namespace-refresh-red.log`: **1 intended failure**: changing a directory after namespace capture was blessed by taking a later stamp as inverse authority.
   - Fixed by retaining/reverifying the captured stamp. `/workspace/scratch/task08-final-focused.log`: **105 passed** across recovery, rename, journal, coordinator and platform. `unowned_child_blocks_directory_material_refresh` separately preserves an external child.
9. Durability self-review:
   - `cargo test --locked -p vidlib-fileops --test rename recovery_cannot_clear`, `/workspace/scratch/task08-durability-red.log`: **1 intended failure**, an Unsupported receipt flush incorrectly cleared its gate.
   - `cargo test --locked -p vidlib-fileops --test recovery verified_flush_audit`, `/workspace/scratch/task08-flush-audit-red.log`: **1 intended failure**, prior verified durability was lost across a later inverse gap and demanded the no-longer-current historical pathname (SourceMissing).
   - `cargo test --locked -p vidlib-fileops --test recovery --test rename`, `/workspace/scratch/task08-durability-final.log`: **22 recovery + 36 executor tests passed**, no warnings, after durable flush-resolution audit and reuse.

`task08-combined-intermediate.log` is deliberately retained as a failed intermediate run: 4 existing rename expectations failed. Three were the explicitly approved Task07 compensation expectation changes above; one v3 migration fixture downgraded user_version but left v5 tables/checksum in place. Its fixture now removes all newer schema artifacts, genuinely exercises v3-to-v5 migration, and still preserves missing historical namespace. The failed migration fixture was corrected likewise so it reaches its intended trigger. `failed_v4_recovery_migration_rolls_back_without_losing_evidence` independently covers v5 rollback and retained original evidence. None of those failed intermediates is represented as final green.

## Process-crash evidence and coverage limits

`tests/support/crash_child.rs` creates real media files, obtains real Coordinator leases, opens real SQLite and calls PlatformFs. The integration binary launches its own filtered child entrypoint and asserts termination code 86 from `std::process::exit` inside the selected boundary, without running Rust destructors. Parents reopen the database/files and recover. No mocked Result alone is counted as process-crash evidence.

Coverage includes Prepared/before first intent; before/after each of three cycle native moves; before/after each of three inverse moves; directory/child hierarchy restoration; exact native temporary names; unknown destination preservation; all seven additional persisted phase before/after fixtures; published content verification; source/owned cleanup facts; metadata; loss/reconnection by making the media path unavailable; missing or changed review authority; current native parent replacement immediately before native handle acquisition; recovery audit and inverse-intent transaction failures; final durability resolution. Prior receipts observed before subsequent child crashes cover persisted receipt boundaries. Two of the 22 recovery test functions are the child-entry harnesses (normal invocation returns without a crash request).

The lost-drive fixture simulates path unavailability by moving the media directory; it does not claim removable-hardware testing. Windows-only runtime tests are not executed on Linux. SQL trigger failures exercise transaction boundaries, not OS power loss. External changes after the final native validation are not claimed to be isolated by a filesystem transaction.

## Final verification

Focused final behavioral command:

```sh
cargo test --locked -p vidlib-fileops --test recovery --test rename
```

`/workspace/scratch/task08-durability-final.log`: **58 passed, 0 failed** (22 recovery, 36 executor), no warnings.

Broader workspace (fresh Linux desktop shell):

```sh
source /workspace/.tools/desktop-env.sh
CARGO_TARGET_DIR=/workspace/.tools/desktop-target cargo test --locked --workspace
```

Initial `/workspace/scratch/task08-workspace.log`: **256 passed, 0 failed**, all doctests successful. The later substantive durability correction and added coverage justified one final rerun. `/workspace/scratch/task08-workspace-final.log`: **261 passed, 0 failed**, all doctests successful, no warnings. Includes 36 executor, 22 recovery, 19 journal, 13 coordinator, 20 platform, 16 fileops unit, 21 duplicate-action, 40 graph, 15 desktop and other inventory/engine/contract tests. Existing duplicate-finder and desktop tests remain green.

Final static/platform commands:

```sh
cargo clippy --locked -p vidlib-fileops --all-targets -- -D warnings
cargo fmt --all -- --check
# fresh shell:
source /workspace/.tools/windows-check-env.sh
cargo check --locked -p vidlib-inventory -p vidlib-rename -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu
```

- `/workspace/scratch/task08-clippy-final.log`: passed, Finished dev profile, no warnings. Package-cache lock waiting messages reflect concurrent checks, not failures.
- `/workspace/scratch/task08-fmt-final.log`: passed, no output.
- `/workspace/scratch/task08-windows-final.log`: passed, Finished dev profile, no warnings. This is cross-compilation only; actual Windows native/runtime/power-loss checks remain pending and gates unchanged.
- `git diff --check`: passed; staged check and commit recorded below.

## Self-review and concerns

Reviewed original-versus-inverse receipt retention, no-effect audit/reset, journal write poison/error propagation, native reviewed parent binding, temporary reservation ownership, current-group boundaries, state gates, hierarchy namespace/material proof, durable flush resolution, public/backend-only paths and exact codec quantities. Corrected the namespace-refresh and unconfirmed-durability gaps with named behavioral reds before completion. No dependency-direction changes, recipe reevaluation, imported executable journals, unowned deletion, marker clearing, runtime temporary name generation, native gate changes or unrelated product work were introduced.

Remaining boundaries: later owners must implement copy streaming/creation ownership and planned copy/metadata phase execution/inverses and extend digest algorithms; current safe evidence for already-persisted phases is implemented and tested. Unprovable creation/ownership stays unresolved. Recovery reconstructs full operation/namespace snapshots and performs repeated scans; large-library recovery performance is not qualified here. Actual Windows sharing/handle/timestamp behavior and hardware power-loss durability are unverified. This is an intermediate Rename task, not the complete release. Independent combined review remains required.

## Commit

`2d708f0a46cd94493956ed417e10fd4af65ed53b` — `feat: reconcile interrupted operations and compensate groups`.

All 11 task-owned source/test files are committed. `git diff --check` and `git diff --cached --check` passed before commit. Working tree is clean after commit. No manifest or lockfile changes. This report is retained at the prescribed ignored `.superpowers/sdd/2026-10-17-rename-and-blueprint/task-08-report.md`, matching prior task reports.

## Review fix round 1/5 — interrupted-group authority and finalization

Review source: `/workspace/scratch/task08-review.md`; FIX_BASE `2d708f0a46cd94493956ed417e10fd4af65ed53b`. The Important finding was reproduced: at a durable G1 receipt / before G2 intent boundary, or after G2's proven non-application reset, the last-non-Planned selector chose fully completed G1. Restore then undid G1. This violates the binding completed-group preservation contract. The controller also explicitly approved correcting terminal finalization ordering: namespace epoch durability must precede clearing the pending gate, including Restore with no new filesystem effects when earlier effects exist.

### Interfaces and durable protocol

- Schema v6 adds `recovery_restore(operation_id PRIMARY KEY REFERENCES operations(id), group_id nullable)`. `PendingOperation::restore_context: Option<RestoreContext>` exposes the durable decision as data; `RestoreContext::group_id: Option<GroupId>` distinguishes no decision from an explicit no-group decision. It has no serialization or executable import interface.
- Crate-private `Journal::remember_restore` durably fixes that optional group in a checked transaction before original gap resolution, non-application reset, durability-proof writes, or inverse creation. A different later group is rejected. Normal automatic current-group compensation persists its already-known group through the same transition.
- `interrupted_group` first uses that durable context, then existing v5 inverse lineage, then the first unfinished or durability-unconfirmed group. It never selects a wholly durable prior group by recency. Planned-only groups confer no inverse authority. An entirely completed, confirmed operation without prior Restore context yields an explicit no-group decision.
- v5 databases migrate transactionally without inventing Restore context, rewriting original steps/receipts/events, or inventing an interruption. Existing inverse links remain continuation evidence. Existing v1–v5 SQL strings and checksums are unchanged. v6 has its own checked migration checksum and table-shape check; schema bounds reject unsupported future versions. Existing v5 readers reject user_version 6 rather than silently ignoring the new authority.
- A persisted Restore decision survives final-gap receipt completion, flush audits, resets, and inverse retries. Resume cannot switch direction after that decision; a fresh reviewed Restore can continue. Inverse selection is constrained to the persisted group. Existing fresh identity/material/complete-namespace/parent-handle checks remain required for every inverse.
- `resume`/`restore` now return after their work while the operation remains pending. `recover` durably advances the namespace epoch before terminal Completed/Cancelled. The ordinary executor similarly owns terminal Failed/Cancelled after automatic compensation and after its existing epoch advancement. Its existing pending/Write-lease admission remains unchanged. RecoveryRequired passes through Running only at that finalization seam. The internal compensation helper no longer accepts an unused cancellation flag; caller-owned report state distinguishes Failed/Cancelled.

Files remain within the approved organization: orchestration in `src/recovery.rs`, durable transitions in `src/journal/recovery.rs`, schema/checks in journal modules, and the narrow ordinary executor finalization seam in `src/rename.rs`. No change was needed to evidence helpers or native filesystem code.

### Intended behavioral reds

All commands used the task's command-scoped Cargo/Rustup environment. Tests were added before the correction. Both crash regressions use actual child exits (code 86), real PlatformFs effects/files, and real durable SQLite state. Test-only inspection adapters observe the committed boundary and terminate the child; no production IPC/failure controls were added.

```sh
cargo test --locked -p vidlib-fileops --test recovery restore_after_
```

`/workspace/scratch/task08-review1-boundaries-red.log`:

```text
restore_after_receipt_before_next_intent_preserves_completed_group ... FAILED
restore_after_non_application_reset_crash_preserves_completed_group ... FAILED
fully durable G1 must not be restored from recency
test result: FAILED. 0 passed; 2 failed; 0 ignored; 0 measured; 23 filtered out
```

The first child exits after G1's durable receipt, during G2 parent inspection before its intent. The second original child exits before G2's syscall; a Recovery Resume child proves non-application, commits the NotApplied audit/reset, and exits at the next inspection before re-arming G2. The parent verifies one durable NotApplied audit before reviewed Restore. Both assert G1's original states/receipts and exact event list remain unchanged, `new` retains G1 bytes, G1 source stays absent, `b` retains G2 bytes, `other` remains absent, no inverse is appended, completed_groups contains G1, final gate clears only with namespace epoch advanced.

```sh
cargo test --locked -p vidlib-fileops --test recovery zero_effect_restore
```

`/workspace/scratch/task08-review1-epoch-red.log`:

```text
zero_effect_restore_keeps_gate_if_epoch_finalization_fails ... FAILED
earlier effects remain gated until the epoch advances
test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 24 filtered out
```

This test starts at the actual G1 receipt boundary and rejects the SQLite epoch update with a trigger. It requires pending gate retained, epoch unchanged, original files/states/events preserved, and no inverse effects; after removing the trigger, fresh reviewed Restore finalizes safely. The original implementation cleared the pending gate before its failed epoch advancement. This is a transaction-failure test combined with actual prior process-crash evidence, not a power-loss claim.

### Green and additional boundary/migration coverage

An intermediate focused run `/workspace/scratch/task08-review1-first-green.log` passed 19 journal and 25 recovery tests but failed 5 executor tests (`cancellation_compensates_partial_cycle`, `cancellation_inside_cycle_restores_current_group_before_stopping`, `cycle_compensation_preserves_a_completed_earlier_group`, `failed_cycle_compensates_verified_temporary_and_retains_both_receipts`, `runtime_failure_compensates_only_current_group`) with `invalid operation state transition`. Moving terminal state out of the compensation helper required the executor's RecoveryRequired-to-Running transition after epoch advancement. That was corrected; no existing cancellation assertions or preservation expectations were weakened.

Additional substantive coverage:

- `restore_scope_survives_final_gap_receipt_before_inverse_intent`: an original child exits after the third native cycle effect before its receipt. A Restore child durably records scope and resolves that receipt, then exits before any inverse intent. All original steps are CompletionDurable and there are zero inverse rows. After restart, Resume is rejected without changing the operation record, while Restore completes all three inverses once, restores bytes, and yields exactly six events. This prevents a blanket CompletionDurable exclusion from breaking legitimate Restore.
- `v5_migration_preserves_receipts_without_inventing_restore_scope`: a real interrupted two-group operation is downgraded to the exact v5 table/version shape and reopened. Original record and event list remain equal, v6 migration succeeds, and Restore preserves G1/G2 as above.
- `failed_v5_restore_migration_retains_original_evidence`: a conflicting new table causes v6 migration failure; user_version/checksum count remain 5 and the conflicting evidence, original states, one receipt, and one event remain intact.
- Older v3/v4 migration fixtures now remove the v6 table/checksum when constructing historical schemas; their original evidence assertions remain unchanged. Existing future-schema, checksum rejection, partial-cycle Restore, all inverse-retry boundaries, and Unsupported-flush restoration tests remain green.

Final focused command:

```sh
cargo test --locked -p vidlib-fileops --test recovery --test rename --test journal
```

`/workspace/scratch/task08-review1-focused-green.log`:

```text
test result: ok. 19 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
test result: ok. 28 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
test result: ok. 36 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out
```

83 focused tests passed with no warnings. The 28 recovery functions include the two child entrypoint harnesses; substantive parent tests assert their children terminated at the requested boundaries.

The changed schema and epoch/gate finalization justify the directly adjacent coordinator regression, without rerunning the release-wide suite:

```sh
cargo test --locked -p vidlib-fileops --test coordinator
```

`/workspace/scratch/task08-review1-coordinator.log`: `test result: ok. 13 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out`. Initial Task08's 261-test workspace evidence remains recorded above; it is not represented as rerun for this fix.

### Final checks and self-review

```sh
cargo clippy --locked -p vidlib-fileops --all-targets -- -D warnings
cargo fmt --all -- --check
# fresh shell:
source /workspace/.tools/windows-check-env.sh
cargo check --locked -p vidlib-inventory -p vidlib-rename -p vidlib-fileops --all-targets --target x86_64-pc-windows-gnu
git diff --check
```

- `/workspace/scratch/task08-review1-clippy.log`: passed, `Finished dev profile ... in 4.62s`, no warnings.
- `/workspace/scratch/task08-review1-fmt.log`: passed, empty output.
- `/workspace/scratch/task08-review1-windows.log`: passed, `Finished dev profile ... in 3.44s`, no warnings. Cache/build lock messages come from concurrent checks.
- `git diff --check`: passed, empty output.

Self-review checked scope persistence before evidence-changing transitions, compatible absent context, null versus absent scope, v5 inverse continuation, Unsupported-flush authority, no fallback to completed prior groups, unchanged original facts/events, both explicit/automatic finalization ordering, and the executor's completed-group and ordinary admission contracts. No dependency/manifests/lockfile, canonical checklist, product, or release-wide changes. Parent supplies independent review.

Pending concerns remain explicitly unchanged: actual Windows runtime/sharing/handle/timestamp checks, real removable-device loss/reconnection, and hardware power-loss durability are not established by Linux child exits, SQL triggers, or cross-compilation. Their mutation/release gates remain closed. Later Task19 copy creation/streaming ownership, later metadata execution, desktop IPC, packaging, and release-wide qualification remain with their owners. No additional current changes were made for those Cannot-verify items.

### Round 1 commit

`f5a26f5f76b49d233838c71620776e10e2a8d479` — `fix: retain interrupted group authority during recovery`.

All nine changed source/test files are committed. Both unstaged and staged `git diff --check` passed before commit. `git status --short` is empty after commit. Report remains in the prescribed ignored report location. No push, merge, branch/worktree change, or canonical checklist edit.
