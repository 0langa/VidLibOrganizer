### Task 09: Validated undo and operation history

**Files:** Create `crates/vidlib-fileops/src/undo.rs`, `crates/vidlib-fileops/tests/undo.rs`; extend journal read queries and model DTOs.

**Interfaces:** Produces plan_undo, paged OperationRecord/history DTOs, and explicit history-removal policy. Undo is a new RenamePlan with inverse_of OperationId and the same confirmation/executor path; edit undo/redo comes later in Task 16.

- [ ] **Step 1 — Red:** Add `undo_requires_current_poststate`, `recreated_original_blocks_inverse`, `interrupted_undo_is_recoverable`, `unfinished_history_cannot_be_removed`, and `history_pages_are_stable`.
  ```rust
  assert_eq!(inverse.rows[0].status, RowStatus::Blocked);
  assert_eq!(delete_pending.unwrap_err().code, ErrorCode::RecoveryRequired);
  assert_eq!(page.items.len(), 200);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test undo`.
- [ ] **Step 3 — Implement:** Inverse graph from receipts/expected poststates, full conflict/freshness checks, paged read-only history and explicit deletion of completed undo support. Keep pending recovery and undelivered outbox facts independently protected. Later tasks extend typed inverse variants, not a second undo engine.
- [ ] **Step 4 — Verify green:** Undo/history tests plus existing duplicate actions tests. Confirm an undo failure never overwrites a newly created original or removes unrelated content.
- [ ] **Step 5 — Commit:** `feat: add reviewed inverse plans and operation history`.

