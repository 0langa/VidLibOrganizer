### Task 18: Explicit companion association groups

**Files:** Create `crates/vidlib-rename/src/companions.rs`, `crates/vidlib-rename/tests/companions.rs`; extend recipe/model/graph and UI association DTOs.

**Interfaces:** `associate(inventory: &Inventory, selection: &[EntryId], policy: &CompanionPolicy) -> Result<AssociationSet, RenameError>` and `propagate_names(evaluated, associations)`. One asset has at most one primary; associations enter GroupIds before graph validation and cannot silently extend selection.

- [ ] **Step 1 — Red:** Add `language_and_role_suffixes_preserved`, `idx_sub_pair_is_one_dependency_group`, `two_possible_owners_require_choice`, `folder_artwork_not_assigned_automatically`, `cross_folder_requires_explicit_pair`, and `primary_only_warns_without_mutating_asset`.
  ```rust
  assert_eq!(subtitle_target, "Harbor Watch - S02E02 [1080p].en.forced.srt");
  assert_eq!(idx.group_id, sub.group_id);
  assert!(ambiguous.owner.is_none());
  assert!(!plan.selected_ids.contains(&shared_poster_id));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test companions`.
- [ ] **Step 3 — Implement:** Exact original-stem matching with explicit supported extension list from the spec; recognize retained ISO language/role suffixes without guessing a shared poster/tvshow file's owner. Manual cross-folder owner binding stays within selected grants. Derive all companions from the primary's **same** frozen name/counter, then rerun global collisions and group validation.
- [ ] **Step 4 — Verify green:** Association tests and executor fault injection failing after the first companion step; assert compensation/recovery names every affected asset and never drops unrelated files.
- [ ] **Step 5 — Commit:** `feat: preserve explicit video companion associations`.

