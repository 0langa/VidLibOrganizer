### Spec Compliance

- ❌ Issues found. Task 16 implements the requested preset/editor surface, but optimistic revision protection is not effective across app instances, and unrelated editor actions silently discard unfinished parameter drafts (Important findings 1–2).
- Review scope: frozen `9b41f2d..4d0cb80` package (101,263 bytes), read in consecutive segments once, after the task contract, official reviewer template, brief and report. No regenerated diff, suite reruns, helpers, or product mutations.
- ⚠️ Cannot verify from diff: native Windows atomic replacement/write-through, actual power-loss durability, WebView2 behavior and NTFS/exFAT/removable/network qualification remain pending; platform-specific implementation is at `src-tauri/src/rename_preferences.rs:139` and directory synchronization at `src-tauri/src/rename_preferences.rs:63`. The reported Windows GNU all-target compile is compile evidence at its stated revision, not runtime evidence.
- ⚠️ Cannot verify from diff: broad release guarantees owned by unchanged executor/journal/probe/Blueprint code remain outside this task. Full-document preview enters the existing pipeline at `src-tauri/src/commands/rename.rs:496`; this review does not establish finished Rename or Blueprint release compliance.
- ⚠️ Cannot verify from diff: reported test execution and raw logs were not independently rerun. Preserve the evidence distinction: 431 distinct tests in the workspace run, one subsequently added focused wire test (`src-tauri/tests/command_contracts.rs:1531`), and the final localized persistence rerun covering response preparation before publication (`src-tauri/src/rename_preferences.rs:244`). These are not a second full-workspace run.

### Strengths

- `crates/vidlib-rename/src/presets.rs:84` centralizes import/export through the strict RecipeV1 codec and maps both recipe size and rule count failures to ImportLimit. Immutable snapshots and exact decimal revisions remain separate from recipe revision; boundary tests include 1 MiB/+1, 100/101 rules and values above JavaScript's exact integer range (`crates/vidlib-rename/tests/presets.rs:29`, `crates/vidlib-rename/tests/presets.rs:76`).
- `src-tauri/src/rename_preferences.rs:113` writes and flushes exclusive temporary files, publishes immutable archives before the current record, and classifies a failed postpublication directory flush as `presetCommitUncertain` (`:172`). Fallible DTO preparation precedes publication (`:244`). The controller's ruling is reflected in separate real-file precommit and postcommit tests (`:401`, `:487`, `:601`); the ruling does not resolve the concurrency defect below.
- `src-tauri/tests/command_contracts.rs:1531` and the shared literal fixture test the explicit camelCase envelope/opaque portable document boundary. `src-tauri/tests/command_contracts.rs:1365` exercises actual ordered backend evaluation from a saved recipe and subsequent confirmation revocation, rather than only inspecting a mocked request.
- `ui/recipe/history.js:3` separates bounded, detached recipe edit history from filesystem Undo. Rule repeat/reorder/disable preserve ordered data, and listeners are aborted on render/destruction (`ui/recipe/editor.js:22`, `:37`, `:47`).

### Issues

#### Critical (Must Fix)

None.

#### Important (Should Fix)

1. **Concurrent instances can both pass expectedRevision and replace a newer active record with an older one.** `src-tauri/src/rename_preferences.rs:185` holds only `AppState.rename_preferences_lock`; each `AppState::open` creates its own mutex (`src-tauri/src/app_state.rs:45`). The current revision is checked once before archive allocation (`rename_preferences.rs:193`), and publication replaces the current record unconditionally (`:246`). Concrete interleaving: A and B both read current revision 1 with expectedRevision 1; A publishes archive 2 and pauses; B sees that differing archive, treats it as an orphan (`:217`), allocates archive 3 and publishes current 3; A then publishes current 2 and both saves return success. This loses B's active update, regresses current revision, and defeats the expected-revision contract. Even publication in the opposite order silently accepts a stale save. Immutable no-clobber archives do not serialize current publication. Hold a process-shared preset lock across the current read, expected-revision check, archive allocation and current publication (including recovery of apparent orphans). Add a deterministic two-instance interleaving test proving a stale writer cannot publish or regress the current record. A late unlocked recheck alone would still race.

2. **An unrelated structural edit silently discards an invalid draft and re-enables extraction of its previous valid parameters.** `ui/recipe/editor.js:22` unconditionally clears `invalidDrafts` and rebuilds all controls from the last valid history snapshot. `ui/recipe/fields.js:38` keeps invalid textarea text only in the DOM. After entering `{broken` in an advanced rule, `getRecipe()` correctly throws; clicking Add rule (`editor.js:27`), moving any rule (`:39`), or changing another rule's type triggers render, deletes the unfinished text, clears its blocking status and allows save/preview using the old parameters. That contradicts the intended protection against silently using a previous valid recipe and loses pending user edits without an explicit discard. Preserve draft text and validation state by stable rule ID through unrelated renders, or block those actions until the user resolves or explicitly discards the draft. Extend `tests/ui/recipe-editor.spec.mjs:98` with an invalid draft followed by Add/reorder and assert the draft and extraction block remain.

#### Minor (Nice to Have)

None.

### Focused Checks

- Named cross-interface risk: concurrent app lifetime versus preset locking. Inspected `crates/vidlib-fileops/src/coordinator.rs:53` through `:83`: startup's advisory lock is released before `open` returns; it does not serialize preset saves or enforce a single app instance. Checked registration/startup for a single-instance lock and found none. No concurrent stress or confirmatory suite run was needed to establish the explicit interleaving above.
- Named cross-interface risk: edits must revoke plans/nonces. The diff cut off `ui/rename/main.js` at `invalidate`; read only the missing lifecycle continuation (`:123`–`:174`). `edited` advances revision, clears UI plan state and queues `update_rename_inputs`. Focused inspection of `src-tauri/src/commands/rename.rs:325`–`:340` confirms advancing revision invalidates the backend registry and clears reviews. This supports normal edit revocation; it does not repair draft loss.
- Targeted line locators were used for report references; no complete changed file was reread and no existing verification suite was rerun.

### Assessment

**Task quality:** Needs fixes.

**Counts:** Critical 0; Important 2; Minor 0.

**Reasoning:** The data boundary, single-instance persistence path and ordered preview integration are well supported by concrete tests. Cross-instance publication and draft preservation remain correctness gaps that the current happy-path and fault tests do not cover.
