# Task 03 report — deterministic recipes and plan models

Status: implemented, verified, ready for controller review.
Base: `b91a3e4e356ed2cebebe796474d1a3c92ab5624e`.
Commit: `07f9a50` — `feat: define deterministic rename recipes and plans`.
The report is in the repository-ignored `.superpowers` task-evidence directory; implementation/Cargo changes are committed.

## Public interfaces

New pure crate `vidlib-rename` depends on `vidlib-inventory`, `serde`, and `serde_json`; tests use `tempfile`. No fileops dependency, filesystem access, clock reads, RNG calls, probes or hashing occur in production evaluation.

- `RecipeV1 { schema_version, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`, `from_json(&[u8])`, `validate()`.
- `Rule { id, enabled, segment, parameters }`; strictly tagged `RuleParameters::{Keep, FixedStem, Template}`. Keep and FixedStem on Stem are the only active implementations. Template AST import/validation is supported, but an enabled Template returns `UnsupportedRule` before rows. Future rule tags remain rejected until their owning rule tasks add implementations. No future UI controls were added.
- `SegmentSelector::{Stem, Extension, WholeName, Graphemes, Delimited}` and `NameSegment`. Grapheme positions are signed/inclusive one-based data: zero/out-of-range is reserved for a future row issue, not rejected as a recipe error. Active non-Stem segments currently return `UnsupportedRule`.
- Typed `TemplatePart::{Literal, Field { key, format, fallback }, Optional}`, `FieldKey` covering original/current stem, extension, parent level, relative directory, counter, dates, size, canonical media fields, hashes, UUID/random; `ValueFormat` and numeric `Radix` enums. Field-format combinations, nonpositive parent levels, nesting, padding and decimal scale are validated. Date format subset is documented in source: `%Y %m %d %H %M %S %f %z %:z %%`.
- Data-only companions/associations, destination by grant ID/layout, collision policy, timestamp/attribute metadata changes. Invalid ownership/format/conflict combinations are rejected. Configurations requiring later behavior return `UnsupportedConfiguration` before rows.
- `FrozenInputs { inventory_id, generation, now_ns, timezone, primary_order, values }`; per-entry/rule `FrozenValue`, typed values and explicit `MissingDecision::{Block, OmitOptional, Fallback}`. Recorded timestamp timezone can remain `None`. UTC, supplied confirmed IANA name, and fixed offsets are represented. Evaluation checks generation, primary vector, selected IDs, rule IDs, duplicate values, value types and timezone syntax/range; it never regenerates frozen values.
- `evaluate(&Inventory, &RecipeV1, &FrozenInputs) -> Result<EvaluatedBatch, RenameError>`. Native root/grant membership and exact relative-to-absolute binding are validated, including individually granted files. Entries are indexed by EntryId. Rules run against current stem in order; original extension is preserved. Group IDs derive deterministically from primary EntryIds. Unsupported observed entries remain blocked rows with their original native paths. This is candidate evaluation; namespace/graph safety is still Task06.
- Backend-only `PlanRow`, `EvaluatedBatch`, `RenamePlan`, `ExecutionPlan`, `ExecutionGroup`, `ExecutionStep`, `InspectionProvenance`, `ExecutionAction`. These have no Serialize/Deserialize derives. Execution provenance owns the approved PlanRef, inventory and recipe snapshots, frozen values, grants, and namespace/policy epochs. Steps carry exact native paths, expected source stamp, action and group/entry/step IDs; ordered groups carry dependencies. The later planner builds these data.
- `PlanRef { session_id, plan_id, revision }`; explicit `PlanRowDto`, `EvaluatedBatchDto`, `RenamePlanDto` and `to_dto()` methods. UI DTOs omit native path fields, grants, frozen backend inputs and execution authority. Display paths are presentation only. Size and timestamp fields use decimal strings; revision/generation/count fields use inventory's canonical decimal serde adapters; UUID IDs remain strings. Enum JSON tags/codes use snake_case.
- `PlanCounts::from_rows` uses checked addition.
- Pure in-memory `PlanStore::new(session_id)`, `publish`, `current`, `confirm`, `consume_confirmation`, `invalidate`. Plans are owned and exposed only through shared references. Publish requires the store session, monotonically increasing supplied revision and consistent provenance/counts. Publish/invalidate revoke confirmation; each supplied backend nonce can be used once in the session. Invalidated refs cannot be republished. Task10 supplies process session IDs, fresh backend nonces, and invalidation calls on inventory/recipe/selection changes.
- Stable typed `RenameError { code, message }` / `RenameErrorCode`. Callers use codes rather than error message text.

## TDD evidence

Read `/workspace/scratch/superpowers-source/skills/test-driven-development/SKILL.md` and `writing-good-tests.md` before implementation. Tests were written against real inventory scans and real evaluation; no mocks. Each test's comment names the break it catches.

All Rust commands below used this command-scoped environment:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

Initial red command:

```sh
cargo test -p vidlib-rename --test contracts
```

Compilation succeeded against data definitions and deliberately nonfunctional method stubs. Output: `FAILED. 0 passed; 10 failed`, exit 101. Named failures:

- `unknown_recipe_version_or_rule_rejected`: stub returned InvalidRecipe instead of UnknownRecipeVersion.
- `preview_freezes_clock_and_random`: evaluator returned UnsupportedRule/not implemented.
- `unselected_or_outside_grant_id_rejected`: evaluator returned UnsupportedRule instead of UnselectedEntry.
- `json_preserves_large_sizes`: evaluator returned UnsupportedRule/not implemented.
- `explanations_follow_rule_order`: evaluator returned UnsupportedRule/not implemented.
- `recipe_schema_round_trip_and_validation`: importer returned InvalidRecipe/not implemented.
- `frozen_inventory_and_numbering_order_must_match`: evaluator returned UnsupportedRule instead of StaleInputs.
- `bounded_recipe_import_and_unimplemented_rules_fail_closed`: importer returned InvalidRecipe instead of RecipeTooLarge.
- `invalid_fixed_stem_or_segment_rejected_before_evaluation`: evaluator returned UnsupportedRule instead of InvalidRecipe.
- `template_types_and_frozen_values_round_trip`: importer returned InvalidRecipe/not implemented.

Further named red/green cycles:

- After adding store/DTO/frozen-validation tests, the stub run reported 1 passed/14 failed. `invalid_segments_templates_and_associations_rejected` initially passed because the validate stub rejected everything; its positive valid-position assertion was subsequently added and observed failing before the corresponding correction (see below).
- After implementing recipe/evaluation behavior, the same command produced `12 passed; 3 failed`: `plan_dto_is_stable_exact_and_contains_no_execution_authority` saw changed count 0 instead of 1; `plan_store_rejects_foreign_session_and_snapshot_mismatch` saw a foreign plan wrongly accepted; `plan_store_revokes_refs_and_confirmation_nonces` reached the missing confirmation consumer. Implemented store and projection/count behavior after those failures.
- `direct_recipe_deserialization_rejects_unknown_version` failed because direct serde accepted schema 99; `frozen_field_types_are_checked_before_rows` failed because Text("not a size") was accepted as SizeBytes. The full run was 12 passed/5 failed before implementing these guards.
- `cargo test -p vidlib-rename --test contracts individual_file_grant_is_supported` failed with OutsideGrant for the real individually selected file. Fixed native relative-path base handling without granting neighboring sources.
- `cargo test -p vidlib-rename --test contracts invalid_segments_templates_and_associations_rejected` failed at the positive assertion that grapheme zero remains valid recipe data. Corrected validation to defer zero/out-of-range to future row evaluation, as section 4.2 requires. Active segment evaluation remains unsupported and fails before rows.

Green contracts: `cargo test -p vidlib-rename --test contracts` reported `18 passed; 0 failed`. Final workspace run repeated all 18 after indexing/formatting changes.

All final contract names:

1. unknown_recipe_version_or_rule_rejected
2. preview_freezes_clock_and_random
3. unselected_or_outside_grant_id_rejected
4. json_preserves_large_sizes
5. explanations_follow_rule_order
6. recipe_schema_round_trip_and_validation
7. frozen_inventory_and_numbering_order_must_match
8. bounded_recipe_import_and_unimplemented_rules_fail_closed
9. invalid_fixed_stem_or_segment_rejected_before_evaluation
10. template_types_and_frozen_values_round_trip
11. plan_store_revokes_refs_and_confirmation_nonces
12. plan_store_rejects_foreign_session_and_snapshot_mismatch
13. plan_dto_is_stable_exact_and_contains_no_execution_authority
14. invalid_segments_templates_and_associations_rejected
15. duplicate_frozen_values_and_invalid_timezone_rejected
16. direct_recipe_deserialization_rejects_unknown_version
17. frozen_field_types_are_checked_before_rows
18. individual_file_grant_is_supported

## Final verification

- `cargo test --workspace --exclude vidlib-tauri`: exit 0; 106 tests passed: engine scan 14; fileops unit 8, actions 21, platform 18; inventory 22, path codec 5; rename contracts 18. All crate doc-tests passed. The Windows runtime-only test binary has 0 tests on Linux.
- `cargo clippy -p vidlib-rename --all-targets -- -D warnings`: exit 0, no warnings (`Finished dev profile ... 6.51s`).
- Initial `cargo fmt --all -- --check` found only new crate formatting differences (exit 1); `cargo fmt -p vidlib-rename` applied formatting. Final `cargo fmt --all -- --check`: exit 0.
- `source /workspace/.tools/windows-check-env.sh` followed by `cargo check -p vidlib-rename --all-targets --target x86_64-pc-windows-gnu`: exit 0 (`Finished dev profile ... 3.03s`). Compile evidence only, no Windows runtime claim.
- `git diff --check`: exit 0.
- `cargo tree -p vidlib-rename --depth 1`: only serde, serde_json, vidlib-inventory and dev tempfile. No fileops dependency.

No desktop test run was attempted: controller identified the existing missing `icon.png` desktop baseline as Task05-owned. No canonical plan edits, helpers, reviewers or subagents were used.

## Concerns and remaining ownership

- This task is the model/initial evaluation slice, not the completed Rename release. Active Template and all future rule tags remain unavailable as described above. Later tasks implement rule semantics and graph/namespace planning; there is deliberately no placeholder public `plan()` that implies a validated graph exists.
- IANA timezone confirmation/database resolution belongs to frozen-input preparation; this pure crate validates only supplied name syntax. Unknown recording timezone stays absent. No local timezone is inferred.
- Grants and snapshots are trusted backend observations. Filesystem freshness, root protection, namespace collisions, graph construction, staging, journaling and mutation are later task responsibilities. PlanStore is process-local data and does not execute or persist plans.
- Desktop baseline and Windows runtime remain pending with their existing owners; Linux workspace tests and Windows cross-compilation are green.
