# Task review contract

Read /workspace/scratch/superpowers-source/skills/subagent-driven-development/task-reviewer-prompt.md and follow its task-scoped read-only review contract. Do not dispatch subagents. Review requirements first, then code quality. Read the full diff package once; no re-deriving git diff and no re-reading entire changed files unless a concrete cut-off hunk requires it. No suite reruns merely to confirm reported results. Specific focused checks may investigate concrete doubts.

Use the supplied task brief, report and review package paths as the only starting inputs. Other files may be checked only for a concrete named cross-interface risk. Treat implementer claims as unverified; assess the diff independently. Report missing/extra/misunderstood requirements, Critical/Important/Minor with file:line evidence and concrete impact. Report Cannot-verify-from-diff items for controller resolution instead of roaming. Do not pre-judge plan requirements or platform outcomes.

Write the complete review at the supplied /workspace/scratch review-report path (this is the only permitted write); checkout/index/HEAD/branch remain read-only. Return the spec compliance verdict, task quality verdict, actionable findings with file:line, and report path. Keep successful checks concise. State real Windows runtime checks as pending if report only provides compile/portable evidence.

## Binding global constraints verbatim


The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.

