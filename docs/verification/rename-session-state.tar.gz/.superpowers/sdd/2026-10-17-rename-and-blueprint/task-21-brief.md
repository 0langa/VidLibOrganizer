# Task 21: Complete the Rename controls and user journeys


**Files:** Create `ui/rename/rules.js`, `ui/rename/selection.js`, `ui/rename/associations.js`, `ui/rename/destinations.js`, `ui/rename/metadata.js`, `tests/ui/rename-rules.spec.mjs`, `tests/ui/rename-workflows.spec.mjs`; extend the common recipe editor, preview/history and desktop request validation.

**Interfaces:** R01–R17 use only the implemented RecipeV1/typed command DTOs. All controls share createRecipeEditor and start_rename_preview; a single state reducer tracks inventory/recipe/plan revisions and current job. UI grouping does not create alternate filename behavior.

- [ ] **Step 1 — Red:** Browser golden scenarios cover every R01–R17 control family, per-rule explanations, manual numbering order, search/200-row paging/highlighted differences, imports/paste/export/presets/edit undo, companion choice, folder/destination/metadata summaries, recovery and filesystem undo. Add `older_job_finishes_after_newer_recipe` and malicious filename/metadata text fixtures.
  ```js
  expect(bridge.lastAppliedPlanRef).toEqual(latestReviewedPlanRef);
  await expect(page.locator('#rename-results script')).toHaveCount(0);
  await expect(page.getByTestId('rename-row')).toHaveCount(200);
  ```
- [ ] **Step 2 — Verify red:** `npx playwright test tests/ui/rename-rules.spec.mjs tests/ui/rename-workflows.spec.mjs`.
- [ ] **Step 3 — Implement:** Complete the actual controls and accessible labels for the full matrix; lazy advanced panels for metadata/regex, explicit missing-field actions, fixed revision acceptance, abortable watchers and focus restoration. Display-only sorts cannot edit numbering. Review summaries include non-displayed selection rows and carried descendants. Use JSDoc data interfaces and text nodes; no placeholders or disabled unfinished options count as implemented scope.
- [ ] **Step 4 — Verify green:** Browser journeys at normal/narrow viewport, keyboard-only use, screen-reader live status, zero app console errors, and current finder/libraries regressions. Syntax-check all modules and verify the packaged browser sample cannot call file actions.
- [ ] **Step 5 — Commit:** `feat: complete bulk rename editing and review workflows`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.1 Native paths, IDs, observations

Task 01 owns opaque UUID newtypes in `vidlib_inventory::ids`: `InventoryId`, `RootId`, `EntryId`, `GrantId`, `SessionId`, `JobId`, `PlanId`, `GroupId`, `StepId`, `OperationId`, `EventId`, `PresetId`, `CollectionId`, `AttemptId`, `AttachmentId`. IDs are not permissions. Revisions are Rust `u64`; schema versions are small `u32`.

`NativePathRecord { platform: WindowsUtf16Le | UnixBytes, bytes: Vec<u8> }` round-trips exact OS strings. Persist path keys as bytes, with a separate display string; only root-relative validated records enter portable inventories. Never use display strings or physical file IDs as unique path keys. Unsupported/unroundtrippable rename names remain visible issues. All new JSON u64/i128 counts/times/revisions are validated decimal strings; UUIDs are strings. SQLite stores exact quantities as decimal text, with fixed-width big-endian numeric sort keys where numeric indexing is required. Do not cast them to SQLite REAL or JS Number.

`FileStamp` contains optional physical identity, size for regular files, native-precision created/modified/accessed epoch-nanoseconds (`Option<i128>`), and Windows attribute bits. `PhysicalId` includes platform, volume identity, and file identity. `EntrySnapshot` contains EntryId, RootId, exact relative path, Rust-owned absolute PathBuf, display_name/display_path, kind, FileStamp, observation time, and issue state. File hard-link aliases remain separate entries. `RootBinding` contains RootId, backend-owned source grant, PathBuf, evidence, and capability facts; a binding records evidence absence separately from mismatch.

`Inventory { id, generation, roots, entries, coverage, window, issues }` is immutable. `ScopeCoverage` records exact directory, **listed child names even if stat fails**, `children_complete`, `subtree_complete`, outcome, filter fingerprint, observation interval, and issues. `JobControl` owns cancellation (`Arc<AtomicBool>`) and a bounded progress sink; `Progress { phase, done, total, current_entry }` is throttled to 10/s.

Public inventory interface: `scan(request: &InventoryRequest, control: &JobControl) -> Result<Inventory, InventoryError>`. Request grants come from backend native selection/validated manual paths; inventory sources can be roots or explicit files. Child traversal never follows a link/reparse point.

Task 01 also defines read-only `DirectoryFacts` and `NamespaceSnapshot` in inventory/model.rs: exact observed parent paths/entries, per-parent case/name/length facts, filesystem capabilities, source grants, protected-root/marker policy, persisted namespace/policy epoch and capture interval. `PlatformFs::capture_namespace(grants: &GrantSet, candidates: &[PathBuf])` in Task 02 populates these data types. Their definition never imports Rename/fileops. A test adapter can supply this same data to the pure planner.


### 4.4 Tauri/JavaScript and Blueprint contracts

Task 10 exposes owned command request structs and `Result<_, CommandError { code, message, phase, item_id, operation_id, retryable }>`; serialize using camelCase consistently. Commands clone Arc-managed handles under short locks, release guards, then start blocking workers. Job types carry owned results; query responses page at 200 rows. Never keep a std MutexGuard or rusqlite Connection borrow across await.

Core commands: `select_sources(PickerKind) -> SelectionDto`, `start_inventory(InventoryRequestDto) -> JobId`, `start_rename_preview(RenameRequestDto) -> JobId`, `job_status(JobId) -> JobStatusDto`, `cancel_job(JobId)`, `rename_page(PlanRef, PageQuery) -> Page<PlanRowDto>`, `confirm_rename(PlanRef) -> ConfirmationDto`, `apply_rename(PlanRef, confirmation_nonce) -> JobId`, `operation_history(PageQuery) -> Page<OperationDto>`, `recovery_preview(OperationId)`, `start_recovery(RecoveryRef, choice, nonce)`, `start_undo(OperationId) -> JobId`. Nonces bind the current session/revision/summary and are revoked on edits. Queries do not reauthorize native paths.

All **new** commands use one owned argument named `request` (wrap multi-field cases in the corresponding request DTO) plus managed state; JS invokes them with `{ request: dto }`. Existing commands retain their prior argument shape. Task 10 adds `src-tauri/tests/command_contracts.rs` and `tests/ui/fixtures/command-contracts.json` to verify camelCase/tag/decimal-string serialization against the same golden payloads used by browser mocks. PageQuery contains cursor, limit capped at 200, display sort/filter, and expected data revision; it never changes recipe numbering order.

Common JS interfaces: `watchJob(jobId, {signal, onProgress}) -> Promise<JobResult>` cleans up timers on finish/navigation/error; `createRecipeEditor({recipe, onChange}) -> {getRecipe(), setRecipe(recipe), destroy()}` never computes filenames; `formatExactBytes(decimalString)` uses BigInt and string-safe formatting. `call()` in `ui/api.js` remains compatible with existing commands while new errors are formatted centrally.

Blueprint Task 24 owns `BlueprintStore::open(path: &Path) -> Result<Self, BlueprintError>`, collection/RootBinding revision records, and paged queries. Task 25 owns `recognize(evidence: &RecognitionInput) -> RecognitionDecision` (`Known`, `CandidateNeedsConfirmation`, `IdentityConflict`, `MarkerOnlyNoLocalData`, `Unknown`), `register`, and `rebind` with expected binding revision. Task 26 owns `begin_refresh(collection_id, request) -> AttemptId`, `stage_inventory(attempt, inventory)`, and `promote_refresh(attempt) -> RefreshReport`; promotion commits baseline scopes and observed events together.

Task 27 owns `project_events(events: &[OperationEventV1]) -> ProjectionReceipt` with EventId uniqueness and transactional cursor updates. Task 28 owns `attach_template(collection, scope, preset_id, revision, recipe_snapshot) -> AttachmentId` and `summarize_patterns(selection, baseline_revision) -> PatternSummary`. Task 30 owns `export_bundle`, `validate_import`, `import_inactive`, `prune_history`, and `remove_collection`; none grants filesystem access or accepts executable journals.

Blueprint queries return `Page<MapEntryDto>`, `CollectionSummaryDto`, `Page<ChangeDto>` with observation interval/origin/confidence and separate last-attempt/last-complete times. Its commands mirror the store operations through owned DTOs, not SQL rows. Sending cached items to Rename resolves an explicit fresh native selection and scans again; stale EntryIds are never reused.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.



## Task11 selector and text-schema handoff
Read task-11-report.md for typed TextOperation/RuleParameters::Text, explicit extension/WholeName and full case/exception/Roman behavior. Existing Delimited selects afterNth opening literal through next same delimiter/end, optional opening inclusion. New Between selects the Nth flat opening/closing literal pair with optional inclusion, implementing approved second-bracketed-segment editing. Expose these as typed data in the shared editor when this task owns those controls; do not recreate transformations in JS, silently change selector semantics, or lose configured inactive rules. Original/current fields and current-input segment resolution remain backend-owned. Dotted-I title spelling is a deferred final-triage minor, not permission to normalize names.


## Explicit numbering-scope and template Counter carry
Approved renaming spec section4: "Counter assignment uses the frozen selected primary-item vector; companions inherit their primary's result and do not consume counters. Directory numbering is a separate explicitly selected scope." Preserve this in your owned selection/association/UI/acceptance work: no implicit flattening of file/directory or companion scopes or display sorting into counter order. Task13 assign_numbers is an explicit-vector primitive with original-parent reset; use a narrow typed scope integration if needed and test mixed files/directories plus companions. Task14 unparameterized FieldKey::Counter defaults to1-based ordinal within the explicit frozen primary scope and retains explicit per-entry/per-rule frozen IntegerCounter. It does not implicitly bind to one of several configured Number rules. Report actual end-to-end scope evidence instead of claiming the intermediate primitives finish the UI workflow.


## Controller mixed-kind numbering scope ruling
Task15 mixed-kind numbering uses a narrow RecipeV1 NumberingScope::Files (serde default) or explicitly selected Directories with one frozen primary vector for the chosen kind. Number rules consume ordinals/apply only within that scope; other-kind selected rows retain their current name through that Number rule and may use other rules. Do not globally reject mixed file/directory selection, because combined parent/child preview is required. Required template Counter outside the active primary scope produces a clear missing/scope row issue unless the AST explicitly supplies fallback/optional behavior. Generic assign_numbers remains an explicit-vector primitive; Task18 removes companions from primary vectors before freezing. Reason: approved spec separates directory numbering while requiring one consistent file/parent final-path preview, and existing RecipeV1 has one numbering order. Cost if wrong: users expecting independently configured simultaneous file and directory counters in one recipe need an explicit multi-scope rule/binding extension and revised previews; schema default may require import migration. No native authority or scope is granted. Test both explicit scopes with mixed selected kinds, out-of-scope Counter, recomputation/collisions and later companions.

Cancellation acceptance carry: approved spec says "Compile once per rule and check cancellation between items." Verify actual desktop CPU-side selection/ordered evaluation, not only hash/helper I/O, honors cancellation between rows while retaining once-per-enabled-rule preparation. Legacy pure wrappers may stay compatible; add a narrow controlled/prepared evaluation entry point if needed, without a second engine or per-row recompilation. Report actual cancellation evidence; an after-whole-batch check does not establish this requirement.


## Task18 opt-in companion policy carry
Controller Ruling8: additive MatchExact{associations} explicitly enables same-original-stem/language-role matching plus manual overrides, while existing Explicit remains manual-only and None disables propagation. None keeps deliberately selected rows independent; only-video selection warns and leaves unselected related assets untouched. MatchExact ambiguity leaves a possible asset unchanged with a warning until manual choice; no hidden selection extension or grants. UI must offer the actual policy choice and selected ownership decisions, not silently change old recipes. Ownership resolves before frozen primary scope/counters/metadata, and all selected rows participate in global preflight/group validation. Read final Task18 report for actual reviewed signatures/DTOs and fault evidence.


## Task19 compatibility/protocol carry
Controller Rulings9/10 authorize explicit CreateStaging/WriteStaging actions with durable created native identity before bulk streaming, separate intent/verified digest, compiled quarantine for safe removal and immutable legacy StageCopy inspection. New explicit CopyTo/MoveTo and typed PreserveHierarchy/FolderTemplate layouts retain existing SameDirectory in-place behavior. Legacy unsupported Granted data stays readable but requires explicit Copy/Move choice and a new preview; no implicit destructive migration. Actual destination authority comes from current backend grants. Read final reviewed Task19 report for actual signatures, phase crash/recovery/Undo evidence and pending Windows qualification. UI and verification must present/reproduce these real typed modes and phases.


## Task19 inverse-lineage carry
Controller Ruling11 permits a checked ordered one-to-many recovery-effect lineage (or equivalent durable compiled inverse plan) where a forward step requires multiple copy-back/owned-cleanup effects. Old rows/meaning and immutable original facts survive migration. Each inverse has durable intent/receipt and fresh identity/full digest; all required effects must finish before its forward step/group is compensated. Interrupted chains retain pinned Restore scope/recovery ownership and epoch ordering; restored cross-volume objects have newly recorded actual identities. Read final reviewed Task19 report/signatures; do not restore the old one-to-one assumption or treat incomplete chains as compensated.


## Approved Copy/Move Undo disclosure and directory ownership
Renaming spec section8: "Cross-volume undo may require copying back and sufficient space. Undo of Copy removes only a created copy whose identity and full digest still match its completion record; that deletion is explicitly disclosed. Created directories are removed only if still empty and owned by that operation." Keep actual receipt identity/full SHA256 authority, current-source/path conflicts and original metadata intent. Supply backend plan/summary facts needed for the review/Undo confirmation to disclose removal of created copies and ownership-qualified empty directories; Task21 owns the complete visual confirmation flow. A completed copy followed by failed source removal remains a published-copy fact, never a fictional completed move or omitted history event.

Task19 Ruling12 adds explicit source-directory removal with matching owned destination directory receipt, complete descendant effects, fresh source identity/emptiness and compiled deepest-first quarantine. Original dir metadata freezes before child effects; only owned destination dirs get preservation metadata. Actual folder Restore/Undo/new identities and unknown/nonempty refusals belong19; read its final reviewed report, preserve this protocol in metadata/UI/verification work.


## Task20 timestamp increment ruling

Ruling: Task20 retains existing MetadataChange::Timestamp as exact Set and adds explicit Offset (frozen original field plus offset_ns) and Increment (explicit start_ns plus frozen ordinal times step_ns), all checked without implicit original-time addition or clock regeneration. Metadata Increment uses the full frozen primary_order across selected primary kinds, independent of Number/Counter numbering_scope; resolved selected companions inherit their primary ordinal and consume none. Missing original Offset base or unresolved Increment owner/ordinal blocks the affected row with a typed issue, never an invented value or unselected mutation. Reason: separate visible intents make timestamp semantics deterministic while preserving existing frozen selection/order and companion ownership contracts. Cost if wrong: users wanting original+offset+ordinal or independently staggered companions need another explicit mode; mixed-kind scoping requires selection filtering, and additive variants require compatible readers. Native support/precision, original per-field authority and expected-poststate recovery checks remain mandatory; no Windows qualification is inferred.


## Task20 durable metadata-prestate carry (Ruling16)

Ruling: Task20 adds a checked, separately persisted resolved metadata-prestate relation rather than a new capture action. Capture factual before-state outside SQL under existing native identity/grant/named-effect/namespace proof; bind it immutably to the exact operation/SetMetadata step and persist it atomically with that step's durable intent BEFORE the native setter. Reverify the same actual object/expected fields immediately at native effect. Every new SetMetadata path, including Task19 preservation and inverse/recovery metadata, must use this protocol. Probe/Resume/Restore/receipts use the captured before-state; never refresh it from an already changed object or reinterpret compiled original intent as a factual before-state. Duplicate/reopen writes preserve the first exact binding. Keep complete DAG/parent/epoch rules and no filesystem I/O inside SQL. Checked migration preserves old receipts/events/meaning and rolls back on failure. Legacy before-state may be derived only from exact existing durable evidence (e.g. static Observed/receipt proof); an old dynamic directory gap with no provable before-state remains explicitly unresolved rather than invented. Reason: child effects make live directory material dynamic; after a SetMetadata receipt gap the current requested value cannot truthfully supply its own original value. Cost if wrong: extra journal protocol/migration/durability work and crash tests; older builds reject the new schema, and unprovable legacy dynamic gaps may need review. Actual crashes around prestate+intent/native effect/receipt and migration retention/rollback are required. Compatibility limits and unavailable native Windows checks remain explicit; no Windows gate opens.

Read the final reviewed Task20 report for implemented signatures and actual evidence. UI and verification must retain truthful unresolved legacy gaps and field-specific original/requested/expected poststates.


## Relevant deferred review pointers

Read deferred-minors.md for Task10 Minor04 (inventory kind DTO casing), Minor05 (api.js/dom.js ownership reconciliation), Minor06 (compressed UI orchestration) and Task18 Minor12 (warning classified by arbitrary Rule.id). They remain deferred final-branch findings unless naturally addressed in this full-control task. Record any actual fix and covering evidence; do not silently claim resolved or expand unrelated work just to touch listed files.


## Task20 directory restoration target carry (Ruling17)

Ruling: Task20 distinguishes the frozen pre-operation original metadata used as the approved restoration target from the factual native pre-Set state durably captured under Ruling16. Directory Undo/Restore finalization restores only the fields explicitly changed by the original operation to those frozen original values, after its named child inverse effects, using the actual current directory identity and full DirectoryAfterEffects grant/namespace/dependency proof. Keep factual pre-Set and observed poststate as immutable receipt evidence; never rewrite them to look like the frozen originals. Automatic Task19 preservation keeps its explicit original-field intent. Do not restore unrelated fields, bless unknown child/external changes, fabricate identities, or reinterpret legacy receipts. Reason: the operation's own child path mutations change directory mtime between preview and setter, so restoring that intermediate value would not restore the approved original state after paths recover. Cost if wrong: restoring a preview-original field may differ from an intermediate OS-generated time users expected, and inverse planning/proof needs extra ordering/regression work; a separate future intent would be needed for intermediate-time semantics. Real direct-child plus nested same-volume Rename and cross-volume folder Resume/Restore/Undo retain exact original/factual/requested separation. Keep/default is distinct from an explicit directory Set that equals the frozen original but still needs finalization after child path effects. Native Windows qualifications remain pending and gates stay closed.


## Approved matrix and workflow — verbatim spec sections3–4

The following is copied from the approved renaming spec, not a new design. Full R01–R17 controls and workflows are this task; native producer/Explorer R18 implementation remains Task22. Use the actual reviewed backend types and reports, retaining compatible imported data.

## 3. Included capability matrix

This is VidLibOrganizer's acceptance scope, not a claim of binary compatibility with BRU presets, its interface, or every undocumented setting. BRU's site mixes free and licensed features; JavaScript renaming/filtering is explicitly licensed. The capabilities below are intentionally included irrespective of an unresolved entitlement for a particular BRU version.

| ID | Included behavior | Acceptance example or rule |
| --- | --- | --- |
| R01 | Add prefixes/suffixes, insert text, literal replacement lists, remove characters/ranges, trim/collapse whitespace, crop around delimiters. | Strip a known release suffix and replace separators without changing the extension. |
| R02 | Move or copy a substring within a name; reverse a chosen segment; character translation and optional transliteration. | Move an existing year to the end; preserve non-Latin names unless a translation rule is enabled. |
| R03 | Upper/lower/title/sentence case, user-defined case exceptions, Roman-numeral case handling. | Preserve `BBC`, `III`, and a user exception while title-casing other words. |
| R04 | Multiple regex replacements with captures, lookarounds, backreferences in patterns, first/all match controls, and case sensitivity. | Extract/reorder an existing episode identifier; show unsupported or exhausted expressions as errors. |
| R05 | Restrict a rule to a segment by positions, positions from the end, or delimiter occurrences; reorder/repeat/disable rules. | Replace the second bracketed segment only; preview the effect of each rule. |
| R06 | Sequential numbering: start, step, padding, position, prefix/suffix, decimal/hex/alphabetic representation, repeat-each count, reset by folder. Pad existing numbers independently. | Natural order puts `2` before `10`; applying uses the numbering order frozen in the preview. |
| R07 | Date parsing/reformatting; date insertion from filename, filesystem dates, recording metadata, or a frozen current time. | Reformat a user-confirmed `DD-MM-YYYY` date; do not guess an ambiguous numeric date. |
| R08 | Name templates using original/current stem, extension, parent directories, relative directory, counters, dates, file size, available media properties, and explicit fallback/optional groups. | Missing required title blocks the row; an optional resolution group disappears cleanly if unknown. |
| R09 | Optional full-file CRC32, MD5, SHA-1, SHA-256, and SHA-512 name tokens; optional generated UUID/random tokens. | Hashing reads only when requested; generated values are frozen in the reviewed plan. |
| R10 | Keep/replace/remove a stem; extension case/change/add/remove controls and explicit whole-name mode. | Default rules affect the stem only; changing `.avi` to `.mp4` is labelled a name change, not conversion. |
| R11 | Recursive selection with depth limit; include/exclude wildcards and regex; filters on kind, extension, name/path length, size, dates, and attributes. | Root overlaps count a path once; selection changes regenerate counters and conflict checks. |
| R12 | Import explicit old-to-new mappings from CSV or delimited text; paste name lists; single-row override; export reviewed mappings/reports. | Ambiguous basename mapping is rejected; exact path mappings remain within authorized roots. |
| R13 | Saved, versioned presets; import/export of app recipes; undo/redo of recipe edits. | A preset reproduces the same names for the same frozen input and clock values. |
| R14 | Associated-file linking for subtitles, metadata, artwork, and paired assets. | Rename `old.en.forced.srt` with `old.mkv` while retaining `.en.forced`; keep `.idx`/`.sub` pairs together. |
| R15 | Subfolder renaming; new folder layouts; rename in place or copy/move to an explicit destination; preserve or transform relative hierarchy. | File and parent-folder renames have one consistent final-path preview. |
| R16 | Opt-in Windows attributes and filesystem timestamp changes. | Set/clear hidden/read-only/archive/system; set or offset created/modified/accessed time, including a per-item increment. Defaults leave them unchanged. |
| R17 | Searchable/sortable preview with highlighted differences, manual order, error details, export, execution history, recovery, validated undo. | A target conflict is visible before confirmation and cannot silently overwrite another file. |
| R18 | Native file/folder selection, drag/drop, keyboard access; optional Windows Explorer entry point passing selected paths. | Shell arguments select files for review; they never trigger execution or evaluate a command string. |

Photo-only EXIF modification, PDF metadata tooling, music-specific tagging, arbitrary JavaScript execution, transcoding, online identification, filesystem watchers that automatically rename, scheduled jobs, and BRU/BRC file-format compatibility are outside this release. Existing duplicate detection remains separate.

## 4. Workflow and interface

1. Choose files or roots. The initial filter selects videos; the user may explicitly include collection assets, other files, and folders. Inventory includes zero-byte entries with their status; the duplicate engine's zero-byte exclusion does not govern Rename.
2. Load a preset or build a recipe with ordered rule cards. Templates have a field picker and visible missing-field behavior. Advanced options are disclosed without requiring scripting.
3. Review a table of current name/path, proposed name/path, kind, size, and status. Filters are All, Changed, Unchanged, Needs review, and Blocked. Show exact counts for the approved selection, not just the displayed page.
4. Resolve or explicitly exclude blocked rows/dependency groups. Excluding a row or editing a rule creates a new plan revision and recomputes numbering, associated files, and collisions.
5. Review a summary of the current plan: file/folder counts, destinations, companion changes, metadata changes, and conflicts. Only this plan revision can be confirmed.
6. Execute in the background; display progress and partial outcomes. Completed operations appear in history with recovery/undo availability.

Rename has independent selection state. Importing a Blueprint selection or template is an explicit action. Browser preview uses fixture data and cannot perform operations. Screen-reader announcements describe progress and errors; focus returns to the initiating control after dialogs. Names/metadata are rendered as text, never HTML.

The backend is authoritative for generated names. The UI does not implement a second transformation engine. It requests paged rows, per-rule explanations, and aggregate counts from a versioned plan. A table sort changes display only; a separate visible control adopts that order for numbering. Manual reordering creates a new plan.



## Task20 controlled-field execution authority carry (Ruling18)

Ruling: Task20 fix round1 adds typed field-sensitive observed identity authority carrying the exact durable expected stamp plus the explicitly controlled timestamp fields, canonically derived by Undo from the original authorized intents and latest completed factual receipts. Keep existing Observed/FromReceipt data and generic volatile-atime semantics unchanged. New field constraints survive compiled inverse serialization, preflight, receipt/path lineage, native RenameRequest/cleanup at the first destructive effect, and recovery/Resume/Restore; never flatten them into generic freshness or refresh controlled values from an externally changed object. A receipt can track actual new identity/path but cannot silently discard or replace a controlled-field expectation; only explicitly authorized named effects may change that expectation under existing DirectoryAfterEffects/factual-prestate rules. Revalidate actual held and bound objects at the final existing native validation boundary. Preserve source grants/protection, full digest/identity, DAG/epoch and immutable facts; canonical validation prevents removal/substitution of required constraints and stays pure with no filesystem I/O in SQL. Preserve old decoding/meaning with checked migration only if genuinely required; this ruling does not require another journal relation. Reason: generic identity freshness intentionally ignores volatile atime, so an Undo-only preview check cannot protect a later destructive action. Cost if wrong: a broader serialized identity/native request and inverse/recovery protocol, more compatibility/crash tests, possible conservative refusals/rework, and older readers reject the new variant. Native Windows remains pending and production mutation gates stay CLOSED.

Read final reviewed Task20 report including appended fix1 for actual type/signature/evidence.


## Task20 UI-facing interface carry

Read final reviewed task-20-report.md, including all fix appendices; the controller dispatches21 only after20approval. `vidlib_rename::metadata::{MetadataChangeSet, AttributeChange, TimestampChange}` has Keep defaults for hidden/read_only/archive/system and created/modified/accessed. Existing core Timestamp remains exact Set; Offset and Increment use Ruling15. Desktop `RenameRequestDto.metadataChanges: Option<MetadataChangeSetDto>` uses strict camelCase (`readOnly`, `valueNs`, `offsetNs`, `startNs`, `stepNs`) and exact decimal strings. ABSENT controls preserve existing/imported recipe metadata; PROVIDED controls explicitly replace its metadata control set. Opening/closing a lazy panel must not silently emit all-Keep and erase imported metadata, and clearing an explicitly edited control must not leave hidden stale recipe effects. Use one authoritative editor/request state and actual core/DTO serialization; do not build a second filename engine. No implicit clock/timezone or numeric timestamp coercion.

Backend original frozen restoration targets, factual native pre-Set and requested/poststate values are distinct; display their meaning accurately. Legacy dynamic setter gaps without provable before-state remain unresolved. OS-managed atime and unsupported native creation/flag/precision requests stay truthful; no helper/compile/mock proves Windows runtime. `ExpectedIdentity::MetadataChecked` and native field constraints are backend authority and must never be constructed as permissions by JS; UI keeps using backend item/plan/recovery references and current confirmation. Read final20fixreport for any current signatures instead of inferring them from these notes. Full CPU between-item cancellation remains your task.

Today's user boundary is finish Rename23, then pause before Blueprint24; do not build Blueprint controls in this task.
