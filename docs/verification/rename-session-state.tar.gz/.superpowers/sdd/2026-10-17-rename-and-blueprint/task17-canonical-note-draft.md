# Pending review: Task17 canonical evidence draft
Do not apply completion until independent review passes.

Implementation:593405a. Core requested-only metadata cache/provenance, title/language/typed canonical fields, unknown-zone civil date retention, real legacy+ordered preview; official MediaInfo25.10Windowsx64 packaged exe+manifest+notices with exacthashes; bounded10s4MiB64KiB direct subprocess/COM worker and one drive slot; read-only held helper input with swap/restore red-green.

Step1portable reds observed; Step2core+Linuxhelper red complete but Windows command execution remains unchecked/pending. Step3implementation complete subjectreview. Step4realfixture/cache/process/packagehash+Tauristaging checks portablecomplete; installedWindowsNSIS/offlineresource smoke remains unchecked/pending. Step5commit593405a subjectfixes.

Finalaffectedchecks266distinct owningRust, later11inventory test-only robustness adjustment, Linux+WindowsGNUalltargetClippy and Windowshelper/preview/inventory executablelinks; vendor8resources3tests/fmt/stageddiff green. Earlier455distinctworkspace+4Node24Chromium PRE-sourcepinning and explicitlydistinct, notfreshfinalwholeworkspace. Oneignoredhelper_fixture intentionallychild-invoked by boundedparenttests.

PendingWindows: actual25.10helper/COM/PropertySystem/processJobcancel-reap/sourcepins-write/delete-sharing/ancestorpins/ordinarychildcreation-release/runtime/offlineNSISresource lookup/MSVC/NTFSexFATUNCshare. Otherarchitectures unsupported. No native mutation gate opened, no Rename/Blueprint completeclaim. Task21fullcontrols andTask23native/offlinegate later.
