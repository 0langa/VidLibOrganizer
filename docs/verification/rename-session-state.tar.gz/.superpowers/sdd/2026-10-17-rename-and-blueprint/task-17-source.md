### Task 17: Bundled metadata helper and Windows properties

**Files:** Create `src-tauri/src/metadata.rs`, `src-tauri/tests/metadata_helper.rs`, `crates/vidlib-rename/src/metadata.rs`, `crates/vidlib-rename/tests/metadata.rs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tests/fixtures/media/README.md`; update Tauri bundle resources and command adapters.

**Interfaces:** `MetadataProvider::probe(path: &Path, fields: &[PropertyKey], control: &JobControl) -> Result<MetadataRecord, MetadataIssue>`; each MetadataValue contains typed value, source key/provider/version, timezone status, or explicit Missing/Unsupported/Error. A cache key is physical identity + exact path + size/mtime + provider version + requested fields; absence of identity never merges unrelated paths.

- [ ] **Step 1 — Red:** Add `no_probe_for_text_recipe`, `requested_fields_only_and_cache_invalidates`, `helper_timeout_kills_and_reaps`, `stdout_stderr_and_json_are_bounded`, `windows_property_types_are_normalized`, and fixture-video duration/resolution/codec/title/date tests.
  ```rust
  assert_eq!(timeout.code, MetadataIssueCode::Timeout);
  assert!(child_was_reaped);
  assert_eq!(text_recipe_probe_count, 0);
  assert_eq!(record.recorded_date.timezone, TimezoneEvidence::Unknown);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test metadata`; Windows: `cargo test -p vidlib-tauri --test metadata_helper`.
- [ ] **Step 3 — Implement:** Resolve a stable official MediaInfo Windows CLI artifact per supported architecture, verify version/URL/SHA-256 and redistribution notices into the committed manifest, and package it as a local resource. Do not use floating `latest`, startup downloads, or a user PATH executable. Spawn directly without shell; 10-second monotonic deadline, 4 MiB stdout/64 KiB stderr caps, cancellation kill/reap and one probe per volume/drive. Parse only requested normalized fields. Add COM-initialized worker-owned Windows Property System extraction by canonical typed key. Fail clearly if a helper/field is unavailable; never edit embedded metadata.
- [ ] **Step 4 — Verify green:** Real fixture integration, fake hanging/noisy process fixtures, cache mutation tests, installer resource smoke check and hashes/notice validation. Fixture media is tiny, redistributable, and documented; no user's media are copied into the repository.
- [ ] **Step 5 — Commit:** `feat: bundle bounded offline media metadata probing`.

