# Task 01 implementation report

Status: DONE_WITH_CONCERNS (platform/runtime checks pending; implementation committed).

Commit: `d734f556c840da70cf0bc5cfb2a965b27603ae0b` — `feat: add native-path collection inventory`.
Parent/baseline: `786c2a4`.
Worktree: `/workspace/VidLibOrganizer/.worktrees/rename-blueprint`.

## Scope and requirements

Implemented `.superpowers/sdd/2026-10-17-rename-and-blueprint/task-01-brief.md` without reading the entire canonical plan. The controller later supplied the omitted section-3 inventory file list; final module structure matches that list, with small focused `control.rs` and `exact.rs` helpers. Canonical plan/checklist were not edited. No subagents were used. The commit includes only the inventory crate and required root Cargo manifest/lock edits. This ignored report is outside the implementation commit, as directed.

The cloud TDD skill lookup initially failed because cloud skills became unavailable. The controller supplied its exact cached contents at `.superpowers/sdd/2026-10-17-rename-and-blueprint/tdd-skill.md`; I read that before production behavior. I subsequently read the recovered `writing-good-tests.md` at `/workspace/scratch/superpowers-source/skills/test-driven-development/writing-good-tests.md`, pinned by the controller to Superpowers `bb92a77741419a4ab5f06e711a283343f1ada0c3`. No skill content was inferred from memory.

## Files and public interfaces

- Root `Cargo.toml`: adds workspace member `crates/vidlib-inventory`.
- Root `Cargo.lock`: adds inventory package dependency entry without upgrading existing packages.
- `crates/vidlib-inventory/Cargo.toml`: serde, UUID v4/serde, walkdir; Unix-only rustix FS for no-follow directory descriptors; Windows-only windows-sys filesystem APIs; tempfile/serde_json for tests. Traversal intentionally uses explicit listing/stat seams rather than opaque walkdir iteration so partial errors and listed names survive.
- `src/lib.rs`: public inventory surface/reexports; `path_codec` compatibility alias for `path`.
- `src/ids.rs`: opaque UUID-string newtypes `InventoryId`, `RootId`, `EntryId`, `GrantId`, `SessionId`, `JobId`, `PlanId`, `GroupId`, `StepId`, `OperationId`, `EventId`, `PresetId`, `CollectionId`, `AttemptId`, `AttachmentId`. IDs are explicitly not permissions.
- `src/path.rs`: `PathPlatform::{WindowsUtf16Le, UnixBytes}`, exact `NativePathRecord { platform, bytes }`, `encode_path`, fallible `decode_path`, and record-platform-aware `validate_relative`. Foreign encodings return an unsupported-platform error instead of transcoding; odd UTF16 byte lengths are errors. Portable relative records reject empty paths, parent/current components, absolute paths, NUL, and Windows drive/stream colon syntax.
- `src/exact.rs`: public serde adapters for canonical decimal-string `u64`, `i128`, and optional variants. Reject JSON numeric values, overflow, leading zeros, plus signs and negative zero.
- `src/model.rs`: `FileStamp`, `PhysicalId`, `EntrySnapshot`, `SourceGrant`, `GrantSet`, `RootBinding`, `RootEvidence`/`RootEvidenceState`, capability facts, `InventoryRequest`, `Inventory`, `ScopeCoverage`, observation windows and issues. Also defines `DirectoryFacts`, `NamespaceEntry`, `NamespaceSnapshot`, case/normalization/name-length facts and policy data for Task 02. No Rename/fileops dependency.
- `src/model.rs`: shared `BLUEPRINT_MARKER_NAME`, `STAGING_NAME_PREFIX`, and `ProtectedPolicy::excludes` are the canonical marker/staging/protected-root exclusion surface. Defaults are `.vidlib-blueprint.json` and prefix `.vidlib-staging`. Reserved ancestor components remain protected when explicitly selected as roots/files. Protected roots/custom prefixes remain explicit policy data.
- `src/control.rs`: cloneable `JobControl`, shared `Arc<AtomicBool>` cancellation, bounded nonblocking sync-channel progress, `Progress`/`ProgressPhase`; progress attempts throttled to at most one per 100 ms. Counts serialize exactly. Full/disconnected channels drop updates rather than block scanning.
- `src/scan.rs`: `scan(&InventoryRequest, &JobControl) -> Result<Inventory, InventoryError>`, `scan_with_fs` read-only injection seam, `InventoryFs`, `DirectoryListing`, `OsInventoryFs`. Native root/direct-file sources; path-based overlap deduplication; distinct hard-link entries; shallow roots first for stable ownership; listed names recorded before stat; unknown entries retained on failed stat; incomplete child/listing/cancellation coverage propagated to ancestors; no marker creation.
- `src/platform/mod.rs`: native nanosecond timestamp/stamp helpers.
- `src/platform/unix.rs`: device/inode identities as exact bytes and directory descriptor enumeration with `O_NOFOLLOW | O_DIRECTORY` through rustix.
- `src/platform/windows.rs`: read-only reparse-open handles, volume/file identities as bytes, Windows attribute bits, and handle-based directory enumeration with checked record bounds. Rejects directory reparse points independently of earlier stat. Windows code was cross-compiled/linted, not executed.
- `tests/support/mod.rs`: disposable real filesystem fixture and narrow stat/listing/cancellation failure injection.
- `tests/inventory.rs`, `tests/path_codec.rs`: behavior tests below.

Absolute lookup paths/source grants remain owned `PathBuf` in Rust and are skipped in JSON. Display text is generated separately and never used for keys or lookup. Root-relative entry records are validated before inclusion. Unsupported Unicode transformations on non-UTF8 native names remain visible issues with the original path retained. File identity does not deduplicate hard-link aliases. Capability uncertainty/evidence absence remain explicit rather than guessed. The scan returns observation snapshots, never mutation authority.

## Test-first evidence

All Cargo commands used command-scoped environment assignments, with no HOME redefinition:

```text
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH
```

### Initial required-contract red

Before production behavior, the workspace/crate declaration and empty `src/lib.rs` allowed Cargo to find the package and named test targets. Tests used only disposable temporary directories.

Command:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory --test path_codec
```

Observed exit 101. Intended missing-contract failures included unresolved `scan`, `InventoryFs`, `DirectoryListing`, `InventoryRequest`, `JobControl`, `RootBinding`, `ids`, `encode_path`, `decode_path`, and `FileStamp`. No user-directory access or unrelated runtime failure caused red. The captured full red log follows:

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
error[E0432]: unresolved imports `vidlib_inventory::DirectoryListing`, `vidlib_inventory::InventoryFs`, `vidlib_inventory::InventoryRequest`, `vidlib_inventory::JobControl`, `vidlib_inventory::RootBinding`, `vidlib_inventory::scan_with_fs`
 --> crates/vidlib-inventory/tests/support/mod.rs:3:24
  |
3 | use vidlib_inventory::{DirectoryListing, InventoryFs, InventoryRequest, JobControl, RootBinding, scan_with_fs};
  |                        ^^^^^^^^^^^^^^^^  ^^^^^^^^^^^  ^^^^^^^^^^^^^^^^  ^^^^^^^^^^  ^^^^^^^^^^^  ^^^^^^^^^^^^ no `scan_with_fs` in the root
  |                        |                 |            |                 |           |
  |                        |                 |            |                 |           no `RootBinding` in the root
  |                        |                 |            |                 no `JobControl` in the root
  |                        |                 |            no `InventoryRequest` in the root
  |                        |                 no `InventoryFs` in the root
  |                        no `DirectoryListing` in the root

error[E0432]: unresolved imports `vidlib_inventory::decode_path`, `vidlib_inventory::encode_path`, `vidlib_inventory::NativePathRecord`, `vidlib_inventory::PathPlatform`, `vidlib_inventory::FileStamp`, `vidlib_inventory::InventoryRequest`
 --> crates/vidlib-inventory/tests/path_codec.rs:2:24
  |
2 | use vidlib_inventory::{decode_path, encode_path, NativePathRecord, PathPlatform, FileStamp, InventoryRequest};
  |                        ^^^^^^^^^^^  ^^^^^^^^^^^  ^^^^^^^^^^^^^^^^  ^^^^^^^^^^^^  ^^^^^^^^^  ^^^^^^^^^^^^^^^^ no `InventoryRequest` in the root
  |                        |            |            |                 |             |
  |                        |            |            |                 |             no `FileStamp` in the root
  |                        |            |            |                 no `PathPlatform` in the root
  |                        |            |            no `NativePathRecord` in the root
  |                        |            no `encode_path` in the root
  |                        no `decode_path` in the root

error[E0432]: unresolved import `vidlib_inventory::ids`
 --> crates/vidlib-inventory/tests/path_codec.rs:3:23
  |
3 | use vidlib_inventory::ids::*;
  |                       ^^^ could not find `ids` in `vidlib_inventory`

error[E0432]: unresolved imports `vidlib_inventory::scan`, `vidlib_inventory::encode_path`, `vidlib_inventory::CoverageOutcome`, `vidlib_inventory::EntryKind`, `vidlib_inventory::InventoryRequest`, `vidlib_inventory::JobControl`, `vidlib_inventory::RootBinding`
 --> crates/vidlib-inventory/tests/inventory.rs:4:24
  |
4 | use vidlib_inventory::{scan, encode_path, CoverageOutcome, EntryKind, InventoryRequest, JobControl, RootBinding};
  |                        ^^^^  ^^^^^^^^^^^  ^^^^^^^^^^^^^^^  ^^^^^^^^^  ^^^^^^^^^^^^^^^^  ^^^^^^^^^^  ^^^^^^^^^^^ no `RootBinding` in the root
  |                        |     |            |                |          |                 |
  |                        |     |            |                |          |                 no `JobControl` in the root
  |                        |     |            |                |          no `InventoryRequest` in the root
  |                        |     |            |                no `EntryKind` in the root
  |                        |     |            no `CoverageOutcome` in the root
  |                        |     no `encode_path` in the root
  |                        no `scan` in the root

error[E0432]: unresolved imports `vidlib_inventory::NamespaceSnapshot`, `vidlib_inventory::DirectoryFacts`, `vidlib_inventory::CaseSensitivity`, `vidlib_inventory::RootEvidenceState`
   --> crates/vidlib-inventory/tests/inventory.rs:152:28
    |
152 |     use vidlib_inventory::{NamespaceSnapshot, DirectoryFacts, CaseSensitivity, RootEvidenceState};
    |                            ^^^^^^^^^^^^^^^^^  ^^^^^^^^^^^^^^  ^^^^^^^^^^^^^^^  ^^^^^^^^^^^^^^^^^ no `RootEvidenceState` in the root
    |                            |                  |               |
    |                            |                  |               no `CaseSensitivity` in the root
    |                            |                  no `DirectoryFacts` in the root
    |                            no `NamespaceSnapshot` in the root

error[E0433]: cannot find `IssueCode` in `vidlib_inventory`
   --> crates/vidlib-inventory/tests/inventory.rs:130:77
    |
130 |     assert!(entry.issues.iter().any(|issue| issue.code == vidlib_inventory::IssueCode::UnsupportedName));
    |                                                                             ^^^^^^^^^ could not find `IssueCode` in `vidlib_inventory`

error[E0425]: cannot find value `OsInventoryFs` in crate `vidlib_inventory`
  --> crates/vidlib-inventory/tests/support/mod.rs:46:45
   |
46 |         let mut listing = vidlib_inventory::OsInventoryFs.read_directory(path)?;
   |                                             ^^^^^^^^^^^^^ not found in `vidlib_inventory`

error[E0425]: cannot find type `Inventory` in crate `vidlib_inventory`
  --> crates/vidlib-inventory/tests/support/mod.rs:54:73
   |
54 | pub fn fault_scan(fixture: &Fixture, fs: &FaultFs) -> vidlib_inventory::Inventory {
   |                                                                         ^^^^^^^^^ not found in `vidlib_inventory`

error[E0425]: cannot find function `decode_path` in crate `vidlib_inventory`
   --> crates/vidlib-inventory/tests/inventory.rs:131:34
    |
131 |     assert_eq!(vidlib_inventory::decode_path(&entry.relative_path).unwrap(), path.file_name().unwrap());
    |                                  ^^^^^^^^^^^ not found in `vidlib_inventory`

Some errors have detailed explanations: E0425, E0432, E0433.
For more information about an error, try `rustc --explain E0425`.
error: could not compile `vidlib-inventory` (test "inventory") due to 7 previous errors
warning: build failed, waiting for other jobs to finish...
For more information about this error, try `rustc --explain E0432`.
error: could not compile `vidlib-inventory` (test "path_codec") due to 2 previous errors

```

### Initial scoped green

After implementing the contract, the identical scoped command passed 12 inventory tests and 5 path/JSON tests (17 total). Linux Clippy initially found `chunks_exact_to_as_chunks`, `unnecessary_lazy_evaluations`, then a test `field_reassign_with_default`; those were corrected and Clippy passed.

### Additional edge red/green

Before tightening reserved-subtree policy and OS directory listing, added real filesystem tests. Command was `cargo test -p vidlib-inventory --test inventory` with the same command-scoped environment. The actual Cargo output showed 12 passed / 2 failed, specifically the intended assertions for selected staging descendants and directly listing a directory link. Captured red output:

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.34s
     Running tests/inventory.rs (target/debug/deps/inventory-9ec74283a4b33a20)

running 14 tests
test cancellation_preserves_coverage ... ok
test explicit_files_are_supported_and_relative_grants_are_rejected ... ok
test failed_stat_retains_listed_child ... ok
test links_are_visible_but_never_followed ... ok
test namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops ... ok
test os_directory_listing_refuses_directory_links ... FAILED
test native_modified_timestamp_and_regular_file_size_match_os_observation ... ok
test non_utf8_names_remain_native_and_carry_transformation_issues ... ok
test overlap_deduplicates_paths_not_hardlinks ... ok
test precancelled_scan_records_unvisited_roots_and_progress_is_bounded ... ok
test protected_subtrees_are_excluded_when_selected_directly ... FAILED
test protected_marker_and_staging_names_remain_in_listing_but_are_excluded ... ok
test scan_keeps_unique_empty_and_nonvideo_entries ... ok
test partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors ... ok

failures:

---- os_directory_listing_refuses_directory_links stdout ----

thread 'os_directory_listing_refuses_directory_links' (9723) panicked at crates/vidlib-inventory/tests/inventory.rs:319:5:
assertion failed: vidlib_inventory::OsInventoryFs.read_directory(&link).is_err()
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace

---- protected_subtrees_are_excluded_when_selected_directly stdout ----

thread 'protected_subtrees_are_excluded_when_selected_directly' (9728) panicked at crates/vidlib-inventory/tests/inventory.rs:307:9:
assertion failed: inventory.entries.is_empty()


failures:
    os_directory_listing_refuses_directory_links
    protected_subtrees_are_excluded_when_selected_directly

test result: FAILED. 12 passed; 2 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p vidlib-inventory --test inventory`

```

The fixes moved exclusion matching to all ancestor components and changed OS listing to no-follow directory handles. The required scoped command then passed 14 inventory tests and 5 path/JSON tests. Final scoped output:

```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.10s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 14 tests
test cancellation_preserves_coverage ... ok
test failed_stat_retains_listed_child ... ok
test links_are_visible_but_never_followed ... ok
test explicit_files_are_supported_and_relative_grants_are_rejected ... ok
test namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops ... ok
test native_modified_timestamp_and_regular_file_size_match_os_observation ... ok
test non_utf8_names_remain_native_and_carry_transformation_issues ... ok
test os_directory_listing_refuses_directory_links ... ok
test precancelled_scan_records_unvisited_roots_and_progress_is_bounded ... ok
test overlap_deduplicates_paths_not_hardlinks ... ok
test partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors ... ok
test protected_subtrees_are_excluded_when_selected_directly ... ok
test scan_keeps_unique_empty_and_nonvideo_entries ... ok
test protected_marker_and_staging_names_remain_in_listing_but_are_excluded ... ok

test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/path_codec.rs (target/debug/deps/path_codec-4d9b5506ad20490f)

running 5 tests
test all_ids_are_distinct_uuid_strings ... ok
test path_codec_round_trips_native_units ... ok
test json_quantities_and_nanosecond_timestamps_use_validated_decimal_strings ... ok
test portable_relative_paths_reject_escape_and_native_display_is_not_lookup ... ok
test windows_utf16_fixture_is_exact_and_foreign_paths_are_not_transcoded ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## Tests by name

Inventory (14 executed on Linux):

1. `scan_keeps_unique_empty_and_nonvideo_entries`
2. `overlap_deduplicates_paths_not_hardlinks`
3. `failed_stat_retains_listed_child`
4. `cancellation_preserves_coverage`
5. `partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors`
6. `explicit_files_are_supported_and_relative_grants_are_rejected`
7. `protected_marker_and_staging_names_remain_in_listing_but_are_excluded`
8. `links_are_visible_but_never_followed` (Unix)
9. `non_utf8_names_remain_native_and_carry_transformation_issues` (Unix)
10. `precancelled_scan_records_unvisited_roots_and_progress_is_bounded`
11. `namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops`
12. `native_modified_timestamp_and_regular_file_size_match_os_observation`
13. `protected_subtrees_are_excluded_when_selected_directly`
14. `os_directory_listing_refuses_directory_links` (Unix)

Windows-only `os_directory_listing_refuses_directory_reparse_points` compiles, but execution remains pending; it needs Windows Developer Mode or symlink privileges. The native-unit roundtrip test includes Windows unpaired-surrogate code, also only cross-compiled. No Windows runtime success is claimed.

Path/JSON (5 executed on Linux):

1. `path_codec_round_trips_native_units`
2. `windows_utf16_fixture_is_exact_and_foreign_paths_are_not_transcoded`
3. `portable_relative_paths_reject_escape_and_native_display_is_not_lookup`
4. `all_ids_are_distinct_uuid_strings`
5. `json_quantities_and_nanosecond_timestamps_use_validated_decimal_strings`

The Windows UTF16LE fixture `[0x61, 0, 0, 0xD8, 0x62, 0]` preserves an unpaired surrogate across JSON on Linux and is explicitly rejected for native lookup there. Unix invalid-byte names are exercised on real temporary files. FileStamp tests include `u64::MAX`, `i128::MIN/MAX`, pre-epoch `-1`, >JS-exact-integer quantities, noncanonical strings, numeric JSON and overflow.

## Final verification

Passed:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory --test path_codec
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo clippy -p vidlib-inventory --all-targets -- -D warnings
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo clippy -p vidlib-inventory --target x86_64-pc-windows-gnu --all-targets -- -D warnings
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo check -p vidlib-inventory --target x86_64-pc-windows-gnu --all-targets
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo fmt --all -- --check
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory -p vidlib-engine -p vidlib-fileops
git diff --check
```

The final portable suite passed 55 tests: 19 inventory + 14 existing engine scan + 1 existing fileops unit + 21 existing fileops integration. No existing tests changed. Doc tests passed. Final Linux Clippy output:

```text
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.12s

```

Final Windows-target Clippy output:

```text
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.10s

```

Portable suite output:

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.73s
     Running unittests src/lib.rs (target/debug/deps/vidlib_engine-d93bfedd144350c9)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/scan.rs (target/debug/deps/scan-c76ad2f0b7e7510f)

running 14 tests
test cancellation_before_scan_preserves_cancelled_state ... ok
test directory_links_are_not_followed_or_counted_as_extra_videos ... ok
test empty_library_completes_without_issues_or_hash_work ... ok
test fast_scan_groups_exact_sizes_recursively_without_content_comparison ... ok
test invalid_roots_produce_issues_without_discarding_valid_roots ... ok
test md5_separates_same_size_collisions_and_hashes_complete_candidates_only ... ok
test missing_candidate_reports_issue_and_keeps_other_duplicate_results ... ok
test cancellation_mid_hash_stops_before_finishing_current_file ... ok
test no_roots_is_a_validation_error ... ok
test overlapping_roots_and_repeated_paths_are_counted_once ... ok
test selected_directory_link_is_reported_instead_of_followed ... ok
test files_changed_during_hashing_are_excluded_and_reported ... ok
test modification_time_change_without_length_change_invalidates_hash ... ok
test complete_hash_detects_a_difference_beyond_the_first_buffer ... ok

test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.06s

     Running unittests src/lib.rs (target/debug/deps/vidlib_fileops-4d310a9b5f95c519)

running 1 test
test tests::changed_source_after_validation_cleans_partial_destination ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/actions.rs (target/debug/deps/actions-b4a440a8f8447d98)

running 21 tests
test changed_modification_time_rejects_deletion ... ok
test changed_kept_copy_hash_prevents_deletion_even_with_restored_timestamp ... ok
test changed_selected_content_rejects_md5_actions_with_restored_timestamp ... ok
test duplicate_selection_is_rejected ... ok
test empty_selection_is_rejected ... ok
test missing_kept_copy_prevents_deletion ... ok
test deleting_a_selected_copy_keeps_the_original ... ok
test invalid_move_destination_prevents_changes ... ok
test missing_md5_hash_rejects_actions ... ok
test move_collision_never_overwrites_existing_file ... ok
test move_preserves_content_and_kept_original ... ok
test move_preserves_original_modification_timestamp ... ok
test move_to_source_directory_is_rejected ... ok
test selecting_every_copy_is_rejected_before_any_deletion ... ok
test size_candidates_can_be_deleted_without_content_equality ... ok
test stale_group_late_in_request_prevents_changes_to_an_earlier_group ... ok
test stale_selected_file_rejects_every_action ... ok
test symlink_source_is_rejected_without_removing_its_target ... ok
test selected_files_with_same_name_both_move_without_overwrite ... ok
test unknown_path_rejects_the_entire_request ... ok
test move_preserves_content_across_many_streaming_chunks ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

     Running unittests src/lib.rs (target/debug/deps/vidlib_inventory-8cf31c7bb3797f0b)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 14 tests
test explicit_files_are_supported_and_relative_grants_are_rejected ... ok
test cancellation_preserves_coverage ... ok
test failed_stat_retains_listed_child ... ok
test links_are_visible_but_never_followed ... ok
test namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops ... ok
test os_directory_listing_refuses_directory_links ... ok
test overlap_deduplicates_paths_not_hardlinks ... ok
test native_modified_timestamp_and_regular_file_size_match_os_observation ... ok
test precancelled_scan_records_unvisited_roots_and_progress_is_bounded ... ok
test non_utf8_names_remain_native_and_carry_transformation_issues ... ok
test partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors ... ok
test protected_subtrees_are_excluded_when_selected_directly ... ok
test protected_marker_and_staging_names_remain_in_listing_but_are_excluded ... ok
test scan_keeps_unique_empty_and_nonvideo_entries ... ok

test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/path_codec.rs (target/debug/deps/path_codec-4d9b5506ad20490f)

running 5 tests
test path_codec_round_trips_native_units ... ok
test portable_relative_paths_reject_escape_and_native_display_is_not_lookup ... ok
test all_ids_are_distinct_uuid_strings ... ok
test json_quantities_and_nanosecond_timestamps_use_validated_decimal_strings ... ok
test windows_utf16_fixture_is_exact_and_foreign_paths_are_not_transcoded ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_engine

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_fileops

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_inventory

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

## Concerns / unavailable checks

- Actual Windows execution remains pending: reparse/link behavior, physical identity adapters, native UTF16/unpaired-surrogate roundtrip, filesystem-specific timestamp/case behavior. Windows-target check/Clippy prove compilation/linting only. Linux tests are not Windows evidence.
- An unconfigured-environment `cargo test --workspace --all-targets` attempt exited 101 in `glib-sys v0.18.1`'s custom build: `pkg-config` could not find `glib-2.0 >= 2.70` / `glib-2.0.pc`. This did not reach desktop tests. The controller subsequently clarified the configured desktop environment at `/workspace/.tools/desktop-env.sh` / `/workspace/.tools/desktop-target`: native dependencies can build there, but desktop currently fails on baseline missing `src-tauri/icons/icon.png` (only `icon.ico` is tracked). Task 05 will address the supporting asset. Per controller direction, the full workspace was not rerun. No desktop completion claim is made.
- Inventory is read-only and time bounded; filesystem changes between observations remain possible. Opened directory enumeration rejects a final symlink/reparse replacement, but this is not a locked namespace or an authority for later actions. Later operation adapters must revalidate live grants/namespace/stamps before mutation as specified.
- Unobserved capability facts remain `Unknown`; physical identity acquisition may return absence. Missing evidence and mismatched evidence use separate states. No marker parser, marker creation, mutation/journaling, or later-task feature was added.

No outstanding Linux portable test failures. No canonical plan/checklist edits. Controller review follows the committed diff.


# Task 01 — Fix round 1/5

Review source: `/workspace/scratch/task01-review.md`, Important items 1–3, read verbatim.
FIX_BASE / reviewed HEAD: `d734f556c840da70cf0bc5cfb2a965b27603ae0b`.
Fix commit: `dfc7e4eae1f46f165d32e83790263f2f6935d9f2` — `fix: anchor inventory traversal and validate every binding`.

Loaded Superpowers receiving-code-review and TDD skills for this round; applied the already-read writing-good-tests reference. No subagents, canonical checklist edits, or later-feature work.

## Important item 1: anchored child observations

Reproduced the actual escape with a deterministic real-directory fixture: after enumerating `nested`, the test adapter renames it and replaces it with a link to an external temporary tree whose `sub` directory contains `outside.mkv`. The reviewed scanner followed the intermediate link and returned `outside.mkv`; the intended red assertion failed. The fixed scanner returns no external child and reports incomplete nested/ancestor coverage, while retaining the exact listed `sub` name.

The read-only seam now exposes `InventoryDirectory` and `FileObservation`. The scanner keeps the enumerated directory handle live through child stat and child-directory open. Child operations accept exactly one validated native component and never fall back to absolute child lookup:

- Unix holds an opened directory `File`; `statx` (with `statat` fallback on ENOSYS) uses the parent descriptor and `SYMLINK_NOFOLLOW`; child directory `openat` uses `O_NOFOLLOW | O_DIRECTORY`. Linux birth time is preserved when statx supplies it; created time is absent when the fallback cannot observe it. Existing native timestamp/size/non-UTF8 tests remain green.
- Windows keeps the directory handle and opens each exact child with `NtCreateFile` using `OBJECT_ATTRIBUTES.RootDirectory`, `FILE_OPEN_REPARSE_POINT`, read-only access and shared read/write/delete. Metadata and identity are obtained from that child handle. Child directories are rejected if their handle metadata identifies a link/reparse point. Existing handle directory enumeration operates on the retained handle.
- The scanner verifies that the held directory matches the earlier observation, checks live directory/ancestor path identities before child traversal and at completion, and records `IssueCode::DirectoryChanged` with failed coverage if consistency cannot be established. Missing identity fails closed rather than asserting complete coverage. Native relative operations provide the actual no-follow guarantee; live path checks additionally prevent a moved/replaced binding from appearing complete.

The failure adapter now wraps real directory handles, injecting only stat/listing/cancellation/swap effects while retaining the native anchoring behavior.

## Important item 2: reserved/protected namespace comparison

Reproduced reserved ASCII case variants and case-varied protected roots entering the inventory before the fix. Shared `ProtectedPolicy::excludes` now applies native component comparisons to marker, staging and protected-root checks, including direct selection and ancestor components. Root matching stays component bounded (`protected-other` is still visible).

Because policy does not claim known filesystem case behavior, Unix conservatively protects ASCII case variants too; Windows uses native `CompareStringOrdinal` with ignore-case for UTF16 components, including Unicode protected-root aliases. Original native paths remain unchanged; comparisons neither transcode nor reconstruct lookup paths. Comparison uncertainty protects conservatively. The filter fingerprint version is bumped to `inventory-filter-v2` to distinguish the changed comparison semantics.

The portable ASCII/direct-selection tests execute on Linux and compile on Windows. Windows-only Unicode-root test `windows_protected_roots_match_native_unicode_case_aliases` compiles but remains unexecuted; no Windows runtime success is claimed.

## Important item 3: every binding gets fresh evidence

Reproduced an overlapping nested binding carrying wrong expected identity and old `Matches`: the reviewed scanner skipped it and retained `Matches`. Also reproduced missing observation/coverage association for a valid overlapping nested binding. Validation now happens before traversal deduplication. A wrong nested expected identity produces fresh `Mismatch`, observed identity, an `EvidenceMismatch` issue and a failed scope associated with that root ID, while entries stay deduplicated.

Binding observation/state is reset for each scan; a failed new observation cannot retain old `Matches` or an old observed identity. A focused additional red/green test covers that unavailable-evidence path. Successfully observed overlapping directory bindings retain a coverage association under their own root ID, even though entry traversal is shared.

**Overlap ownership/coverage contract:** shallow-root traversal owns entries, and exact native-path deduplication yields one `EntrySnapshot` per observed native path (hard-link aliases remain separate). An overlapping binding has its own fresh evidence and root coverage association but does not get duplicate copies of the entries already owned by the shallow root. Later per-root Blueprint consumers must preserve binding evidence and resolve overlapping ownership/coverage; they must not interpret the absence of duplicate entries with the overlapping root ID as absent filesystem entries. The controller will carry this interface note into refresh integration.

## New regression tests

Linux-executed additions (6):

1. `overlapping_bindings_validate_evidence_before_deduplicating_traversal`
2. `overlapping_bindings_retain_their_own_observation_and_coverage_association`
3. `reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems`
4. `protected_roots_conservatively_match_case_aliases_at_component_boundaries`
5. `replacing_a_listed_directory_with_an_external_link_never_observes_external_children`
6. `failed_binding_observation_drops_previously_matched_evidence`

Windows-only addition: `windows_protected_roots_match_native_unicode_case_aliases` (compiled/linted, runtime pending). The swap test uses Windows symlink creation on that target and therefore also needs Developer Mode or appropriate symlink privileges at runtime.

## Exact red/green commands and output

Every Cargo invocation retains command-scoped CARGO_HOME/RUSTUP_HOME/PATH and does not redefine HOME.

### evidence

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory overlapping_bindings
```

Observed red (exit 101, intended behavior assertion):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.60s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 2 tests
test overlapping_bindings_retain_their_own_observation_and_coverage_association ... FAILED
test overlapping_bindings_validate_evidence_before_deduplicating_traversal ... FAILED

failures:

---- overlapping_bindings_retain_their_own_observation_and_coverage_association stdout ----

thread 'overlapping_bindings_retain_their_own_observation_and_coverage_association' (11971) panicked at crates/vidlib-inventory/tests/inventory.rs:365:5:
assertion failed: binding.evidence.observed_identity.is_some()
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace

---- overlapping_bindings_validate_evidence_before_deduplicating_traversal stdout ----

thread 'overlapping_bindings_validate_evidence_before_deduplicating_traversal' (11972) panicked at crates/vidlib-inventory/tests/inventory.rs:349:5:
assertion `left == right` failed
  left: Matches
 right: Mismatch


failures:
    overlapping_bindings_retain_their_own_observation_and_coverage_association
    overlapping_bindings_validate_evidence_before_deduplicating_traversal

test result: FAILED. 0 passed; 2 failed; 0 ignored; 0 measured; 14 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p vidlib-inventory --test inventory`

```

Observed green (exit 0):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.83s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 2 tests
test overlapping_bindings_retain_their_own_observation_and_coverage_association ... ok
test overlapping_bindings_validate_evidence_before_deduplicating_traversal ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 14 filtered out; finished in 0.00s


```

### case

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory conservatively
```

Observed red (exit 101, intended behavior assertion):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.38s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 2 tests
test reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems ... FAILED
test protected_roots_conservatively_match_case_aliases_at_component_boundaries ... FAILED

failures:

---- reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems stdout ----

thread 'reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems' (12394) panicked at crates/vidlib-inventory/tests/inventory.rs:382:5:
assertion failed: !inventory.entries.iter().any(|entry|
            entry.absolute_path == marker || entry.absolute_path == staging ||
                entry.absolute_path == hidden)

---- protected_roots_conservatively_match_case_aliases_at_component_boundaries stdout ----

thread 'protected_roots_conservatively_match_case_aliases_at_component_boundaries' (12393) panicked at crates/vidlib-inventory/tests/inventory.rs:403:5:
assertion failed: !inventory.entries.iter().any(|entry|
            entry.absolute_path.starts_with(&protected))
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    protected_roots_conservatively_match_case_aliases_at_component_boundaries
    reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems

test result: FAILED. 0 passed; 2 failed; 0 ignored; 0 measured; 16 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p vidlib-inventory --test inventory`

```

Observed green (exit 0):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.68s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 2 tests
test protected_roots_conservatively_match_case_aliases_at_component_boundaries ... ok
test reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 16 filtered out; finished in 0.00s


```

### anchoring

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory replacing_a_listed
```

Observed red (exit 101, intended behavior assertion):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.39s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 1 test
test replacing_a_listed_directory_with_an_external_link_never_observes_external_children ... FAILED

failures:

---- replacing_a_listed_directory_with_an_external_link_never_observes_external_children stdout ----

thread 'replacing_a_listed_directory_with_an_external_link_never_observes_external_children' (12842) panicked at crates/vidlib-inventory/tests/inventory.rs:437:5:
assertion failed: !inventory.entries.iter().any(|entry| entry.display_name == "outside.mkv")
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    replacing_a_listed_directory_with_an_external_link_never_observes_external_children

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 18 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p vidlib-inventory --test inventory`

```

Observed green (exit 0):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.72s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 1 test
test replacing_a_listed_directory_with_an_external_link_never_observes_external_children ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 18 filtered out; finished in 0.00s


```

### unavailable

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory failed_binding_observation
```

Observed red (exit 101, intended behavior assertion):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.43s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 1 test
test failed_binding_observation_drops_previously_matched_evidence ... FAILED

failures:

---- failed_binding_observation_drops_previously_matched_evidence stdout ----

thread 'failed_binding_observation_drops_previously_matched_evidence' (13526) panicked at crates/vidlib-inventory/tests/inventory.rs:459:5:
assertion `left == right` failed
  left: Matches
 right: Unavailable
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    failed_binding_observation_drops_previously_matched_evidence

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 19 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p vidlib-inventory --test inventory`

```

Observed green (exit 0):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.67s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 1 test
test failed_binding_observation_drops_previously_matched_evidence ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 19 filtered out; finished in 0.00s


```

## Final round verification

Commands (all exited 0):

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory --test path_codec
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory -p vidlib-engine -p vidlib-fileops
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo clippy -p vidlib-inventory --all-targets -- -D warnings
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo clippy -p vidlib-inventory --target x86_64-pc-windows-gnu --all-targets -- -D warnings
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo fmt --all -- --check
git diff --check
```

The final explicit scoped command and final portable command both include the unavailable-evidence regression and pass all 25 inventory tests (20 inventory +5 codec/JSON) plus the unchanged 36 existing engine/fileops tests: 61 total. Documentation tests pass. The full desktop/workspace attempt was not repeated; the previously reported baseline dependency/icon limitations remain unchanged and the controller explicitly requested scoped/portable verification only.

Final portable output:

```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.47s
     Running unittests src/lib.rs (target/debug/deps/vidlib_engine-d93bfedd144350c9)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/scan.rs (target/debug/deps/scan-c76ad2f0b7e7510f)

running 14 tests
test cancellation_before_scan_preserves_cancelled_state ... ok
test directory_links_are_not_followed_or_counted_as_extra_videos ... ok
test empty_library_completes_without_issues_or_hash_work ... ok
test fast_scan_groups_exact_sizes_recursively_without_content_comparison ... ok
test invalid_roots_produce_issues_without_discarding_valid_roots ... ok
test md5_separates_same_size_collisions_and_hashes_complete_candidates_only ... ok
test missing_candidate_reports_issue_and_keeps_other_duplicate_results ... ok
test cancellation_mid_hash_stops_before_finishing_current_file ... ok
test no_roots_is_a_validation_error ... ok
test overlapping_roots_and_repeated_paths_are_counted_once ... ok
test selected_directory_link_is_reported_instead_of_followed ... ok
test files_changed_during_hashing_are_excluded_and_reported ... ok
test modification_time_change_without_length_change_invalidates_hash ... ok
test complete_hash_detects_a_difference_beyond_the_first_buffer ... ok

test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.06s

     Running unittests src/lib.rs (target/debug/deps/vidlib_fileops-4d310a9b5f95c519)

running 1 test
test tests::changed_source_after_validation_cleans_partial_destination ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/actions.rs (target/debug/deps/actions-b4a440a8f8447d98)

running 21 tests
test deleting_a_selected_copy_keeps_the_original ... ok
test duplicate_selection_is_rejected ... ok
test changed_kept_copy_hash_prevents_deletion_even_with_restored_timestamp ... ok
test changed_modification_time_rejects_deletion ... ok
test empty_selection_is_rejected ... ok
test invalid_move_destination_prevents_changes ... ok
test missing_kept_copy_prevents_deletion ... ok
test changed_selected_content_rejects_md5_actions_with_restored_timestamp ... ok
test missing_md5_hash_rejects_actions ... ok
test move_collision_never_overwrites_existing_file ... ok
test move_preserves_content_and_kept_original ... ok
test move_preserves_original_modification_timestamp ... ok
test move_to_source_directory_is_rejected ... ok
test selecting_every_copy_is_rejected_before_any_deletion ... ok
test size_candidates_can_be_deleted_without_content_equality ... ok
test stale_selected_file_rejects_every_action ... ok
test stale_group_late_in_request_prevents_changes_to_an_earlier_group ... ok
test symlink_source_is_rejected_without_removing_its_target ... ok
test unknown_path_rejects_the_entire_request ... ok
test selected_files_with_same_name_both_move_without_overwrite ... ok
test move_preserves_content_across_many_streaming_chunks ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running unittests src/lib.rs (target/debug/deps/vidlib_inventory-8cf31c7bb3797f0b)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 20 tests
test cancellation_preserves_coverage ... ok
test explicit_files_are_supported_and_relative_grants_are_rejected ... ok
test failed_binding_observation_drops_previously_matched_evidence ... ok
test namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops ... ok
test links_are_visible_but_never_followed ... ok
test failed_stat_retains_listed_child ... ok
test native_modified_timestamp_and_regular_file_size_match_os_observation ... ok
test os_directory_listing_refuses_directory_links ... ok
test non_utf8_names_remain_native_and_carry_transformation_issues ... ok
test overlap_deduplicates_paths_not_hardlinks ... ok
test overlapping_bindings_retain_their_own_observation_and_coverage_association ... ok
test overlapping_bindings_validate_evidence_before_deduplicating_traversal ... ok
test precancelled_scan_records_unvisited_roots_and_progress_is_bounded ... ok
test protected_marker_and_staging_names_remain_in_listing_but_are_excluded ... ok
test partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors ... ok
test protected_subtrees_are_excluded_when_selected_directly ... ok
test protected_roots_conservatively_match_case_aliases_at_component_boundaries ... ok
test replacing_a_listed_directory_with_an_external_link_never_observes_external_children ... ok
test reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems ... ok
test scan_keeps_unique_empty_and_nonvideo_entries ... ok

test result: ok. 20 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/path_codec.rs (target/debug/deps/path_codec-4d9b5506ad20490f)

running 5 tests
test all_ids_are_distinct_uuid_strings ... ok
test path_codec_round_trips_native_units ... ok
test portable_relative_paths_reject_escape_and_native_display_is_not_lookup ... ok
test json_quantities_and_nanosecond_timestamps_use_validated_decimal_strings ... ok
test windows_utf16_fixture_is_exact_and_foreign_paths_are_not_transcoded ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_engine

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_fileops

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_inventory

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

Final Linux Clippy output:

```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on build directory
    Checking vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 2.61s

```

Final Windows GNU target Clippy output:

```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on build directory
    Checking vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 2.01s

```

## Remaining status notes

- No known failing Linux portable regression remains for the reviewed issues.
- Actual Windows runtime behavior remains pending, including NtCreateFile relative-handle access/reparse handling, native Unicode policy comparisons, physical identity, UTF16 paths and filesystem-specific behavior. Cross-target compilation/Clippy is not Windows execution evidence.
- The new handle surface and conservative unknown-identity failure are part of read-only inventory. Later platform execution, journaling, Rename and Blueprint features remain separate tasks. No changes to later-feature or release-completion status are claimed.
- The overlap ownership/coverage note above is a consumer integration requirement, not a claim that later Blueprint refresh is implemented.

Final post-commit scoped output (exit 0):

```text
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.16s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 20 tests
test explicit_files_are_supported_and_relative_grants_are_rejected ... ok
test cancellation_preserves_coverage ... ok
test failed_stat_retains_listed_child ... ok
test failed_binding_observation_drops_previously_matched_evidence ... ok
test links_are_visible_but_never_followed ... ok
test namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops ... ok
test os_directory_listing_refuses_directory_links ... ok
test native_modified_timestamp_and_regular_file_size_match_os_observation ... ok
test non_utf8_names_remain_native_and_carry_transformation_issues ... ok
test overlap_deduplicates_paths_not_hardlinks ... ok
test overlapping_bindings_retain_their_own_observation_and_coverage_association ... ok
test overlapping_bindings_validate_evidence_before_deduplicating_traversal ... ok
test precancelled_scan_records_unvisited_roots_and_progress_is_bounded ... ok
test protected_marker_and_staging_names_remain_in_listing_but_are_excluded ... ok
test protected_subtrees_are_excluded_when_selected_directly ... ok
test partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors ... ok
test replacing_a_listed_directory_with_an_external_link_never_observes_external_children ... ok
test protected_roots_conservatively_match_case_aliases_at_component_boundaries ... ok
test reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems ... ok
test scan_keeps_unique_empty_and_nonvideo_entries ... ok

test result: ok. 20 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/path_codec.rs (target/debug/deps/path_codec-4d9b5506ad20490f)

running 5 tests
test all_ids_are_distinct_uuid_strings ... ok
test path_codec_round_trips_native_units ... ok
test portable_relative_paths_reject_escape_and_native_display_is_not_lookup ... ok
test windows_utf16_fixture_is_exact_and_foreign_paths_are_not_transcoded ... ok
test json_quantities_and_nanosecond_timestamps_use_validated_decimal_strings ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```


# Task 01 — Fix round 2/5

Review source: `/workspace/scratch/task01-rereview1.md`, read verbatim, especially New Breakage / Important optional-identity enumeration regression. The three original Important findings are recorded as ADDRESSED and were not reopened. The Minor copied-overlap issue-path attribution item is explicitly deferred by the controller to whole-branch review and was not changed.

FIX_BASE: `dfc7e4eae1f46f165d32e83790263f2f6935d9f2`.
Fix commit: `aff67d56929657ee6b74652475ac3c975591bd2f` — `fix: retain safe inventory observations without physical identity`.

## Regression and scoped fix

The intended-red test uses the real retained no-follow directory handles and a narrow identity-availability seam in `tests/support/mod.rs`. Cases independently omit initial root identity, retained-handle/child identity, and both. The reviewed scanner returned zero entries even for the first valid-handle case; the observed assertion was `left: 0 / right: 6`.

The scanner now distinguishes three conditions:

- Invalid/non-directory retained handle: reject traversal with failed coverage.
- Both physical identities available and positively unequal: reject traversal with failed coverage.
- Valid retained handle with unavailable optional physical identity: preserve safe handle-relative enumeration, metadata and recursive observations; keep coverage incomplete with `IssueCode::IdentityUnavailable`.

Internal ancestor anchors carry optional identity. Known identities retain the existing live path/ancestor consistency checks; missing identity is never treated as proof of consistency. Any missing directory/ancestor identity makes `subtree_complete` false, while a successful enumeration can still truthfully set `children_complete` and retain every exact listed name. Operations remain handle relative, so unavailable identity does not restore absolute child lookup or link following.

The Windows handle observation adapter also preserves a successful metadata observation when optional file identity lookup fails, rather than converting optional identity absence into an invalid-handle error. Validating handle metadata/kind remains required.

This supersedes the round-1 report's statement that missing identity failed closed before listing: consistency now fails closed in coverage while safe observations survive, matching the optional-identity contract.

Changed files are limited to `src/scan.rs`, one new issue variant in `src/model.rs`, the optional identity handling in `src/platform/windows.rs`, and the focused fixture/regressions in `tests/inventory.rs` and `tests/support/mod.rs`. No canonical checklist, later feature, or overlap-attribution changes. No subagents.

## Named covering tests

New tests:

1. `unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage` — all six entries, including nested `c.mov`, survive each missing-identity case; exact listed names remain; enumeration can be complete while subtree coverage is failed/incomplete; identity-unavailable issues and unavailable expected-root evidence remain explicit.
2. `mismatched_identity_or_invalid_directory_handle_still_rejects_traversal` — positive identity mismatch and non-directory handle metadata each reject child enumeration and produce failed coverage.

The full inventory/path codec run also keeps the original directory-link replacement, no-follow, case exclusion, overlap evidence, stat/listing failure, cancellation, hard-link, native-path and exact JSON regressions green. The unchanged 36 engine/fileops tests pass.

## Exact commands and relevant output

All Cargo commands use command-scoped toolchain variables; HOME is never redefined.

Intended red (exit 101), before production changes:

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory unavailable_directory_identity
```

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.55s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 1 test
test unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage ... FAILED

failures:

---- unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage stdout ----

thread 'unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage' (14767) panicked at crates/vidlib-inventory/tests/inventory.rs:545:9:
assertion `left == right` failed: root missing=true, handle missing=false
  left: 0
 right: 6
note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace


failures:
    unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage

test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 21 filtered out; finished in 0.00s

error: test failed, to rerun pass `-p vidlib-inventory --test inventory`

```

Identical focused command after the fix (exit 0):

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 1.18s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 1 test
test unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 21 filtered out; finished in 0.00s


```

Covering tests (exit 0):

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory --test inventory --test path_codec
```

```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.93s
     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 22 tests
test explicit_files_are_supported_and_relative_grants_are_rejected ... ok
test cancellation_preserves_coverage ... ok
test failed_binding_observation_drops_previously_matched_evidence ... ok
test namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops ... ok
test failed_stat_retains_listed_child ... ok
test links_are_visible_but_never_followed ... ok
test mismatched_identity_or_invalid_directory_handle_still_rejects_traversal ... ok
test native_modified_timestamp_and_regular_file_size_match_os_observation ... ok
test non_utf8_names_remain_native_and_carry_transformation_issues ... ok
test os_directory_listing_refuses_directory_links ... ok
test overlapping_bindings_retain_their_own_observation_and_coverage_association ... ok
test overlap_deduplicates_paths_not_hardlinks ... ok
test overlapping_bindings_validate_evidence_before_deduplicating_traversal ... ok
test precancelled_scan_records_unvisited_roots_and_progress_is_bounded ... ok
test protected_marker_and_staging_names_remain_in_listing_but_are_excluded ... ok
test partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors ... ok
test protected_roots_conservatively_match_case_aliases_at_component_boundaries ... ok
test protected_subtrees_are_excluded_when_selected_directly ... ok
test reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems ... ok
test replacing_a_listed_directory_with_an_external_link_never_observes_external_children ... ok
test scan_keeps_unique_empty_and_nonvideo_entries ... ok
test unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

     Running tests/path_codec.rs (target/debug/deps/path_codec-4d9b5506ad20490f)

running 5 tests
test path_codec_round_trips_native_units ... ok
test json_quantities_and_nanosecond_timestamps_use_validated_decimal_strings ... ok
test portable_relative_paths_reject_escape_and_native_display_is_not_lookup ... ok
test windows_utf16_fixture_is_exact_and_foreign_paths_are_not_transcoded ... ok
test all_ids_are_distinct_uuid_strings ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

Affected lint/format checks (all exit 0):

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo clippy -p vidlib-inventory --all-targets -- -D warnings
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo clippy -p vidlib-inventory --target x86_64-pc-windows-gnu --all-targets -- -D warnings
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo fmt --all -- --check
git diff --check
```

Linux Clippy:

```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on build directory
    Checking vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 1.49s

```

Windows GNU target Clippy:

```text
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on package cache
    Blocking waiting for file lock on build directory
    Checking vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 2.07s

```

Existing portable suite plus inventory (exit 0):

```sh
CARGO_HOME=/workspace/.tools/cargo RUSTUP_HOME=/workspace/.tools/rustup PATH=/workspace/.tools/cargo/bin:$PATH cargo test -p vidlib-inventory -p vidlib-engine -p vidlib-fileops
```

Final result: **63 portable tests pass**: 22 inventory behavior +5 codec/JSON +36 existing engine/fileops tests; doc tests pass. Complete output:

```text
   Compiling vidlib-inventory v0.2.0 (/workspace/VidLibOrganizer/.worktrees/rename-blueprint/crates/vidlib-inventory)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 0.56s
     Running unittests src/lib.rs (target/debug/deps/vidlib_engine-d93bfedd144350c9)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/scan.rs (target/debug/deps/scan-c76ad2f0b7e7510f)

running 14 tests
test cancellation_before_scan_preserves_cancelled_state ... ok
test directory_links_are_not_followed_or_counted_as_extra_videos ... ok
test empty_library_completes_without_issues_or_hash_work ... ok
test fast_scan_groups_exact_sizes_recursively_without_content_comparison ... ok
test invalid_roots_produce_issues_without_discarding_valid_roots ... ok
test md5_separates_same_size_collisions_and_hashes_complete_candidates_only ... ok
test missing_candidate_reports_issue_and_keeps_other_duplicate_results ... ok
test cancellation_mid_hash_stops_before_finishing_current_file ... ok
test no_roots_is_a_validation_error ... ok
test overlapping_roots_and_repeated_paths_are_counted_once ... ok
test selected_directory_link_is_reported_instead_of_followed ... ok
test modification_time_change_without_length_change_invalidates_hash ... ok
test files_changed_during_hashing_are_excluded_and_reported ... ok
test complete_hash_detects_a_difference_beyond_the_first_buffer ... ok

test result: ok. 14 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running unittests src/lib.rs (target/debug/deps/vidlib_fileops-4d310a9b5f95c519)

running 1 test
test tests::changed_source_after_validation_cleans_partial_destination ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/actions.rs (target/debug/deps/actions-b4a440a8f8447d98)

running 21 tests
test changed_modification_time_rejects_deletion ... ok
test changed_kept_copy_hash_prevents_deletion_even_with_restored_timestamp ... ok
test changed_selected_content_rejects_md5_actions_with_restored_timestamp ... ok
test empty_selection_is_rejected ... ok
test duplicate_selection_is_rejected ... ok
test deleting_a_selected_copy_keeps_the_original ... ok
test invalid_move_destination_prevents_changes ... ok
test missing_kept_copy_prevents_deletion ... ok
test missing_md5_hash_rejects_actions ... ok
test move_collision_never_overwrites_existing_file ... ok
test move_preserves_original_modification_timestamp ... ok
test move_preserves_content_and_kept_original ... ok
test move_to_source_directory_is_rejected ... ok
test selecting_every_copy_is_rejected_before_any_deletion ... ok
test size_candidates_can_be_deleted_without_content_equality ... ok
test stale_group_late_in_request_prevents_changes_to_an_earlier_group ... ok
test stale_selected_file_rejects_every_action ... ok
test symlink_source_is_rejected_without_removing_its_target ... ok
test selected_files_with_same_name_both_move_without_overwrite ... ok
test unknown_path_rejects_the_entire_request ... ok
test move_preserves_content_across_many_streaming_chunks ... ok

test result: ok. 21 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.03s

     Running unittests src/lib.rs (target/debug/deps/vidlib_inventory-8cf31c7bb3797f0b)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/inventory.rs (target/debug/deps/inventory-54d7614fdaa102a6)

running 22 tests
test explicit_files_are_supported_and_relative_grants_are_rejected ... ok
test cancellation_preserves_coverage ... ok
test failed_stat_retains_listed_child ... ok
test failed_binding_observation_drops_previously_matched_evidence ... ok
test mismatched_identity_or_invalid_directory_handle_still_rejects_traversal ... ok
test namespace_model_carries_exact_epochs_and_observed_parent_facts_without_fileops ... ok
test links_are_visible_but_never_followed ... ok
test os_directory_listing_refuses_directory_links ... ok
test native_modified_timestamp_and_regular_file_size_match_os_observation ... ok
test non_utf8_names_remain_native_and_carry_transformation_issues ... ok
test overlapping_bindings_retain_their_own_observation_and_coverage_association ... ok
test overlap_deduplicates_paths_not_hardlinks ... ok
test overlapping_bindings_validate_evidence_before_deduplicating_traversal ... ok
test precancelled_scan_records_unvisited_roots_and_progress_is_bounded ... ok
test partial_and_failed_listings_propagate_incomplete_coverage_to_ancestors ... ok
test protected_subtrees_are_excluded_when_selected_directly ... ok
test protected_marker_and_staging_names_remain_in_listing_but_are_excluded ... ok
test replacing_a_listed_directory_with_an_external_link_never_observes_external_children ... ok
test protected_roots_conservatively_match_case_aliases_at_component_boundaries ... ok
test reserved_ascii_case_variants_are_conservatively_excluded_for_unknown_filesystems ... ok
test scan_keeps_unique_empty_and_nonvideo_entries ... ok
test unavailable_directory_identity_preserves_safe_entries_with_incomplete_coverage ... ok

test result: ok. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/path_codec.rs (target/debug/deps/path_codec-4d9b5506ad20490f)

running 5 tests
test portable_relative_paths_reject_escape_and_native_display_is_not_lookup ... ok
test path_codec_round_trips_native_units ... ok
test all_ids_are_distinct_uuid_strings ... ok
test json_quantities_and_nanosecond_timestamps_use_validated_decimal_strings ... ok
test windows_utf16_fixture_is_exact_and_foreign_paths_are_not_transcoded ... ok

test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_engine

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_fileops

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests vidlib_inventory

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```

No failing Linux portable checks remain. Actual Windows runtime checks remain pending; Windows-target Clippy demonstrates compilation/linting only. Existing desktop baseline limitations and the explicitly deferred Minor overlap diagnostic attribution item remain as previously recorded.
