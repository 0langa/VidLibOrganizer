### Task 25: Recognition, markers, rebinding, and root guards

**Files:** Create `crates/vidlib-blueprint/src/identity.rs`, `crates/vidlib-blueprint/src/markers.rs`, `crates/vidlib-blueprint/tests/identity_markers.rs`; extend roots/registry queries, fileops journal policy tables and Rename protected-root namespace capture.

**Interfaces:** Implements recognize/register/rebind from 4.4. Marker actions take an explicit selected-root grant and confirmed intent. Add `Journal::upsert_root_guard(root_id, revision, native_root)` / `remove_root_guard(root_id, revision)` for an independent protected-root policy mirror; protected guards do not authorize file access.

- [ ] **Step 1 — Red:** Add `known_identity_reconnects_drive_letter`, `same_path_replacement_requires_review`, `lookalike_structure_is_only_candidate`, `copied_marker_conflicts`, `marker_only_install_has_no_history`, `no_marker_on_register_or_scan`, `readonly_marker_failure_keeps_registration`, `blueprint_db_offline_keeps_root_guards`, and `registration_revokes_plan_built_before_new_guard`.
  ```rust
  assert_eq!(decision, RecognitionDecision::CandidateNeedsConfirmation);
  assert_eq!(marker_only, RecognitionDecision::MarkerOnlyNoLocalData);
  assert!(!root.join(".vidlib-blueprint.json").exists());
  assert!(independent_rename_namespace.protected_roots.contains(&root_id));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test identity_markers`; run native ID/readonly/reparse cases on Windows.
- [ ] **Step 3 — Implement:** Evidence hierarchy and explicit binding revisions; marker strict schema/UUIDs/4 KiB limit, no links or implicit creation; distinct conflict/no-record/unknown decisions, no drive-wide search. Mirror protected root changes in operations.sqlite3 **before** committing a new Blueprint binding; retire old guards only after the binding commits. Crash/Blueprint DB failure may retain extra conservative guards, never remove required protection or globally block unrelated Rename. Reconcile pending policy updates separately from filesystem recovery. Marker filenames remain protected independently of Blueprint DB availability.
- [ ] **Step 4 — Verify green:** All identity decisions including unstable/missing share identity, file-ID reuse evidence, portable clone conflict and explicit rebind. Rebind updates evidence/freshness without inventing a media-move event; unknown markers never create active root grants.
- [ ] **Step 5 — Commit:** `feat: recognize and explicitly reconnect Blueprint collections`.

