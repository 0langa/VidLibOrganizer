# Task 18: Explicit companion association groups


**Files:** Create `crates/vidlib-rename/src/companions.rs`, `crates/vidlib-rename/tests/companions.rs`; extend recipe/model/graph and UI association DTOs.

**Interfaces:** `associate(inventory: &Inventory, selection: &[EntryId], policy: &CompanionPolicy) -> Result<AssociationSet, RenameError>` and `propagate_names(evaluated, associations)`. One asset has at most one primary; associations enter GroupIds before graph validation and cannot silently extend selection.

- [ ] **Step 1 — Red:** Add `language_and_role_suffixes_preserved`, `idx_sub_pair_is_one_dependency_group`, `two_possible_owners_require_choice`, `folder_artwork_not_assigned_automatically`, `cross_folder_requires_explicit_pair`, and `primary_only_warns_without_mutating_asset`.
  ```rust
  assert_eq!(subtitle_target, "Harbor Watch - S02E02 [1080p].en.forced.srt");
  assert_eq!(idx.group_id, sub.group_id);
  assert!(ambiguous.owner.is_none());
  assert!(!plan.selected_ids.contains(&shared_poster_id));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test companions`.
- [ ] **Step 3 — Implement:** Exact original-stem matching with explicit supported extension list from the spec; recognize retained ISO language/role suffixes without guessing a shared poster/tvshow file's owner. Manual cross-folder owner binding stays within selected grants. Derive all companions from the primary's **same** frozen name/counter, then rerun global collisions and group validation.
- [ ] **Step 4 — Verify green:** Association tests and executor fault injection failing after the first companion step; assert compensation/recovery names every affected asset and never drops unrelated files.
- [ ] **Step 5 — Commit:** `feat: preserve explicit video companion associations`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.



## Explicit numbering-scope and template Counter carry
Approved renaming spec section4: "Counter assignment uses the frozen selected primary-item vector; companions inherit their primary's result and do not consume counters. Directory numbering is a separate explicitly selected scope." Preserve this in your owned selection/association/UI/acceptance work: no implicit flattening of file/directory or companion scopes or display sorting into counter order. Task13 assign_numbers is an explicit-vector primitive with original-parent reset; use a narrow typed scope integration if needed and test mixed files/directories plus companions. Task14 unparameterized FieldKey::Counter defaults to1-based ordinal within the explicit frozen primary scope and retains explicit per-entry/per-rule frozen IntegerCounter. It does not implicitly bind to one of several configured Number rules. Report actual end-to-end scope evidence instead of claiming the intermediate primitives finish the UI workflow.


## Controller mixed-kind numbering scope ruling
Task15 mixed-kind numbering uses a narrow RecipeV1 NumberingScope::Files (serde default) or explicitly selected Directories with one frozen primary vector for the chosen kind. Number rules consume ordinals/apply only within that scope; other-kind selected rows retain their current name through that Number rule and may use other rules. Do not globally reject mixed file/directory selection, because combined parent/child preview is required. Required template Counter outside the active primary scope produces a clear missing/scope row issue unless the AST explicitly supplies fallback/optional behavior. Generic assign_numbers remains an explicit-vector primitive; Task18 removes companions from primary vectors before freezing. Reason: approved spec separates directory numbering while requiring one consistent file/parent final-path preview, and existing RecipeV1 has one numbering order. Cost if wrong: users expecting independently configured simultaneous file and directory counters in one recipe need an explicit multi-scope rule/binding extension and revised previews; schema default may require import migration. No native authority or scope is granted. Test both explicit scopes with mixed selected kinds, out-of-scope Counter, recomputation/collisions and later companions.


## Approved association scope and actual preview handoff
The renaming spec section6 states: "Companion matching initially uses exact original basename plus recognized language/role suffixes in the same folder. Supported assets include `.srt`, `.ass`, `.ssa`, `.vtt`, `.sup`, `.idx`, `.sub`, `.nfo`, `.jpg`, `.jpeg`, `.png`, and `.webp`. Recognized roles include `forced`, `sdh`, `cc`, `poster`, `fanart`, and `thumb`; retained language/role suffixes are shown in the preview. Shared `poster.jpg`, `tvshow.nfo`, and similar folder-wide files are not assigned to one video automatically." It further requires ambiguous ownership to need manual choice or unchanged warnings, at most one primary per asset, explicit cross-folder bindings within selected roots, visible primary-only warnings, and no propagation to unselected assets. Preserve exact suffix spelling/bytes for supported Unicode names.

Integrate associations into actual legacy and ordered-recipe desktop preparation, not only standalone helpers: selection/explicit associations precede primary numbering and requested input freezing; primary rules evaluate once, then companions derive from that same fully evaluated primary result. Keep all selected rows in collision/preflight and explicit same-GroupId dependency lineage. Unknown/unselected entry IDs and unauthorized manual cross-folder pairs fail closed; stored recipe IDs are data, not grants. Command envelope DTOs remain strict camelCase around the portable core RecipeV1 representation. Add necessary narrow fileops executor fault tests under the existing journal/receipt/compensation contracts; copying and metadata mutations are later tasks. Windows fault execution remains pending if not runnable, while portable real-filesystem fault fixtures must run here.

Task17 adds actual requested metadata producer, provenance and bounded offline helper input pinning. Read final reviewed Task17 report before dispatch implementation; do not revert those changes or move I/O into evaluation. Full visual association controls remain Task21; this task owns functioning association policy/bindings and actual preview/graph DTO wiring.


## Controller association-policy ruling
Ruling: Task18 adds opt-in CompanionPolicy::MatchExact { associations } for automatic exact original-stem/language-role matching plus explicit ownership overrides. Existing Explicit remains manual-only and None disables propagation. With None, deliberately selected rows remain independent rename inputs; only-video selection warns about matching unselected related assets and leaves those assets untouched. Under MatchExact, unresolved potential companion ownership leaves the asset unchanged with a warning until explicit binding. Matching never extends selection or creates native grants; resolve ownership before validating/freezing the primary numbering/input vector and globally preflight all selected rows. Reason: the initial AST has only None and Explicit, while the approved spec requires both exact matching and manual ownership choices; a separate opt-in variant preserves existing recipe meanings. Cost if wrong: users/presets expecting automatic matching from the old Explicit policy must choose MatchExact and obtain a new preview, and future readers need the additive variant; choosing independent None can intentionally produce association-break warnings. No mutation authority or hidden extra selected assets result.
