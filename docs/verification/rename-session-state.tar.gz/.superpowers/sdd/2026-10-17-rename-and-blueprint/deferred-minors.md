# Deferred review findings index

Controller process index; progress.md and the original reviews remain authoritative. This is not another implementation plan. Final whole-branch review must triage every open item; Task32 retains dispositions outside this cleanup workspace. Do not call an item fixed from code presence alone. Native Windows qualifications stay separate.

| ID | Origin | Issue / current disposition | Owner / evidence needed |
| --- | --- | --- | --- |
| 01 | Task01 | Overlapping-root diagnostic relative paths need rebasing; pending. | Final branch triage; preserve per-binding coverage/native authority. |
| 02 | Task02 | Windows staging writer has write/delete access while publish/remove opens use FILE_SHARE_READ. Writer must close after verified flush and before publication/cleanup, or held ownership handle be consumed. Implementation and portable lifecycle regression ADDRESSED Task19; native Windows qualification pending. | Full Task19 review/rereview approved453d404+b9b9b38, writer closes before reread/publication/cleanup; portable descriptor regression and Windows fixture compilation pass. Actual Windows sharing runtime remains pending and is not inferred. |
| 03 | Task03 | Duplicate plan/provenance grants consistency. RESOLVED Task06. | Existing checked grant publication validation/review evidence in Task06. |
| 04 | Task10 | Inventory kind wire uses Debug File/Directory versus expected camelCase; pending. | Strict desktop DTO + shared literal golden/browser fixture in final triage or naturally relevant UI work. |
| 05 | Task10 | ui/api.js and dom.js listed without corresponding task hunks; existing behavior independently verified. Pending canonical scope reconciliation. | Final docs reconcile actual later owned changes; do not add gratuitous helpers to satisfy a filename list. |
| 06 | Task10 | Compressed UI orchestration/tests reduce maintainability; some incidental formatting later, remainder pending. | Final whole-branch triage of actual remaining code; original task10-review.md. |
| 07 | Task11 | Initial dotted capital I in title/sentence transforms may become decomposed I+combining dot instead of composed spelling. Pending. | Unicode filename byte golden and narrow preservation decision/fix; do not add normalization to all names. |
| 08 | Task13 | RFC3339 fractions beyond nine digits silently truncate significant nonzero precision. Pending. | Reject significant loss or explicit documented policy, include trailing-zero acceptance regression. |
| 09 | Task14 | Retained/output vector and primary-position scans make frozen preparation quadratic. Pending. | Temporary keyed indexes/ordinal map preserving order/serialization; Task23 scale evidence also relevant. |
| 10 | Task15 | Inherited NO_COLOR/FORCE_COLOR browser warning. RESOLVED necessary Task15 clean UI run. | Use env -u NO_COLOR for later necessary UI checks; old warning log remains historical. |
| 11 | Task17 | vendor_media_info.py archive hydration may download a missing supplementary notice without --fetch. Pending; runtime offline unaffected. | Explicit fetch guard/actionable missing-notice error; focused downloader-not-called test. |
| 12 | Task18 | User Rule.id companion_warning can masquerade as a generated warning because DTO filters explanations by string sentinel. Pending; presentation only. | Typed/separate warning data or validated reserved namespace, narrow DTO regression; independent of Task19 destination frozen-owner correctness fix. |

Task19 destination-owner integration concern RESOLVED: typed FrozenScope Rule(default)/Destination separates adversarial user IDs and generated layout values; scoped shared-hash computation and missing choices fixed in reviewed round1. No new deferred minor was raised in Task19.

As of this index, Tasks01-19 portable implementations reviewed; Task20 next. No whole-release or native Windows completion is claimed.
| 13 | Task20 | Equal-value directory timestamp Set is always retained, even without child/path effects, producing false Changed/effects/summary. Pending final Rename phase triage. | metadata.rs:441/479; condition preservation on relevant planned effects while retaining Ruling17 direct/nested-child finalization. Add empty-directory equal-Set no-effect regression if fixed. |

| 14 | Task21 M1 | Page projection repeatedly scans full inventory and execution steps for each of200 rows, increasing large-plan latency; pending final Rename phase triage. | src-tauri/src/commands/rename.rs:1047/1120 in589087f; per-snapshot/page keyed lookup preserving exact native authorization, Task23 representative scale evidence. |

Task21 M2 extends existing06: new dense editor/selection/template handlers remain finaltriage, with root/task21review references in task-21-review.md. Actual inventory-kind casing defect04 has code+native regression and independent review support; broader literal-golden/canonical closure still pending root reconciliation.

| 15 | Task22 M1 | Successful automatic native-selection retry hides discard but leaves this flow's stale waiting/error notice; pending final Rename phase triage. | ui/main.js:229/237/241 atfdccde7; clear/replace only pending-selection-owned notice on successful acceptance/null pending, retain unrelated messages; busy→success retry browser transition. |

| 16 | Task23 M1 | Metadata-tail cancellation regression waits for throttled partial progress and depends on machine speed/thread scheduling; pending broad Rename phase triage. | crates/vidlib-rename/src/metadata.rs:738 at a5bfc51, shared control.rs:63; deterministic positive-row checkpoint/handshake and cancellation, with throttle coverage separate. No production cancellation defect or failing run was found. |
