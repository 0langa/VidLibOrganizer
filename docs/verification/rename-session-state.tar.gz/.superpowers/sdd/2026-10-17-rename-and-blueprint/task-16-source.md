### Task 16: Presets and the single recipe editor

**Files:** Create `crates/vidlib-rename/src/presets.rs`, `crates/vidlib-rename/tests/presets.rs`, `src-tauri/src/rename_preferences.rs`, `ui/recipe/editor.js`, `ui/recipe/history.js`, `ui/recipe/fields.js`, `tests/ui/recipe-editor.spec.mjs`; extend commands/app state.

**Interfaces:** `PresetStore::load/save_revision/import/export`; PresetId with immutable revision/RecipeV1 snapshot, app-local durable save. Implements createRecipeEditor from 4.4 plus edit undo/redo. Blueprint later embeds this same editor without evaluating names in JS.

- [ ] **Step 1 — Red:** Add `recipe_round_trip_and_version_rejection`, `failed_save_preserves_previous`, `import_limits_and_rule_count`, `edit_undo_redo_is_not_filesystem_undo`; browser test reorder/repeat/disable rules and restore the same serialized recipe.
  ```rust
  assert_eq!(reloaded.recipe, original.recipe);
  assert_eq!(too_many_rules.code, RenameErrorCode::ImportLimit);
  assert_eq!(active_revision, old_revision); // failed save cannot replace it
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test presets`; `npx playwright test tests/ui/recipe-editor.spec.mjs`.
- [ ] **Step 3 — Implement:** 1 MiB/100-rule validation, revisioned presets, atomic persistence through create-new temp+flush+safe replacement of the **app-owned** preset record (never a media target), exact recipe import/export, common editor lifecycle and undo/redo state. Exported recipe data grants no access and carries no executable operations.
- [ ] **Step 4 — Verify green:** Preset/browser tests and reproduced preview goldens from saved recipes; edited presets create new revisions rather than mutate attached snapshots.
- [ ] **Step 5 — Commit:** `feat: add versioned presets and shared recipe editing`.

