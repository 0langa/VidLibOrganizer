### Task 26: Coverage-aware refresh and truthful changes

**Files:** Create `crates/vidlib-blueprint/src/refresh.rs`, `crates/vidlib-blueprint/src/diff.rs`, `crates/vidlib-blueprint/tests/refresh.rs`, `crates/vidlib-blueprint/tests/diff.rs`; extend store/query.

**Interfaces:** Implements begin_refresh/stage_inventory/promote_refresh from 4.4 and ChangeDto. RefreshOutcome is Complete/Partial/Cancelled/Offline/Failed; origins are App or ExternalOrUnknown. A comparison uses matching root/binding/filter scope and observation intervals, not wall-clock claims about external actions.

- [ ] **Step 1 — Red:** Add `first_and_newly_covered_scope_are_baselines`, `partial_refresh_keeps_unobserved_entries`, `stat_failure_after_listing_is_not_missing`, `offline_root_is_not_mass_deletion`, `hardlinks_do_not_force_relocation`, `directory_move_is_expandable_only_with_evidence`, and `multi_root_times_are_independent`.
  ```rust
  assert_eq!(first.added_count, 0);
  assert_eq!(first.baseline_count, 1);
  assert_eq!(offline.missing_count, 0);
  assert!(current.contains_path(&listed_but_unstatted_child));
  assert_ne!(summary.last_attempt, summary.last_complete_observation);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-blueprint --test refresh --test diff`.
- [ ] **Step 3 — Implement:** Stage attempts separately; transactionally promote successful scopes and history while retaining old observations for unreadable/excluded/cancelled scopes. Determine Missing from complete parent enumeration **and listed child names**, not missing metadata rows. First coverage/filter-policy changes establish baselines. LocationChanged requires unambiguous consistent physical evidence; weak relocation links preserve Added/Missing facts. Group directory changes while retaining queryable descendants. Store observed intervals and separate last-attempt/per-scope last-complete times.
- [ ] **Step 4 — Verify green:** Real fixture refreshes before/after external add/remove/rename/metadata changes; injected failed stat/listing/cancel, duplicate physical IDs, root replacement, exclusion changes, and DB promotion rollback. Pattern denominators cannot include retained-but-unobserved stale entries as freshly examined.
- [ ] **Step 5 — Commit:** `feat: compare Blueprint observations with explicit coverage`.

