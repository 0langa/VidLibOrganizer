# Task 15: Selection filters, mappings, overrides, and exports


**Files:** Create `crates/vidlib-rename/src/selection.rs`, `crates/vidlib-rename/src/mappings.rs`, `crates/vidlib-rename/tests/selection_mappings.rs`; extend DTOs/evaluate; use a bounded CSV parser rather than split-on-comma.

**Interfaces:** `select(inventory: &Inventory, filter: &SelectionFilter) -> Result<Vec<EntryId>, RenameError>`; `import_mappings(reader, format, inventory, grants) -> Result<MappingSet, RenameError>`; `export_report(plan, SpreadsheetSafe | ExactMapping) -> Result<Vec<u8>, RenameError>`. Explicit mapping format v1 has `old_path,new_path` with quoted CSV or a user-selected delimiter; exact path lookup precedes unique-basename fallback. Pasted new-name lists map the frozen explicit order and require exact cardinality.

- [ ] **Step 1 — Red:** Add `every_filter_dimension`, `exclude_rebuilds_numbers_and_collisions`, `ambiguous_basename_and_outside_root_rejected`, `quoted_csv_and_paste_cardinality`, `mapping_limits_before_allocation`, and `spreadsheet_safe_export_does_not_change_recorded_path`.
  ```rust
  assert_eq!(err.code, RenameErrorCode::AmbiguousMapping);
  assert_eq!(limit_error.code, RenameErrorCode::ImportLimit);
  assert_eq!(stored_original_name, "=SUM(1,2).mkv");
  assert!(spreadsheet_cell.starts_with('\''));
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-rename --test selection_mappings`.
- [ ] **Step 3 — Implement:** Wildcard/PCRE2 filters across every R11 field, depth/kind/extension/date/size/attribute selection, exact path mapping, explicit row override, 64 MiB/100,000-row streaming limits and safe reports. Reject traversal/duplicate mappings and unknown IDs. Distinguish spreadsheet-safe reports from lossless mapping exports so protection prefixes never accidentally become renamed filenames.
- [ ] **Step 4 — Verify green:** Boundary tests at/above byte/row limits and quoted Unicode/multiline CSV; all-row preflight after selection changes. Formula-like input is literal data and never executed.
- [ ] **Step 5 — Commit:** `feat: add bounded selection mappings and report workflows`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.



## Explicit numbering-scope and template Counter carry
Approved renaming spec section4: "Counter assignment uses the frozen selected primary-item vector; companions inherit their primary's result and do not consume counters. Directory numbering is a separate explicitly selected scope." Preserve this in your owned selection/association/UI/acceptance work: no implicit flattening of file/directory or companion scopes or display sorting into counter order. Task13 assign_numbers is an explicit-vector primitive with original-parent reset; use a narrow typed scope integration if needed and test mixed files/directories plus companions. Task14 unparameterized FieldKey::Counter defaults to1-based ordinal within the explicit frozen primary scope and retains explicit per-entry/per-rule frozen IntegerCounter. It does not implicitly bind to one of several configured Number rules. Report actual end-to-end scope evidence instead of claiming the intermediate primitives finish the UI workflow.

## Task14 input-preparation handoff
Task14 provides InputRequirements::{from_recipe}, freeze_inputs, and FrozenInputCache::{from_inputs,prepare,regenerate} in vidlib-rename. Read their current signatures before integration. Requirements take an explicitly supplied primary_order; cached UUID/random values remain per inventory/entry/rule across temporary selection/rule removal and hashes recheck source freshness. Default Counter ordinals recompute for changed primary vectors; explicit frozen Integer overrides remain. No content reads in pure evaluate/select/mapping parsing. Desktop RenameState now retains a separate cache Arc per inventory lifecycle and NamingRule has typed Template{parts}. Preserve revocation/publication checks when adding owned selection/override preparation; do not silently derive primary order from display sorting or mix directory/file/companion scopes. Full UI controls remain Task21, associations Task18.

Use CARGO_INCREMENTAL=0 for final checks to contain derived-build disk usage. Task14 recovered ENOSPC by deleting stopped incremental caches only; product/evidence preserved. Actual GNU desktop cross-check is infrastructure-pending at tauri-winres: missing unqualified x86_64-w64-mingw32-gcc (gcc-posix installed), while core Windows executables linked. Record pending honestly and avoid unrelated toolchain repair.


## Controller mixed-kind numbering scope ruling
Task15 mixed-kind numbering uses a narrow RecipeV1 NumberingScope::Files (serde default) or explicitly selected Directories with one frozen primary vector for the chosen kind. Number rules consume ordinals/apply only within that scope; other-kind selected rows retain their current name through that Number rule and may use other rules. Do not globally reject mixed file/directory selection, because combined parent/child preview is required. Required template Counter outside the active primary scope produces a clear missing/scope row issue unless the AST explicitly supplies fallback/optional behavior. Generic assign_numbers remains an explicit-vector primitive; Task18 removes companions from primary vectors before freezing. Reason: approved spec separates directory numbering while requiring one consistent file/parent final-path preview, and existing RecipeV1 has one numbering order. Cost if wrong: users expecting independently configured simultaneous file and directory counters in one recipe need an explicit multi-scope rule/binding extension and revised previews; schema default may require import migration. No native authority or scope is granted. Test both explicit scopes with mixed selected kinds, out-of-scope Counter, recomputation/collisions and later companions.
