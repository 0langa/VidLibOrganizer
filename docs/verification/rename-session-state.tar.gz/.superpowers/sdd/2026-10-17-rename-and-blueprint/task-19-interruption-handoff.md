# Task19 continuation after environment refresh

Root observed collaboration.list_agents returns only /root after environment_context refresh; original /root/task19_copy_move is absent. No active cargo/rustc/test build was visible in process-name snapshot. Do not infer it is running or dispatch concurrent writers. Files/tools/worktree persist. Current HEAD remains65b2b58, all working changes are interrupted Task19 work; no final report/commit/review exists. Preserve every existing edit/log.

Read task-19-brief.md and implementer-contract.md; follow the same full task and official SDD/TDD scope. Rulings9/10/11 are ALREADY RECORDED in brief/progress: additive CreateStaging/WriteStaging with actual durable ownership before stream and checked protocol; explicit CopyTo/MoveTo+typedlayout while legacyGranted stays readable but rejected; ordered one-to-many inverse effect lineage for actual cross-volume copy-back/owned cleanup, original facts immutable, full-chain completion/identity/digest gates. No need to re-decide approved choices.

Existing task19-logs:
- red-copy.log: actual copy_digest_and_metadata_verified fails old Unsupported non-RenameEntry; initial unused-test-import warnings retained as scaffold stage, not finalclean claim.
- red-protocol-api.log missinginterfaces (notbehavior). red-protocol-behavior.log same realUnsupported after newactionscompile.
- copy-first.log1/1 realcopydigestmetadata green.
- red-layout-api.log setup;red-layout-behavior.log behavioral;layout-first.log2/2 copy+folderlayout.
- red-move-resume.log behavioral;move-resume-first.log4/4 copy/layout/crossvolumeverifiedpublish-before-removal/partialownedstagingResume. No broad/static/Windows/final claim; logs must be assessed against current code.

21 modified trackedfiles+new copy.rs/copy_move.rs/destination.rs currently exist (gitstatus authoritative),includingCargo.lock,models/nativeplatform/journal/recovery/graph/evaluate/inputprep scaffolds. You must inspect uncommitted changes and current tests, continue rather than reset/reimplement. Last worker was evaluating recovery schema cardinality; Ruling11 already authorizes needed checked multi-effect migration. Some additions may be scaffolds; four initial greens do not complete task.

Remaining full task requirements include durable checked migration/codecs/lineage; full actual Resume/Restore/CopyUndo/MoveUndo with identity+freshfullSHA256 and owned-directory cleanup; compiled quarantines/no unknown deletions; cancellation/faults and actual subprocess phase crash matrix; full destination modes/layout/grants + real legacy/ordered desktop pipeline; native writer closure/minor02 regression; finalbroader tests/static/Windowscompilechecks, report and commit. Inspect requirements individually, do not assume items absent/present from this list. Full UI controls21, metadata mutation20, native Windows/runtime/install/hardwarepending/gatesclosed.

Current cloud environment_status24: running connected observationscurrent, unrestricted/enforced HTTP, no configuredsecrets/runtimevariables/outboundidentities. Runtime skill c14/cloud-environment-runtime now available and rootread; fetch networkingreference/policy onlyifnetworkwork. Preserve proxy/CA. SharedLinux /workspace/.tools/desktop-target CARGO_INCREMENTAL=0; Windowsseparatetarget/sourcewindows-check-env.sh. Sources/tools/past evidence preserved.
