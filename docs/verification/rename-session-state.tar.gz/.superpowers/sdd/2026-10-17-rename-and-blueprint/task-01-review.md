### Spec Compliance

- ❌ Issues found: the inventory surface, required crate/files, exact path/number encodings, entry preservation and coverage are implemented, but no-follow traversal, protected-name handling on Windows, and evidence handling for overlapping bindings have Important correctness gaps listed below.
- ⚠️ Cannot verify from diff: actual Windows runtime behavior remains pending. The report accurately distinguishes Linux execution/portable UTF-16 fixture coverage and Windows compilation/Clippy from execution (`.superpowers/sdd/2026-10-17-rename-and-blueprint/task-01-report.md:254`, `.superpowers/sdd/2026-10-17-rename-and-blueprint/task-01-report.md:419`). The controller must retain Windows reparse, identity, native UTF-16 and filesystem behavior checks as outstanding; no Windows runtime success is established here.
- ⚠️ Cannot verify from diff: complete offline Windows release behavior and later Rename/Blueprint, journal, import, planner and mutation requirements span other tasks. This commit correctly presents a read-only inventory slice, not a completed release (`crates/vidlib-inventory/src/lib.rs:1`).

### Strengths

- Native path units remain separate from display strings; foreign-platform decoding fails explicitly, absolute lookup paths are skipped in JSON, and relative paths are validated (`crates/vidlib-inventory/src/path.rs:61`, `crates/vidlib-inventory/src/path.rs:91`, `crates/vidlib-inventory/src/model.rs:57`, `crates/vidlib-inventory/src/scan.rs:417`).
- Exact decimal adapters reject numeric JSON, noncanonical representations and overflow; boundary cases exercise real serialization behavior (`crates/vidlib-inventory/src/exact.rs:6`, `crates/vidlib-inventory/tests/path_codec.rs:84`).
- Enumeration preserves listed names before stat, retains unknown entries after stat errors, propagates incomplete/cancelled subtree coverage, and keeps hard-link paths distinct (`crates/vidlib-inventory/src/scan.rs:264`, `crates/vidlib-inventory/src/scan.rs:357`, `crates/vidlib-inventory/tests/inventory.rs:41`).
- Required file ownership/dependency direction is respected; the small exact-number and job-control helpers have clear responsibilities (`crates/vidlib-inventory/Cargo.toml:7`, `crates/vidlib-inventory/src/lib.rs:6`). Tests use disposable real directories with a narrow read-only failure seam (`crates/vidlib-inventory/tests/support/mod.rs:18`, `crates/vidlib-inventory/tests/support/mod.rs:50`).

### Issues

#### Critical (Must Fix)

- None found.

#### Important (Should Fix)

1. **Keep child lookup anchored to the directory that was enumerated.** `crates/vidlib-inventory/src/scan.rs:297`–`308` constructs absolute child paths and performs fresh path-based stat/recursion after `read_directory` has returned and closed its directory handle (`crates/vidlib-inventory/src/platform/unix.rs:19`–`38`; Windows has the same handle lifetime). If an observed directory is renamed and replaced by a link between listing and child stat, `symlink_metadata(directory/child)` follows the link in the intermediate component. A directory child can then be recursively opened through that linked ancestor even though the final component passes `O_NOFOLLOW`/reparse validation. The resulting entries can come from outside the observed tree and coverage can still be marked complete. Rejecting final-component links does not meet “Child traversal never follows a link/reparse point” for this sequence. Carry directory handles through child stat/open using native relative operations, or fail coverage whenever live directory/ancestor identity cannot be kept consistent. Add a deterministic seam test that swaps a listed directory to an external link before the next child observation, and assert no external entries and incomplete coverage.

2. **Honor Windows namespace case behavior when excluding reserved entries.** `crates/vidlib-inventory/src/model.rs:287`, `:295` and `:300`–`302` compare protected roots, marker names and staging prefixes by exact case-sensitive native units. On an ordinary case-insensitive Windows directory, selecting `C:\media\.VIDLIB-BLUEPRINT.JSON` addresses the existing `.vidlib-blueprint.json`, but this policy permits it into the inventory; case variants of staging directories likewise permit their descendants to be scanned. The policy is also advertised as the canonical exclusion surface for later operation adapters, so the bypass would propagate. Apply filesystem-appropriate native name comparison (conservatively protect reserved ASCII case variants where case behavior is unknown), including protected-root matching, while preserving native path ownership. Add Windows case-variant marker/staging/direct-selection tests. This is a static correctness finding; Windows runtime verification remains pending.

3. **Validate every requested binding before deduplicating traversal.** `crates/vidlib-inventory/src/scan.rs:103`–`107` skips already-seen overlapping roots before the evidence comparison at `:126`–`146`. For requests containing `/media` and `/media/nested`, the shallow root populates `seen_entries`/`seen_directories`, so a nested binding with an incorrect `expected_identity` is returned unchanged without an `EvidenceMismatch` issue. A previously `Matches` binding can retain that stale state without any new observation. This breaks the contract that a binding records evidence absence separately from mismatch and makes evidence correctness depend on whether another root overlaps it. Observe/check each binding independently, then deduplicate entry traversal; retain explicit evidence and coverage association for skipped bindings. Add a test with a parent grant plus a nested grant carrying deliberately wrong expected identity, and verify the nested binding reports mismatch without duplicating entries.

#### Minor (Nice to Have)

- None.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The data model, exact encodings and failure-aware coverage are well separated and meaningfully tested. The three gaps affect which filesystem entries and root evidence the snapshot represents, so they should be resolved before this foundation is trusted by planning and Blueprint consumers.

**Checks:** Read the supplied brief, report, reviewer contract/template and full `786c2a4..d734f55` diff package. No suite reruns, checkout/index/HEAD changes, extra source-file reads, cross-interface expansion or subagents. Re-read only the initially truncated report/brief portions and extracted line references from the supplied diff. Reported final scoped tests/Clippy are clean; the reported initial workspace failure is explicitly left unresolved with controller-supplied baseline context, not represented as a passing desktop check.
