### Task 01: Native-path inventory and coverage

**Files:** Create the `crates/vidlib-inventory` files listed in section 3, `crates/vidlib-inventory/tests/support/mod.rs`, `crates/vidlib-inventory/tests/inventory.rs`, `crates/vidlib-inventory/tests/path_codec.rs`; modify root `Cargo.toml`/`Cargo.lock`.

**Interfaces:** Produces IDs, native path codec, FileStamp/RootBinding/Inventory/ScopeCoverage/JobControl and `scan` from 4.1; no dependency on Rename or Blueprint. Tests use actual temporary directories and a read-only OS adapter seam for injected stat/listing failures.

- [ ] **Step 1 — Red:** Add `scan_keeps_unique_empty_and_nonvideo_entries`, `overlap_deduplicates_paths_not_hardlinks`, `failed_stat_retains_listed_child`, `path_codec_round_trips_native_units`, and `cancellation_preserves_coverage`. Fixture has `a.mkv`, zero-byte `b.mp4`, `notes.txt`, a nested directory, overlap, a link, and two hard-link paths. Required assertions:
  ```rust
  assert!(inventory.entries.iter().any(|e| e.display_name == "b.mp4"));
  assert_eq!(hardlink_entries.len(), 2);
  assert!(!failed_scope.subtree_complete);
  assert!(failed_scope.listed_names.contains(&failed_name));
  assert_eq!(decode_path(&encode_path(&native_path))?, native_path);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-inventory --test inventory --test path_codec`; it must fail because the public inventory contract is missing, not because a test touched a user directory.
- [ ] **Step 3 — Implement:** Add workspace member, serde/uuid/walkdir dependencies and the 4.1 interface; native timestamp precision, no-follow traversal, per-directory coverage, read-only volume/file identity adapters, protected marker/staging exclusions. Supply deterministic injected cancellation/failure fixture support. JSON exact-number/path tests belong here.
- [ ] **Step 4 — Verify green:** Same command, then `cargo clippy -p vidlib-inventory --all-targets -- -D warnings`. Exercise non-UTF8 Unix bytes and Windows UTF-16 fixture paths; report unsupported transformations without lossy lookup.
- [ ] **Step 5 — Commit:** `feat: add native-path collection inventory`. Include only this crate and required workspace/lock changes.

