### Task 08: Crash reconciliation and group compensation

**Files:** Create `crates/vidlib-fileops/src/recovery.rs`, `crates/vidlib-fileops/tests/recovery.rs`, `crates/vidlib-fileops/tests/support/crash_child.rs`; extend journal schema/state transitions as versioned migrations.

**Interfaces:** Produces reconcile/apply_recovery/RecoveryPreview from 4.3. Recovery uses compiled journal steps and verified identities, not rerun recipe evaluation. Destructive recovery requires an exclusive Recovery lease and reviewed nonce.

- [ ] **Step 1 — Red:** Add `crash_before_and_after_each_phase_reconciles`, `temporary_names_are_reported`, `unknown_target_prevents_blind_resume`, `compensation_stops_without_deleting_unowned_entries`, and `published_phase_without_receipt_is_reconciled_once`.
  ```rust
  assert_eq!(second_reconcile.actions, first_reconcile.actions);
  assert!(unowned_target.exists());
  assert_eq!(preview.unresolved_groups.len(), 1);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test recovery`; crash fixtures terminate a child process, not just return a mocked Result.
- [ ] **Step 3 — Implement:** Reconcile expected pre/post/current paths and identities at every intent/action/receipt gap. Generate reviewable Resume/Restore plans, stop further groups after a runtime failure, compensate only verified current-group entries, and retain explicit unresolved ownership. Reconnection and retries cannot silently repeat a completed filesystem step.
- [ ] **Step 4 — Verify green:** Run recovery tests for file/folder cycles and a lost drive fixture. Assert complete preservation/reporting after every failpoint and no writes before journal durability. Extend these same tests in Tasks 19/20 for new step kinds.
- [ ] **Step 5 — Commit:** `feat: reconcile interrupted operations and compensate groups`.

