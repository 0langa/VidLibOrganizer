### Task 22: Native multi-selection, drop, and Explorer entry

**Files:** Create `src-tauri/src/entrypoint.rs`, `src-tauri/installer/hooks.nsh`, `src-tauri/tests/entrypoint.rs`, `tests/ui/native-selection.spec.mjs`; extend selection/commands, tauri.conf.json/capabilities and UI source selection.

**Interfaces:** select_sources accepts Files/Folders/LibraryRoots; entrypoint parses a path argument list into inactive backend grants and opens review. Optional installer-controlled Explorer integration uses arguments directly, not a shell script; uninstall removes only app-owned registrations.

- [ ] **Step 1 — Red:** Add `native_picker_preserves_paths`, `explorer_arguments_select_without_applying`, `multiple_instances_forward_selection_safely`, `malicious_quoted_path_is_data`, `cancelled_picker_changes_nothing`, and keyboard/drop fixtures.
  ```rust
  assert_eq!(selected_native_paths, expected_os_paths);
  assert_eq!(mutation_calls, 0);
  assert!(!selection.applied);
  ```
- [ ] **Step 2 — Verify red:** Windows desktop entrypoint tests and `npx playwright test tests/ui/native-selection.spec.mjs`.
- [ ] **Step 3 — Implement:** Native rfd multi-selection with no to_string_lossy round-trip, Tauri native drop paths resolved on Rust side, explicit argument framing/validation and optional opt-in Explorer registration. A second instance forwards only selection to the active app or presents it after acquiring the coordinator; never accepts an apply command from process arguments. Keep capabilities narrowly scoped and local CSP intact.
- [ ] **Step 4 — Verify green:** Windows Explorer right-click/multi-file/Unicode/UNC/cancel smoke tests and uninstall registry cleanup; record actual evidence, not just a parsed argument unit test.
- [ ] **Step 5 — Commit:** `feat: add native collection selection and Explorer entry`.

