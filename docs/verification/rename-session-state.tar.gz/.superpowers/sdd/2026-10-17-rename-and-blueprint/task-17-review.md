### Spec Compliance

- ✅ Spec compliant for the Task 17 implementation slice. The supplied `7e84360..593405aef87195a2b6e680f747049455b42716c8` diff implements the listed files, typed producer/cache, actual legacy and ordered preview preparation, bundled Windows x64 resource, and controller-authorized read-only helper handoff. No media mutation or blind source-path fallback was introduced. References: `crates/vidlib-rename/src/metadata.rs:123`, `src-tauri/src/commands/rename.rs:599`, `crates/vidlib-inventory/src/content.rs:59`, `src-tauri/tauri.conf.json:24`.
- ⚠️ Native Windows helper/COM execution, Windows sharing and Job Object behavior, MSVC packaging, NSIS installation/offline resource resolution, and actual NTFS/exFAT/UNC qualification remain pending. The supplied Windows logs show GNU compilation/linking, not execution. Resource staging in `src-tauri/tests/metadata_helper.rs:247` does not establish installer behavior. These remain the expressly deferred platform/release gates, not blockers invented for this intermediate task.
- ⚠️ Complete Task 21 inspector/control flows and Task 23 release qualification are outside this review; this approval does not declare the complete Rename or Blueprint release finished.

### Strengths

- **The helper consumes the held selected source.** `crates/vidlib-inventory/src/content.rs:59` routes the synchronous callback through the existing grant/material/ancestry verifier. Linux supplies the checked parent proc-fd alias at `crates/vidlib-inventory/src/platform/unix.rs:49`. Windows source handles deny write/delete sharing while directory handles deny delete only (`crates/vidlib-inventory/src/platform/windows.rs:82`, `:114`, `:137`). The held chain survives callback completion and the existing postchecks. `src-tauri/tests/metadata_helper.rs:322` exercises actual MediaInfo consumption during a restored path swap; its recorded red returns “Forged fixture,” and its green returns the selected “VidLib fixture.”
- **Production integration uses the existing worker and native authority.** `src-tauri/src/commands/rename.rs:528` clones the provider handle, and `:599` prepares the actual recipe requirements before pure evaluation. `src-tauri/tests/command_contracts.rs:1570` covers both legacy and ordered preview paths, unknown-zone rejection, and an explicit recording-date timezone assumption.
- **Cache keys preserve exact paths and material evidence.** `crates/vidlib-rename/src/metadata.rs:95` includes physical identity, native path, size, mtime, provider version, and the requested field set. Preparation revalidates native authority even on hits, retains successful cache state on cancellation, retries error records, and preserves explicit fallback/optional choices and unrelated generated values (`:123`). Tests cover hard-link aliases, absent identity refusal, material/version/field changes, and cancellation.
- **Subprocess supervision and typed parsing are substantive.** `src-tauri/src/metadata.rs:56` directly spawns an absolute executable, caps output, concurrently drains pipes, polls cancellation/deadline, and kills/waits; `:227` shares drive/volume slots across providers, and `:296` supplies a shared ten-second budget. `:616` parses requested normalized fields without floating-point conversion; `:756` preserves canonical property types and exact FILETIME units. `:832` owns COM and clears PROPVARIANT values on the isolated helper thread, entered before Tauri setup at `:962`.
- **Timezone/provenance handling remains explicit.** The producer retains civil recording times with unknown timezone; the evaluator rejects invalid/nested metadata wrappers (`crates/vidlib-rename/src/evaluate.rs:379`). Missing/error issues retain provider/version/source evidence, and explicit optional/fallback behavior remains usable (`crates/vidlib-rename/src/metadata.rs:258`, `crates/vidlib-rename/src/template.rs:48`).
- **Packaging is pinned and offline at runtime.** `tools/media-info-manifest.json:8` identifies the official versioned x64 archive and exact hashes; executable and redistribution notices are committed resources. Runtime configuration selects only the resource path and verifies the executable hash (`src-tauri/src/metadata.rs:374`, `:534`). The Python script and FFmpeg fixture generation remain developer tools, outside packaged UI.

### Issues

#### Critical (Must Fix)

- None found.

#### Important (Should Fix)

- None found within this task's implementation scope.

#### Minor (Nice to Have)

- **`tools/vendor_media_info.py:56`: archive hydration can unexpectedly access the network without `--fetch`.** When `--archive` is supplied and a supplementary notice is missing, the common hydration branch invokes `fetch_bytes` regardless of the `fetch` flag. This conflicts with the documented explicit-fetch/offline-archive workflow and makes an archive-based rebuild unexpectedly depend on network access. Require `fetch=True` before downloading missing notices; otherwise return an actionable missing-notice error. Add a focused test asserting that archive hydration with a missing notice never calls the downloader unless fetch was explicitly selected. Runtime offline behavior is unaffected.

### Evidence and Review Boundaries

- Read the complete 4,298-line supplied diff package once, in consecutive chunks. No independently derived Git diff, suite rerun, checkout/index/HEAD mutation, or subagent dispatch was performed.
- Two focused context checks resolved cut-off hunks: `crates/vidlib-inventory/src/content.rs:90` onward to verify grant/ancestry checks and retained handle lifetime, and `crates/vidlib-rename/src/hashes.rs:90` onward to verify the new wrapper's assumptions about validated IDs, retained frozen values, and publication. These were targeted function sections, not whole-file rereads or a broader codebase crawl.
- Inspected supplied `task17-logs/red-path-handoff.log` and `green-path-handoff.log`, and final affected-test, Clippy, Windows-link, inventory-final, and vendor logs. Final owning results total 267 harness passes including the existing repeated isolated-regex test, consistent with 266 distinct tests. The final inventory-only log reports 11 passes. Owning Linux and Windows Clippy logs finish cleanly; Windows integration binaries are linked only. Vendor evidence records eight verified resources and three passing tests. No final warnings/errors appeared in the inspected logs.
- The earlier reported 455-test workspace and 28-test UI runs predate the source-handoff fix and were not treated as final-tree qualification. The intentionally ignored `helper_fixture` is explicitly invoked by bounded parent tests (`src-tauri/tests/metadata_helper.rs:37`), not a skipped functional acceptance test.

### Assessment

**Task quality: Approved**, with one minor tooling correction suggested and the expressly pending platform gates retained.

**Reasoning:** The implementation connects real metadata production to both preview paths while retaining native source authority, exact typed evidence, and transactional cache behavior. The source-swap regression and final affected-test evidence meaningfully support the portable implementation; native Windows and installer claims remain appropriately unproven.
