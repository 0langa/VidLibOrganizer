### Task 10: Usable Rename vertical slice and bounded IPC

**Files:** Create `src-tauri/src/lib.rs`, `src-tauri/src/selection.rs`, `src-tauri/src/commands/mod.rs`, `src-tauri/src/commands/rename.rs`, `src-tauri/tests/command_contracts.rs`, `ui/jobs.js`, `ui/exact.js`, `ui/rename/main.js`, `ui/rename/preview.js`, `ui/rename/history.js`, `tests/ui/rename-basic.spec.mjs`, `tests/ui/fixtures/desktop-bridge.js`, `tests/ui/fixtures/command-contracts.json`, `tools/serve-ui.mjs`, `package.json`, `package-lock.json`, `playwright.config.mjs`; modify app_state/main/jobs, ui/index.html/main.js/api.js/styles.css/dom.js.

**Interfaces:** Implements the core commands and JS interfaces in 4.4 for Keep/FixedStem and current executable plans. Native selection returns grant/item IDs plus display strings; plans/history stay backend-paged. Existing library/finder flows keep their command signatures.

- [ ] **Step 1 — Red:** Add command tests `stale_nonce_cannot_apply`, `old_session_plan_is_invalid`, `page_never_returns_native_paths`; browser tests `rename_basic_preview_confirm_cancel`, `preview_response_after_edit_is_ignored`, `browser_preview_cannot_apply`, `exact_bytes_above_js_safe_integer`, and keyboard/dialog focus behavior.
  ```js
  await expect(page.getByTestId('rename-apply')).toBeDisabled();
  await expect(page.getByTestId('exact-bytes')).toContainText('9,007,199,254,740,993');
  expect(bridge.appliedTargets).toEqual([]);
  ```
- [ ] **Step 2 — Verify red:** `npx playwright test tests/ui/rename-basic.spec.mjs`; desktop command tests with `cargo test -p vidlib-tauri commands::rename` where native dependencies exist.
- [ ] **Step 3 — Implement:** Move desktop setup/command modules into a testable library with `pub fn run()` and keep main.rs as the small binary entry point; expose the narrow owned handler/adapter interfaces required by integration tests. Add Rename navigation/table/minimal rule editor exposing only implemented controls, confirmation summary, status polling, cancel/history/recovery, structured error formatting, generation-aware response acceptance and listener teardown. Use textContent/document fragments and BigInt formatting; no HTML string interpolation or JS rename engine. Scope mocked bridge to tests outside packaged UI; browser sample mode remains read-only. Add Playwright dev scripts and a localhost-only Node static server with correct module MIME types, without a build/bundler/runtime dependency.
- [ ] **Step 4 — Verify green:** Same tests, JS syntax checks, existing finder sample interaction tests, desktop owned-state serialization tests. UI renders at most one 200-row page and cannot enable a stale plan through out-of-order job completion.
- [ ] **Step 5 — Commit:** `feat: add Rename preview execution and recovery interface`.

