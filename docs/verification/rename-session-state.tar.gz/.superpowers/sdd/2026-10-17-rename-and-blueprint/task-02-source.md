### Task 02: Prove the no-replace filesystem adapters

**Files:** Create `crates/vidlib-fileops/src/platform/mod.rs`, `crates/vidlib-fileops/src/platform/windows.rs`, `crates/vidlib-fileops/src/platform/linux.rs`, `crates/vidlib-fileops/src/error.rs`, `crates/vidlib-fileops/tests/platform.rs`, `crates/vidlib-fileops/tests/windows_platform.rs`; modify `crates/vidlib-fileops/src/lib.rs`, crate/root manifests and Cargo.lock; add `docs/verification/filesystem-capabilities.md` during execution.

**Interfaces:** Consumes FileStamp/native paths; produces Filesystem, PlatformFs populated NamespaceSnapshot, per-parent DirectoryFacts, capability evidence and OpError. NamespaceSnapshot/DirectoryFacts are defined by Task 01. The Filesystem seam exposes native primitives and does not depend on future Rename recipe/step types. Use the Windows API binding for handle-aware inspection/rename and Linux `renameat2(RENAME_NOREPLACE)` through rustix; unsupported targets fail closed. Do not call private Rust std internals or use an existence-check/overwriting rename fallback.

- [ ] **Step 1 — Red:** Add `existing_target_never_replaced`, `target_created_after_inspection_is_not_overwritten`, `directory_case_policy_is_per_parent`, `reparse_ancestor_rejected`, and Windows locked/case-only/directory tests. Assert both source/destination contents survive the conflict and sibling directories retain their distinct case policy.
  ```rust
  assert_eq!(err.code, ErrorCode::DestinationExists);
  assert_eq!(std::fs::read(&target)?, b"existing");
  assert!(source.exists());
  assert_ne!(insensitive.case_sensitive, sensitive.case_sensitive);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test platform`; Windows: `cargo test -p vidlib-fileops --test windows_platform -- --nocapture`.
- [ ] **Step 3 — Implement:** Pin the public Filesystem seam and no-replace primitives using the `windows` crate under cfg(windows) and rustix under cfg(target_os="linux"), native handle identity/freshness/reparse checks, per-directory case/length/reserved-name facts, create-new staging ownership, flush/durability outcomes, and typed unsupported results. Add capability fixtures and record tested API/OS/filesystem combinations. Distinguish deterministic process-termination recovery from unsupported hardware/power-loss guarantees; a journal does not make a whole batch atomic. Prove metadata setters now, but expose them through recipes only in Task 20.
- [ ] **Step 4 — Verify green/platform gate:** Run both tests on their platforms; record NTFS file+folder behavior, exFAT/removable and SMB capabilities or explicit unsupported outcomes. A Linux-only session leaves Windows rows pending and continues Tasks 03/06/11–16 without assuming Windows support.
- [ ] **Step 5 — Commit:** `feat: add verified no-replace filesystem adapters` with the actual capability evidence.

