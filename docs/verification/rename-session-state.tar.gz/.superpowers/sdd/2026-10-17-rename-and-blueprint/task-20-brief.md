# Task 20: Opt-in filesystem attributes and timestamps

## Current recovery integration handoff

Read final Task08/09/19 reports. Task08 can reconcile already-applied metadata evidence but deliberately did not execute planned metadata Resume/Restore effects; implement metadata execution and typed inverse/recovery together here. Preserve immutable original receipts/events, pinned Restore group, fresh complete namespace/directory evidence when needed, durable intent before effects, held native identity and epoch-before-terminal finalization. Extend actual process-crash/compensation/Undo tests for the new metadata phases rather than counting refusal as completed support.


**Files:** Create `crates/vidlib-fileops/src/metadata.rs`, `crates/vidlib-fileops/tests/metadata_actions.rs`; extend rename recipe/evaluate/journal/undo and desktop metadata DTOs.

**Interfaces:** `MetadataChangeSet` carries per-field Keep/Set/Clear or timestamp Set/Offset/Increment; original and requested states are part of the plan and receipt. Extend Filesystem::set_metadata and inverse planning; metadata-only rows are Changed even if their path stays identical.

- [ ] **Step 1 — Red:** Add `all_defaults_leave_metadata_unchanged`, `each_windows_attribute_and_timestamp_can_be_explicit`, `offset_increment_uses_frozen_item_order`, `partial_set_failure_is_reported_and_recoverable`, and `undo_refuses_changed_poststate`.
  ```rust
  assert_eq!(default_receipt.after.modified_ns, before.modified_ns);
  assert_eq!(metadata_only_row.status, RowStatus::Changed);
  assert_eq!(restored.attribute_bits, original.attribute_bits);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-fileops --test metadata_actions`; run Windows-created/accessed/modified and hidden/read-only/archive/system fixtures there.
- [ ] **Step 3 — Implement:** Native supported setters, typed unsupported results elsewhere, frozen date/time policies from Task 13 and checked per-item increments. Journal expected/current/original states per field, not only filenames. Do not silently clear read-only or write embedded recording metadata to make a rename succeed. Restore only the fields actually changed after verifying expected poststate.
- [ ] **Step 4 — Verify green:** Metadata/undo/recovery tests including failure after a subset of fields; no-op controls stay invisible in the operation summary. Document OS-managed access-time limitations truthfully.
- [ ] **Step 5 — Commit:** `feat: add explicit recoverable file metadata changes`.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.2 Recipe semantics and immutable plans

Task 03 owns `RecipeV1 { schema_version: 1, revision, selection, numbering_order, rules, companions, destination, collision_policy, metadata_changes }`. Every rule is tagged data with its own ID, enabled flag, segment selector, and parameters; reject unknown tags/versions. No eval or embedded JavaScript.

Pin these semantics before implementing rules:

- Text positions are 1-based Unicode extended grapheme indices; negative positions count from the end (`-1` is last), endpoints are inclusive, zero/out-of-range is a row issue. Delimiter occurrence is 1-based, literal, left-to-right/non-overlapping; delimiters are excluded unless explicitly requested. Resolve each rule's segment against that rule's **current** input; do not alter outside text.
- Case conversion uses Unicode word boundaries/full mappings; exceptions are whole-word case-insensitive matches restored to the configured spelling. Roman handling is an explicit Keep/Upper/Lower option, disabled unless selected. Transliteration is explicit. Preserve original spelling/normalization otherwise.
- PCRE2 operates on supported Unicode names with UTF/UCP enabled, JIT off. Replacements support `$1`, `${name}`, and `$$`; invalid capture references are recipe errors, an unmatched valid optional capture yields empty text. First/all and case-sensitive/insensitive are explicit.
- Counter: `start + floor(ordinal/repeat_each) * step`, checked arithmetic; ordinal starts at 0. Alphabetic is spreadsheet-style `1=A, 26=Z, 27=AA` and rejects nonpositive results. Decimal/hex accept signed values; padding applies to magnitude after the sign. Per-folder resets use the **original** source parent. Companions do not consume ordinals. Display sorting never edits numbering order.
- Date formats use the documented chrono/strftime subset, not locale guessing. Require an input format for ambiguous numeric dates. Timezone is UTC, a confirmed IANA zone, or fixed offset; resolve local zone explicitly and freeze it. Reject DST ambiguity/nonexistence unless the recipe explicitly chooses a resolution. Absent recording timezone stays unknown.
- Templates use an AST, not a second executable language: `TemplatePart::Literal(String)`, `Field { key: FieldKey, format: ValueFormat, fallback: Option<String> }`, and `Optional(Vec<TemplatePart>)`. Missing required fields block; Optional renders nothing if an inner required field is missing. Token chips in the common editor edit this AST. Fields cover original/current stem, ext, parent level, relative directory, counter, dates, exact size, canonical media properties, hashes, UUID/random values. Explicit extension mode alone changes extension unless WholeName is selected.
- Random/UUID, now/timezone, hashes, and requested metadata are frozen in `FrozenInputs` for a preview. Explicit missing-field/fallback decisions are preserved. Do not silently regenerate inputs during execution.

`evaluate(inventory: &Inventory, recipe: &RecipeV1, inputs: &FrozenInputs) -> Result<EvaluatedBatch, RenameError>` returns candidate names/paths, group ownership, and per-rule explanations. `PlatformFs::capture_namespace(grants, candidates) -> Result<NamespaceSnapshot, FsError>` supplies observed target entries, per-parent case/name limits, and capabilities. `plan(inventory, evaluated, namespace, version: PlanRef) -> Result<RenamePlan, RenameError>` is deterministic; it does not perform writes.

`PlanRef { session_id, plan_id, revision }`; `RenamePlan` holds input generation, recipe revision, immutable rows/counts/issues, execution graph, frozen inputs and grants. Task 03 owns the pure `ExecutionPlan`/`ExecutionStep` data types in rename/model.rs; Task 06 builds them. ExecutionPlan includes ordered dependency groups, exact steps and inspection provenance (approved PlanRef, inventory/recipe snapshots, frozen values). These data types never depend on fileops. `PlanRow` exposes old/new display names/paths, exact quantities, source EntryId, group, status (`Changed | Unchanged | NeedsReview | Blocked`), and explanations. Native paths remain in backend-only fields. `PlanStore` is process/session scoped; invalidation revokes confirmation nonces and old PlanRefs. Apply cannot accept caller-supplied target paths.

Preview orchestration order is fixed: validate grants/inventory/recipe -> select and resolve explicit associations -> freeze the primary numbering vector -> determine requested input fields and prepare their frozen values -> evaluate ordered primary rules and propagate companion names -> resolve destination layouts -> capture target namespace/protected-root policy -> build/validate the graph for the complete selection -> publish the current PlanRef/summary. Do not assign counters before companion ownership is known or derive companions from partially transformed primary names. Preserve per-entry/rule generated values within the current inventory's FrozenInputs until explicit regeneration or inventory refresh.


### 4.3 Execution, journal, events, and coordination

Task 04 owns Journal, StepReceipt, event/state persistence and `Journal::open(path: &Path) -> Result<Journal, OpError>`, `begin(&mut self, plan: &ExecutionPlan) -> Result<OperationId, OpError>`, `intent(&mut self, op, step: &ExecutionStep) -> Result<(), OpError>`, `complete(&mut self, op, receipt: &StepReceipt) -> Result<(), OpError>`, `pending(&self) -> Result<Vec<PendingOperation>, OpError>`, `events_after(cursor, limit) -> Result<EventPage, OpError>`, and `ack_events(&mut self, ids: &[EventId]) -> Result<(), OpError>`. ExecutionPlan/ExecutionStep are imported from Rename's pure model, not redefined. A connection is opened/used on its owning blocking thread; read queries use separate connections. Set/verify WAL, FULL, foreign_keys=ON, busy_timeout=5000 ms; migrations/intent/receipt transactions use BEGIN IMMEDIATE and explicit commit. No SQLite transaction spans filesystem I/O.

Own schema: `schema_migrations`, `operations`, `steps`, `receipts`, `operation_events`, `outbox_ack`, `history_visibility`; Task 25 adds protected-root policy tables. Each step stores full native path codec, expected prestate, object/temporary ownership, group/sequence, and observed poststate; plan/recipe inputs are stored for inspection but recovery uses the compiled steps. State machine: Prepared -> Running -> Completed / Cancelled / Failed / RecoveryRequired; steps Planned -> IntentDurable -> Applied -> CompletionDurable, or Compensated/Unresolved. Applied is the observed in-memory action state until its receipt transaction commits; a restart without that receipt follows reconciliation, not a fabricated durable flag. SQLite commit failure stops the next filesystem step.

`ExecutionStep` variants cover RenameEntry, CreateDirectory, StageCopy, PublishCopy, RemoveSource, SetMetadata, RemoveOwnedCopy, and RemoveOwnedEmptyDirectory, with exact expected states. `StepReceipt` records actual paths/identity, digest when applicable, metadata, completed phase, and durability result. Store intent before action and receipt after action; reconcile the action/receipt gap by identity, not blind retries. One dependency group is the compensation unit; completed prior groups remain completed.

Rename-cycle temporary names are logical reservations recorded in the graph/journal; the first no-replace move materializes the path atomically. Do not create an empty placeholder and then overwrite it. Copy staging uses create-new ownership with a recorded native identity, and publication still uses no-replace semantics.

`OperationEventV1` contains stable EventId, OperationId, GroupId, StepId, kind, completed phase, native before/after paths, before/after FileStamp, digest if available, observed time, `origin: App`, and journal sequence/provenance. Emit facts for each completed phase, including a verified published copy whose later source removal fails. Events and receipts commit together. Imported reports never become executable journals.

Task 05 owns `Coordinator::open(app_data: &Path) -> Result<Coordinator, OpError>` and `try_acquire(kind: LeaseKind) -> Result<Lease, OpError>` with RAII Read/Write/Recovery leases. Use Tauri's `app.path().app_local_data_dir()` for the two databases and lock file, validate local storage, and retain the existing app_config_dir libraries.json location. Use a per-app-data OS advisory lock file (shared readers, exclusive writer), plus process-local job registry and startup pending-journal gate. A recovery lease is exclusive but may enter RecoveryRequired state. No destructive job bypasses it, including legacy duplicate actions. A second instance cannot write to this app data concurrently. Denied acquisition returns Busy/RecoveryRequired, not a blocking UI wait.

The operation store also owns a monotonic namespace/policy epoch. Read/capture it under a read lease, store it with the plan, and compare again inside the write lease before preflight. Increment it after any app path mutation or protected-root policy update, including partial success, before releasing the lease. Read queries/registries use it to revoke stale results across app instances. An intent/receipt failure leaves the recovery gate active rather than authorizing a stale plan. Blueprint root registration cannot retroactively permit an older plan to rename a newly protected root.

Task 07 owns `execute(plan: &RenamePlan, lease: &Lease, journal: &mut Journal, fs: &mut dyn Filesystem, control: &JobControl) -> Result<OperationReport, OpError>`. The real Windows and Linux adapters and fault-injection test adapter implement `Filesystem`: capture/verify state, no-replace rename/publish, owned directory/staging creation, verified content I/O, metadata changes, and flush results. `OpError` has stable code, phase, operation/step/item IDs when known, message, and retryability; UI receives a serializable DTO, not a panic/debug dump.

Task 08 owns `reconcile(op: &PendingOperation, fs: &mut dyn Filesystem) -> Result<RecoveryPreview, OpError>` and `apply_recovery(preview, choice: Resume | Restore, lease, journal, fs, control) -> Result<OperationReport, OpError>`. Task 09 owns `plan_undo(completed: &OperationRecord, namespace: &NamespaceSnapshot, version: PlanRef) -> Result<RenamePlan, OpError>`; inverse operations use the same executor/journal/confirmation flow.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.



## Task19 inverse-lineage carry
Controller Ruling11 permits a checked ordered one-to-many recovery-effect lineage (or equivalent durable compiled inverse plan) where a forward step requires multiple copy-back/owned-cleanup effects. Old rows/meaning and immutable original facts survive migration. Each inverse has durable intent/receipt and fresh identity/full digest; all required effects must finish before its forward step/group is compensated. Interrupted chains retain pinned Restore scope/recovery ownership and epoch ordering; restored cross-volume objects have newly recorded actual identities. Read final reviewed Task19 report/signatures; do not restore the old one-to-one assumption or treat incomplete chains as compensated.

Task19 Ruling12 adds explicit source-directory removal with matching owned destination directory receipt, complete descendant effects, fresh source identity/emptiness and compiled deepest-first quarantine. Original dir metadata freezes before child effects; only owned destination dirs get preservation metadata. Actual folder Restore/Undo/new identities and unknown/nonempty refusals belong19; read its final reviewed report, preserve this protocol in metadata/UI/verification work.

Task19 Ruling13 persists canonical inverse dependencies across originals in one pinned Restore group: parent creation precedes child copy-back, directory original metadata follows child completion, and an original is compensated only when its entire effect set finishes. Typed DirectoryAfterEffects preserves native ownership/original metadata and refreshes material only against named completed child receipts plus complete expected namespace proof; unknown/unstatable changes never become authority. Preserve this scheduling/metadata protocol when extending R16 and crash verification; read final19report for actual reviewed signatures.


## Task19 final interface carry

Read final `task-19-report.md` (and appended review fixes if present) before changing metadata execution or recovery. Task19 implemented copy/directory preservation metadata, not full R16 controls. Preserve existing same-directory exact-file preview and ordinary Undo tests as well as explicit destination cases. Do not add future sibling target capture to an exact-file in-place grant. Source Copy/Move original grants remain available for exact original path restoration; read-only parent capture is never parent metadata authority.

Ruling14: parent bindings may be concrete `ParentAuthority::Observed` (exact old PhysicalId JSON preserved) or `Created { created_by, path }`, resolved only through an exact durable canonical CreateDirectory receipt with real new native identity, path/kind/group/dependency and held no-follow checks. No fabricated future IDs or fresh-listing authority. Checked v9–v11 migrations, one-to-many effects and complete group manifest/dependency graph retain original receipts/events and old concrete chains. All required inverse effects must finish before original compensation.

`DirectoryAfterEffects { original, created_by, effects }` authorizes material refresh only from named completed child facts plus complete expected namespace, exact native grant, unchanged factual creation/attributes for the directory and captured descendants. It must not bless unrelated changes or observed parent metadata. New R16 partial-field restoration must retain this stricter copy/folder proof and restore only fields actually changed after expected-poststate checks. Journal canonical inverse re-derivation stays pure; no filesystem I/O inside SQL write transactions.

Task19 final base evidence before any review fixes:539 workspace pass/0fail/1ignored helper; copy_move47 includes2 child helpers, real cross-volume `/dev/shm` and forward/inverse subprocess crashes. Linux owning Clippy/fmt/diff and WindowsGNU all-target cargo check pass; Windows runtime/MSVC/install/storage/power-loss remain pending and production gates CLOSED. Use final report for the current reviewed commit and exact APIs; controller will dispatch only after Task19 review clears.


## Metadata composition checks

General metadata actions must compose with both existing in-place execution and Task19 Copy/Move/folder workflows, including partial failure, Resume/Restore and filesystem Undo. Use the actual latest receipt-derived target identity/poststate after preceding effects. Copy keeps the source unchanged and CopyUndo still requires full digest plus the completed expected poststate; MoveUndo/Restore recover only the original fields actually changed. A metadata-only success is not sufficient evidence for composed path+metadata groups. Keep all original factual receipts immutable and field-specific expected/original states explicit.

The existing portable `MetadataChange::Timestamp {field,value_ns}` is an exact Set intent; preserve its meaning when adding Offset/Increment. Defaults/Keep produce no metadata effect or summary. Support and timestamp precision must be truthful per native setter/filesystem; an unsupported creation-time/attribute/precision request must not be reported as applied or silently redirected to a different field. Preserve unknown attribute bits when changing the four opted-in Windows flags. Native Windows runtime/precision/atime behavior remains pending when unavailable, with gates closed.

Read Task19 appended review fixes: directory recovery must distinguish durable lineage from old-path live material, prove the surviving namespace for directory rename gaps and owned-removal absence, and resolve fresh named-effect material before resumed renames. Future restored parents keep planned/live path and exact native identity/dependency authority. Frozen explicit choices remain scoped and must not bypass native source freshness checks. Do not reintroduce the pre-fix original-stamp or old-path-only assumptions.


## Task20 timestamp increment ruling

Ruling: Task20 retains existing MetadataChange::Timestamp as exact Set and adds explicit Offset (frozen original field plus offset_ns) and Increment (explicit start_ns plus frozen ordinal times step_ns), all checked without implicit original-time addition or clock regeneration. Metadata Increment uses the full frozen primary_order across selected primary kinds, independent of Number/Counter numbering_scope; resolved selected companions inherit their primary ordinal and consume none. Missing original Offset base or unresolved Increment owner/ordinal blocks the affected row with a typed issue, never an invented value or unselected mutation. Reason: separate visible intents make timestamp semantics deterministic while preserving existing frozen selection/order and companion ownership contracts. Cost if wrong: users wanting original+offset+ordinal or independently staggered companions need another explicit mode; mixed-kind scoping requires selection filtering, and additive variants require compatible readers. Native support/precision, original per-field authority and expected-poststate recovery checks remain mandatory; no Windows qualification is inferred.


## Task20 durable metadata-prestate carry (Ruling16)

Ruling: Task20 adds a checked, separately persisted resolved metadata-prestate relation rather than a new capture action. Capture factual before-state outside SQL under existing native identity/grant/named-effect/namespace proof; bind it immutably to the exact operation/SetMetadata step and persist it atomically with that step's durable intent BEFORE the native setter. Reverify the same actual object/expected fields immediately at native effect. Every new SetMetadata path, including Task19 preservation and inverse/recovery metadata, must use this protocol. Probe/Resume/Restore/receipts use the captured before-state; never refresh it from an already changed object or reinterpret compiled original intent as a factual before-state. Duplicate/reopen writes preserve the first exact binding. Keep complete DAG/parent/epoch rules and no filesystem I/O inside SQL. Checked migration preserves old receipts/events/meaning and rolls back on failure. Legacy before-state may be derived only from exact existing durable evidence (e.g. static Observed/receipt proof); an old dynamic directory gap with no provable before-state remains explicitly unresolved rather than invented. Reason: child effects make live directory material dynamic; after a SetMetadata receipt gap the current requested value cannot truthfully supply its own original value. Cost if wrong: extra journal protocol/migration/durability work and crash tests; older builds reject the new schema, and unprovable legacy dynamic gaps may need review. Actual crashes around prestate+intent/native effect/receipt and migration retention/rollback are required. Compatibility limits and unavailable native Windows checks remain explicit; no Windows gate opens.

Read the final reviewed Task20 report for implemented signatures and actual evidence. UI and verification must retain truthful unresolved legacy gaps and field-specific original/requested/expected poststates.


## Task20 directory restoration target carry (Ruling17)

Ruling: Task20 distinguishes the frozen pre-operation original metadata used as the approved restoration target from the factual native pre-Set state durably captured under Ruling16. Directory Undo/Restore finalization restores only the fields explicitly changed by the original operation to those frozen original values, after its named child inverse effects, using the actual current directory identity and full DirectoryAfterEffects grant/namespace/dependency proof. Keep factual pre-Set and observed poststate as immutable receipt evidence; never rewrite them to look like the frozen originals. Automatic Task19 preservation keeps its explicit original-field intent. Do not restore unrelated fields, bless unknown child/external changes, fabricate identities, or reinterpret legacy receipts. Reason: the operation's own child path mutations change directory mtime between preview and setter, so restoring that intermediate value would not restore the approved original state after paths recover. Cost if wrong: restoring a preview-original field may differ from an intermediate OS-generated time users expected, and inverse planning/proof needs extra ordering/regression work; a separate future intent would be needed for intermediate-time semantics. Real direct-child plus nested same-volume Rename and cross-volume folder Resume/Restore/Undo retain exact original/factual/requested separation. Keep/default is distinct from an explicit directory Set that equals the frozen original but still needs finalization after child path effects. Native Windows qualifications remain pending and gates stay closed.


## Task20 controlled-field execution authority carry (Ruling18)

Ruling: Task20 fix round1 adds typed field-sensitive observed identity authority carrying the exact durable expected stamp plus the explicitly controlled timestamp fields, canonically derived by Undo from the original authorized intents and latest completed factual receipts. Keep existing Observed/FromReceipt data and generic volatile-atime semantics unchanged. New field constraints survive compiled inverse serialization, preflight, receipt/path lineage, native RenameRequest/cleanup at the first destructive effect, and recovery/Resume/Restore; never flatten them into generic freshness or refresh controlled values from an externally changed object. A receipt can track actual new identity/path but cannot silently discard or replace a controlled-field expectation; only explicitly authorized named effects may change that expectation under existing DirectoryAfterEffects/factual-prestate rules. Revalidate actual held and bound objects at the final existing native validation boundary. Preserve source grants/protection, full digest/identity, DAG/epoch and immutable facts; canonical validation prevents removal/substitution of required constraints and stays pure with no filesystem I/O in SQL. Preserve old decoding/meaning with checked migration only if genuinely required; this ruling does not require another journal relation. Reason: generic identity freshness intentionally ignores volatile atime, so an Undo-only preview check cannot protect a later destructive action. Cost if wrong: a broader serialized identity/native request and inverse/recovery protocol, more compatibility/crash tests, possible conservative refusals/rework, and older readers reject the new variant. Native Windows remains pending and production mutation gates stay CLOSED.

Read final reviewed Task20 report including appended fix1 for actual type/signature/evidence.
