### Task 21: Complete the Rename controls and user journeys

**Files:** Create `ui/rename/rules.js`, `ui/rename/selection.js`, `ui/rename/associations.js`, `ui/rename/destinations.js`, `ui/rename/metadata.js`, `tests/ui/rename-rules.spec.mjs`, `tests/ui/rename-workflows.spec.mjs`; extend the common recipe editor, preview/history and desktop request validation.

**Interfaces:** R01–R17 use only the implemented RecipeV1/typed command DTOs. All controls share createRecipeEditor and start_rename_preview; a single state reducer tracks inventory/recipe/plan revisions and current job. UI grouping does not create alternate filename behavior.

- [ ] **Step 1 — Red:** Browser golden scenarios cover every R01–R17 control family, per-rule explanations, manual numbering order, search/200-row paging/highlighted differences, imports/paste/export/presets/edit undo, companion choice, folder/destination/metadata summaries, recovery and filesystem undo. Add `older_job_finishes_after_newer_recipe` and malicious filename/metadata text fixtures.
  ```js
  expect(bridge.lastAppliedPlanRef).toEqual(latestReviewedPlanRef);
  await expect(page.locator('#rename-results script')).toHaveCount(0);
  await expect(page.getByTestId('rename-row')).toHaveCount(200);
  ```
- [ ] **Step 2 — Verify red:** `npx playwright test tests/ui/rename-rules.spec.mjs tests/ui/rename-workflows.spec.mjs`.
- [ ] **Step 3 — Implement:** Complete the actual controls and accessible labels for the full matrix; lazy advanced panels for metadata/regex, explicit missing-field actions, fixed revision acceptance, abortable watchers and focus restoration. Display-only sorts cannot edit numbering. Review summaries include non-displayed selection rows and carried descendants. Use JSDoc data interfaces and text nodes; no placeholders or disabled unfinished options count as implemented scope.
- [ ] **Step 4 — Verify green:** Browser journeys at normal/narrow viewport, keyboard-only use, screen-reader live status, zero app console errors, and current finder/libraries regressions. Syntax-check all modules and verify the packaged browser sample cannot call file actions.
- [ ] **Step 5 — Commit:** `feat: complete bulk rename editing and review workflows`.

