# Task 01: Native-path inventory and coverage


**Files:** Create the `crates/vidlib-inventory` files listed in section 3, `crates/vidlib-inventory/tests/support/mod.rs`, `crates/vidlib-inventory/tests/inventory.rs`, `crates/vidlib-inventory/tests/path_codec.rs`; modify root `Cargo.toml`/`Cargo.lock`.

**Interfaces:** Produces IDs, native path codec, FileStamp/RootBinding/Inventory/ScopeCoverage/JobControl and `scan` from 4.1; no dependency on Rename or Blueprint. Tests use actual temporary directories and a read-only OS adapter seam for injected stat/listing failures.

- [ ] **Step 1 — Red:** Add `scan_keeps_unique_empty_and_nonvideo_entries`, `overlap_deduplicates_paths_not_hardlinks`, `failed_stat_retains_listed_child`, `path_codec_round_trips_native_units`, and `cancellation_preserves_coverage`. Fixture has `a.mkv`, zero-byte `b.mp4`, `notes.txt`, a nested directory, overlap, a link, and two hard-link paths. Required assertions:
  ```rust
  assert!(inventory.entries.iter().any(|e| e.display_name == "b.mp4"));
  assert_eq!(hardlink_entries.len(), 2);
  assert!(!failed_scope.subtree_complete);
  assert!(failed_scope.listed_names.contains(&failed_name));
  assert_eq!(decode_path(&encode_path(&native_path))?, native_path);
  ```
- [ ] **Step 2 — Verify red:** `cargo test -p vidlib-inventory --test inventory --test path_codec`; it must fail because the public inventory contract is missing, not because a test touched a user directory.
- [ ] **Step 3 — Implement:** Add workspace member, serde/uuid/walkdir dependencies and the 4.1 interface; native timestamp precision, no-follow traversal, per-directory coverage, read-only volume/file identity adapters, protected marker/staging exclusions. Supply deterministic injected cancellation/failure fixture support. JSON exact-number/path tests belong here.
- [ ] **Step 4 — Verify green:** Same command, then `cargo clippy -p vidlib-inventory --all-targets -- -D warnings`. Exercise non-UTF8 Unix bytes and Windows UTF-16 fixture paths; report unsupported transformations without lossy lookup.
- [ ] **Step 5 — Commit:** `feat: add native-path collection inventory`. Include only this crate and required workspace/lock changes.


## Global Constraints

The following requirements are copied from the approved specs and apply to every task:

- "The release works offline on Windows without a user-installed script runtime."
- "Blueprint is optional."
- "Native paths remain owned by Rust. UI actions refer to item/plan IDs, not reconstructed display strings."
- "New byte counts and timestamps crossing JSON use exact encodings, not rounded JavaScript numbers."
- "The backend is authoritative for generated names. The UI does not implement a second transformation engine."
- "Never overwrite an existing entry."
- "Before mutation, write and durably flush an execution journal in app-local `operations.sqlite3`. Use SQLite WAL with `synchronous=FULL` on a local filesystem."
- "The batch is recoverable, not an atomic filesystem transaction."
- "Plans expire on process restart and after inventory/recipe/selection changes."
- "User expressions run without JIT initially, with match limit 1,000,000, depth limit 1,000, heap limit 8 MiB, and pattern limit 16 KiB."
- "Run metadata probes off the UI thread in a cancellable helper process with a 10-second per-file deadline, one active probe per selected drive by default."
- "Validate configuration schemas and bound imports: 64 MiB/100,000 rows for mapping files, 1 MiB/100 rules for recipes, and the regex limits above."
- "Table pages are 200 rows; target validation includes all selected rows."
- "Store collection records in app-local `blueprint.sqlite3`, outside media roots and network shares."
- "No marker is created just by scanning, adding a library folder, or opening Blueprint."
- "The marker, if enabled for an explicitly chosen root, is `.vidlib-blueprint.json` with only `schema_version: 1`, `collection_id`, and `root_id`. Parse only this schema, limit the file to 4 KiB, and reject links/reparse points."
- "Limit an import to 256 MiB and 1,000,000 inventory entries."
- "A stale snapshot is never authority for deletion, rename, or undo."
- "The complete Rename release and this Blueprint foundation have separate completion reports."

The rest of both specs remains normative. Implement R01–R18 completely; intermediate slices are not the finished Rename feature. Retain the current duplicate-finder behavior and fixtures. No arbitrary scripting, online identification, automatic renaming, cloud sync, continuous watcher service, semantic season mapping, or convention-inference hero feature is added.


## Shared contracts applicable to this task
### 4.1 Native paths, IDs, observations

Task 01 owns opaque UUID newtypes in `vidlib_inventory::ids`: `InventoryId`, `RootId`, `EntryId`, `GrantId`, `SessionId`, `JobId`, `PlanId`, `GroupId`, `StepId`, `OperationId`, `EventId`, `PresetId`, `CollectionId`, `AttemptId`, `AttachmentId`. IDs are not permissions. Revisions are Rust `u64`; schema versions are small `u32`.

`NativePathRecord { platform: WindowsUtf16Le | UnixBytes, bytes: Vec<u8> }` round-trips exact OS strings. Persist path keys as bytes, with a separate display string; only root-relative validated records enter portable inventories. Never use display strings or physical file IDs as unique path keys. Unsupported/unroundtrippable rename names remain visible issues. All new JSON u64/i128 counts/times/revisions are validated decimal strings; UUIDs are strings. SQLite stores exact quantities as decimal text, with fixed-width big-endian numeric sort keys where numeric indexing is required. Do not cast them to SQLite REAL or JS Number.

`FileStamp` contains optional physical identity, size for regular files, native-precision created/modified/accessed epoch-nanoseconds (`Option<i128>`), and Windows attribute bits. `PhysicalId` includes platform, volume identity, and file identity. `EntrySnapshot` contains EntryId, RootId, exact relative path, Rust-owned absolute PathBuf, display_name/display_path, kind, FileStamp, observation time, and issue state. File hard-link aliases remain separate entries. `RootBinding` contains RootId, backend-owned source grant, PathBuf, evidence, and capability facts; a binding records evidence absence separately from mismatch.

`Inventory { id, generation, roots, entries, coverage, window, issues }` is immutable. `ScopeCoverage` records exact directory, **listed child names even if stat fails**, `children_complete`, `subtree_complete`, outcome, filter fingerprint, observation interval, and issues. `JobControl` owns cancellation (`Arc<AtomicBool>`) and a bounded progress sink; `Progress { phase, done, total, current_entry }` is throttled to 10/s.

Public inventory interface: `scan(request: &InventoryRequest, control: &JobControl) -> Result<Inventory, InventoryError>`. Request grants come from backend native selection/validated manual paths; inventory sources can be roots or explicit files. Child traversal never follows a link/reparse point.

Task 01 also defines read-only `DirectoryFacts` and `NamespaceSnapshot` in inventory/model.rs: exact observed parent paths/entries, per-parent case/name/length facts, filesystem capabilities, source grants, protected-root/marker policy, persisted namespace/policy epoch and capture interval. `PlatformFs::capture_namespace(grants: &GrantSet, candidates: &[PathBuf])` in Task 02 populates these data types. Their definition never imports Rename/fileops. A test adapter can supply this same data to the pure planner.


## Expanded section 3 file ownership and dependency direction

| Owner | Files/responsibility |
| --- | --- |
| Shared read-only inventory | New `crates/vidlib-inventory/Cargo.toml`; `src/lib.rs`, `ids.rs`, `model.rs`, `path.rs`, `scan.rs`, `platform/mod.rs`, `platform/windows.rs`, `platform/unix.rs`; `tests/inventory.rs`, `tests/path_codec.rs`. |
| Deterministic rename planning | New `crates/vidlib-rename/Cargo.toml`; `src/lib.rs`, `model.rs`, `recipe.rs`, `evaluate.rs`, `graph.rs`, `validate.rs`, `text.rs`, `regex.rs`, `numbers.rs`, `dates.rs`, `template.rs`, `hashes.rs`, `selection.rs`, `mappings.rs`, `presets.rs`, `metadata.rs`, `companions.rs`, `destination.rs`; owning integration tests named in tasks. |
| Filesystem execution | Existing `crates/vidlib-fileops`; keep old public duplicate interface in `src/lib.rs`. Add `src/error.rs`, `platform/`, `journal/`, `coordinator.rs`, `events.rs`, `rename.rs`, `recovery.rs`, `undo.rs`, `copy.rs`, `metadata.rs`, `duplicate_events.rs`; new test binaries listed below. |
| Blueprint | New `crates/vidlib-blueprint/Cargo.toml`; `src/lib.rs`, `model.rs`, `store/`, `identity.rs`, `markers.rs`, `refresh.rs`, `diff.rs`, `operations.rs`, `query.rs`, `templates.rs`, `patterns.rs`, `portability.rs`, `retention.rs`. |
| Desktop adapters | Split modified `src-tauri/src/main.rs` into registration/setup plus `app_state.rs`, `jobs.rs`, `selection.rs`, `commands/rename.rs`, `commands/blueprint.rs`, `metadata.rs`, `entrypoint.rs`. Keep `preferences.rs`/libraries.json compatibility. |
| Interface | Modify `ui/index.html`, `main.js`, `api.js`, `dom.js`, `styles.css`; add `ui/jobs.js`, `ui/exact.js`, focused `ui/rename/`, `ui/recipe/`, and `ui/blueprint/` modules. New CSS stays scoped to these views. |
| Verification/build | New `tests/ui/`, `package.json`, `package-lock.json`, `playwright.config.mjs`, `tools/vendor_media_info.py`, `tools/media-info-manifest.json`, `tools/benchmark-library.ps1`, `.github/workflows/check.yml`, and release evidence under `docs/verification/`. Tests/tools are outside the packaged `ui` directory. |

Dependency direction: `vidlib-inventory <- vidlib-rename <- vidlib-fileops`; Blueprint consumes inventory, recipe data, and the **data-only** `vidlib-fileops::events` interface, never the executor. Tauri owns orchestration. `vidlib-engine` remains unchanged unless a narrow tested coordinator/receipt adaptation requires it; do not replace its scan implementation in this project. Add dependencies in their owning task, with explicit platform cfgs and committed lockfile; no speculative framework, ORM, task scheduler, or frontend bundler.

Task file lists use repository-relative paths. The owner/file map above defines each module's responsibility; shared manifest/lockfile and desktop navigation edits remain serialized by the lead. Integration tests stay with their owning crate, and browser fixtures stay outside the packaged `ui` directory.

