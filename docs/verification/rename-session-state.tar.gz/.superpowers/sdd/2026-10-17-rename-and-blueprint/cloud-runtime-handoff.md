# Already-read managed cloud runtime requirements

The controller read cloud-environment-runtime SKILL.md and references/networking.md from package c13/cloud-environment-runtime when available. A later skills-catalog update says no cloud skills are currently available; this handoff preserves relevant instructions without requiring a missing package. Superpowers instructions/assets remain available at the pinned local source paths in the implementer contract.

- Where callable, use the managed cloud environment_status tool at new/resumed work and to diagnose network/authentication errors. Check observations_current and observed running/readiness, not just desired configuration. Tool metadata may be discovered by exact name in ALL_TOOLS.
- Before networking read /etc/codex/network-policy.json. Latest observed v1 policy was unrestricted HTTP/enforced with vpn_configured false, but recheck actual current state rather than assume old readiness after replacement.
- Preserve inherited HTTP/HTTPS proxies and CA/TLS validation. No direct-route bypass, proxy removal, secret-value printing, environment dumps or credential-file inspection. Read readiness metadata only. No extra credential setup is needed for public dependency fetches unless an actual error indicates it.
- VPN/Docker/profile instructions are outside current work; do not invent or configure them to solve unrelated build issues. Report concrete unavailable capability, continue independent authorized work.
- After environment replacement, reconcile live agent status as well as filesystem state. Controller owns interrupted-worker scheduling; preserve existing code/logs rather than restart design/task.
